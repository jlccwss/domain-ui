module.exports = {
  extends: ['@kl/recommended'],
  rules: {
    'no-debugger': 'error',
    'no-shadow': 'error',
    'no-unused-vars': 'off',
    'no-console': 'off',
    '@typescript-eslint/no-var-requires': 'off',
    '@typescript-eslint/ban-ts-comment': 'off',
    '@typescript-eslint/no-explicit-any': 'off',
    '@typescript-eslint/no-unused-vars': ['error'],
    'no-empty': [
      'error',
      {
        allowEmptyCatch: true
      }
    ],
    'comma-dangle': ['error', 'never']
  },
  env: {
    browser: false,
    node: true
  }
};
