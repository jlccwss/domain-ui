# web_plugin_talos_common_ci - JavaScript Shell 合集 

## 功能

- javascrpit
  - talosGray // 灰度
  - diffLint  // 通用Lint插件
  - freepackCheck // freepackCheck插件
  - angularHackLint  // 用于处理 anuglar和vue混合的项目lint
  - diffBranchLastTag // 使用freepack进行拆分模块发布项目进行diff输出更新模块和更新人进行消息推送
  - branchCheck // 分支检测
  - monitorCheckBeforeBuild // 监控相关
  - scriptCrossoriginCheck // 监控相关
- shell
  - es5-check // ES5语法检测
  - auto-update // 自动更新版本号
  - gray-build // 灰度build
  - lx-check  // 暂时无用
  - post-install  // 进入指定目录执行install

## Development Setup

``` bash
# 安装依赖
mnpm install

# 本地编译 
npm run build
```


## Talos 发布

[Talos 发布 ](http://talos.sankuai.com/#/project/6371?page_num=1)


## 目录结构

```bash
├── README.md               项目文档
├── test                    单元测试
└─  src                     资源路径
```
