import 'mocha';
import should from 'should';

describe('test', function () {
  it('return hello', function () {
    should('hello').be.equal('hello');
  });
});
