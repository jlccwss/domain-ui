const path = require('path');
const glob = require('glob');
const buildfils = glob.sync('./src/script/*.{ts,js}');
const TerserPlugin = require('terser-webpack-plugin');
const webpack = require('webpack');
const entry = buildfils.reduce((acc, filePath) => {
  let filename = filePath.split('/').pop().split('.').shift();
  return {
    ...acc,
    [filename]: filePath
  };
}, {});
module.exports = {
  mode: 'production',
  target: ['node'],
  entry: entry,
  output: {
    filename: '[name].js',
    path: path.resolve(__dirname, 'build/script/')
  },
  resolve: {
    extensions: ['.tsx', '.ts', '.js'],
    fallback: {
      fs: false,
      child_process: false
    }
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        use: 'ts-loader',
        exclude: /node_modules/
      }
    ]
  },
  optimization: {
    minimize: true,
    minimizer: [
      new TerserPlugin({
        extractComments: false
      })
    ]
  },
  plugins: [
    new webpack.SourceMapDevToolPlugin({
      filename: '[file].map',
      publicPath: process.env.SOURCEMAP_PUBLIC_URL
        ? `${process.env.SOURCEMAP_PUBLIC_URL}script/`
        : `./script/`
    })
  ]
};
