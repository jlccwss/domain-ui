interface Window {
  Owl: any;
  mcc: any;
  getHornConfig: (url: string, params: any) => void;
}
