#!/bin/bash

cd ${projectRoot:-.}
CLIENT_TYPE_ARR=('WEB' "MRN" "MMP")

res=$(echo "${CLIENT_TYPE_ARR[@]}" | grep -wq "${CLIENT_TYPE}" &&  echo "yes" || echo "no")
if [ "${res}" != "yes" ];then
    echo "${CLIENT_TYPE}类型,暂不支持请校验"
    exit 1
fi

if [ ${CLIENT_TYPE} = 'WEB' ]; then
    echo "web项目检测"
    if grep -l -r "analytics.meituan.net/analytics.js\|lx.meituan.net/lx.js\|lx.meituan.net/lx.5.min.js" build/; then
        echo "埋点 SDK found in Project"
        exit 0
    else
        echo "埋点 SDK NOT found in Project"
        exit 1
    fi
fi

if [ ${CLIENT_TYPE} = 'MRN' ]; then
    echo "MRN项目检测"
    if grep -l -r "@analytics/mrn-sdk" build/; then
        echo "埋点 SDK found in Project"
        exit 0
    else
        echo "埋点 SDK NOT found in Project"
        exit 1
    fi 
fi

if [ ${CLIENT_TYPE} = 'MMP' ]; then
    echo "小程序项目检测"
    if grep -l -r "@analytics/wechat-sdk" build/; then
        echo "埋点 SDK found in Project"
        exit 0
    else
        echo "埋点 SDK NOT found in Project"
        exit 1
    fi 
fi