#!/bin/bash
npm i -g @mtfe/es-check@1.0.9
echo $esnot
checkPaths=
if [ $AWP_BUSINESS_TYPE = 'web' ]; then
    echo 'web项目'
    cd ${projectRoot:-.}
    if [ -f ".escheckrc" ]; then
        echo '使用本地 .escheckrc 进行检测'
        npx es-check
    else
        checkPaths="./build/**/*.js ./build/**/*.html"
        echo "进行【$checkPaths】文件检测"
        npx es-check --module=false es5 $checkPaths
    fi
elif [ $AWP_BUSINESS_TYPE = 'MP' ]; then
    echo '小程序项目'
    cd ${AWP_GIT_SLUG}
    cd ${projectRoot:-.}
    checkPaths="./$AWP_MP_BUILD_DIR**/*.js"
    if [ -f ".escheckrc" ]; then
        echo '使用本地 .escheckrc 进行检测'
        npx es-check
    else
        echo "进行【$checkPaths】文件检测"
        npx es-check --module=false es5 $checkPaths
    fi
elif [ $AWP_BUSINESS_TYPE = 'MMP' ]; then
    echo 'MMP项目'
    cd ${AWP_GIT_SLUG}
    cd ${projectRoot:-.}
    checkfolder="es5checkfolder"
    if [ -d "./$checkfolder" ]; then
        rm -rf ./es5check
    fi
    unzip -o ${MMP_BUILD_PATH} -d ./$checkfolder
    cd $checkfolder
    for zip in *.zip; do
        if [[ ! $zip =~ .dio.zip$ ]]; then
            dirname=$(echo $zip | sed 's/zip$//')
            if mkdir "$dirname"; then
                if cd "$dirname"; then
                    unzip ../"$zip"
                    cd ..
                # rm -f $zip # Uncomment to delete the original zip file
                else
                    echo "Could not unpack $zip - cd failed"
                fi
            else
                echo "Could not unpack $zip - mkdir failed"
            fi
        fi
    done
    echo '解压后目录'
    ls
    cd ..
    checkPaths="./$checkfolder/**/*.js ./$checkfolder/**/*.html"
    echo "进行【$checkPaths】文件检测"
    npx es-check --module=false es5 $checkPaths
fi
