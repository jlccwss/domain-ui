#!/bin/bash
projectRoot=${projectRoot:-./}
PACKAGE_JSON_FILE=${projectRoot}/package.json

echo "package.json 文件路径："$PACKAGE_JSON_FILE

echo "当前分支:${AWP_GIT_BRANCH_NAME}"
echo "看下参数更新类型:${UPDATE_VERSION_TYPE}"

default_version_patt="[0-9]\{1,\}\.[0-9]\{1,\}\.[0-9]\{1,\}"
default_version_patt_check="^[0-9]{1,}\.[0-9]{1,}.[0-9]{1,}$"

# 本地测试暂时不需要设置账号
git config --global user.email "hfe_stash@meituan.com"
git config --global user.name "hfe_stash"

echo "自定义修改的文件path：$FILEURLS，关键字：$VERSION_KEYWOEDS"
echo "自定义版本号：$CUSTOM_VERSION_NUM"

VERSION_NAME=''

function checkPackageJson() {
    # 检测是否普通文件
    if [ -f "${PACKAGE_JSON_FILE}" ]; then
        VERSION_NAME=$(grep -e "\"version\"" ${PACKAGE_JSON_FILE} | tr -cd "[0-9][.]")
        echo "升级前版本号："$VERSION_NAME
    else
        echo "package.json 文件没有找到，请确认projectRoot参数配置"
    fi
}
# 更新package版本号
function updateVersion() {
    checkPackageJson

    if [ ${UPDATE_VERSION_TYPE} = 'major' ]; then
        npm version major --no-git-tag-version
    elif [ ${UPDATE_VERSION_TYPE} = 'minor' ]; then
        npm version minor --no-git-tag-version
    elif [ ${UPDATE_VERSION_TYPE} = 'patch' ]; then
        npm version patch --no-git-tag-version
    elif [ ${UPDATE_VERSION_TYPE} = 'version' ]; then
        if [[ "$CUSTOM_VERSION_NUM" =~ $default_version_patt_check ]]; then
            echo '版本号符合规范'
            sed -i "s/\"version\": \"${default_version_patt}\"/\"version\": \"${CUSTOM_VERSION_NUM}\"/g" $PACKAGE_JSON_FILE
        else
            echo '版本号不符合规范:\nhttps://km.sankuai.com/page/573394150'
            exit 1
        fi
    elif [ ${UPDATE_VERSION_TYPE} = 'none' ]; then
        echo '不升级版本号，退出！'
        exit 0
    fi

    if [ $? -ne 0 ]; then
        echo "npm version update error，请检查版本号格式是否符合X.Y.Z"
        exit 1
    fi
}
# MP使用环境变量版本号更新
function updateMPProdVersion() {
    checkPackageJson
    sed -i "s/\"version\": \"${default_version_patt}\"/\"version\": \"$1\"/g" $PACKAGE_JSON_FILE
}

if [ $AWP_BUSINESS_TYPE = 'MP' ]; then
    echo '小程序项目'
    cd $AWP_GIT_SLUG
    cd $projectRoot
    pwd

    # 获取环境变量中发布版本号
    temp1=${AWP_COMMENT#*\"version\": \"}
    temp2=$(echo ${temp1%\}} | awk '$1=$1')
    MPVERSION=${temp2%\"}
    echo "发布平台版本号:${MPVERSION}"
    # 如果不为空，则代表是线上环境发布，有发布版本环境变量
    if [ -n "$MPVERSION" ]; then
        updateMPProdVersion $MPVERSION
    else
        updateVersion
    fi
else
    echo '非小程序项目'
    cd $projectRoot
    pwd
    # 上一次提交的commitID
    git fetch origin ${AWP_GIT_BRANCH_NAME} --tags --depth=1
    lastCommitID=$(git rev-parse HEAD)
    # 获取某次commitID上的tag
    curTag=$(git tag --contains ${lastCommitID})

    if [ $curTag ]; then
        echo "本次发布commitID:${lastCommitID}已有打tag:${curTag}，不进行版本号升级"
        echo "退出！"
        exit 0
    fi
    updateVersion
fi

# 获取项目名称
PROJECT_NAME=$(cat package.json | jq .name | tr -d '\"')
# 获取package.json更新后的版本号
NEW_VERSION_STRING=$(cat package.json | jq .version | tr -d '\"')

# 自动更新文件版本号的函数
function updateCustomVersionPatch() {
    echo "更新的匹配文件：$2"
    echo "更新的文件版本号前缀：$1"
    sed -i "s/$1${default_version_patt}/$1${NEW_VERSION_STRING}/g" $2
    git add $2
    echo "/////////////"
}

# 处理自定义的文件版本更新
if [ "$FILEURLS" -a "$VERSION_KEYWOEDS" ]; then
    # 修改默认分隔符
    OLD_IFS="$IFS"
    IFS=",，"
    fileUrlArr=(${FILEURLS})
    versionKeyWordArr=(${VERSION_KEYWOEDS})
    IFS="$OLD_IFS"

    if [ ${#fileUrlArr[@]} != ${#versionKeyWordArr[@]} ]; then
        echo "输入的自定修改文件与关键字数量不匹配:"
        echo "文件:$FILEURLS"
        echo "关键字:$VERSION_KEYWOEDS"
        exit 1
    fi
    for ((i = 0; i < ${#fileUrlArr[@]}; i++)); do
        updateCustomVersionPatch "${versionKeyWordArr[i]}" "${fileUrlArr[i]}"
    done
fi

git add $PACKAGE_JSON_FILE

git commit -n -m "Merge: ${AWP_OP}: ${PROJECT_NAME}版本号自动升级，从${VERSION_NAME}升级到${NEW_VERSION_STRING}"

# 不需要push到仓库的项目类型
NOT_NEED_PUSH_LIST=('MP')

if [[ "${NOT_NEED_PUSH_LIST[@]}" =~ "$AWP_BUSINESS_TYPE" ]]; then
    echo "${AWP_BUSINESS_TYPE}类型项目不push代码到仓库"
else
    if [ -z "${AWP_GIT_BRANCH_NAME}" ]; then
        git push origin HEAD
    else
        git push origin HEAD:${AWP_GIT_BRANCH_NAME}
    fi

    if [ $? -ne 0 ]; then
        echo "git push 代码时出错，请检查账号hfe_stash是否有项目的写权限"
        exit 1
    fi
fi

# tag发布
TAG_STR="v${NEW_VERSION_STRING}"
git tag "$TAG_STR"
git push origin "$TAG_STR"

if [ $? -ne 0 ]; then
    echo "git push tag时出错，请检查账号hfe_stash是否有项目的写权限"
    exit 1
fi

echo " 自动升级版本号: ${VERSION_NAME} to ${NEW_VERSION_STRING} successfully."
