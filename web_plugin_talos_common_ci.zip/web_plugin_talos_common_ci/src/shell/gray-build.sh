#!/bin/bash

# node重写待废弃
GRAY_RELEASE_DIR="__gray__";

echo "是否灰度发布: $GRAY_RELEASE"
if [[ "$GRAY_RELEASE" = "true" ]];
then
  export PUBLIC_URL=$PUBLIC_URL$GRAY_RELEASE_DIR/;
  echo "PUBLIC_URL: $PUBLIC_URL";
fi

# 自定义Build插件
cd ${projectRoot:-.} 

rm -rf build/

npm run build

BUILD_RESULT=$?

if [ "$BUILD_RESULT" != 0 ]; then
  echo "构建失败"
  exit 1
fi

cd ${projectRoot:-.} 

if [[ "$GRAY_RELEASE" = "true" ]];
then
  echo "文件移动"
  mv build _temp_build_
  mkdir build
  mv _temp_build_ build/$GRAY_RELEASE_DIR
fi
