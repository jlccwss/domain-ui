#!/bin/bash
npminstall() {
    if [ -f 'yarn.lock' ]; then
        yarn install --production=false --unsafe-perm
    elif [ -f 'package-lock.json' -o -f 'npm-shrinkwrap.json' ]; then
        mnpm install --production=false --unsafe-perm
    else
        yarn install --production=false --unsafe-perm
    fi

}

echo $installfolders
if [ -n "$installfolders" ]; then
    str=${installfolders//,/ }
    arr=($str)
    for folder in ${arr[@]}; do
        echo ${projectRoot:-.}${folder}
        cd ${projectRoot:-.}${folder}
        npminstall
    done
fi
