#!/bin/bash
cd ${projectRoot:-.}
cd ${buildPath:-.}
curl https://awp-assets.meituan.net/klfe/web_plugin_talos_common_ci/script/monitorCheckAfterBuild.js | node -