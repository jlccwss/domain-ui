#!/bin/bash
cd ${projectRoot:-.}
cd ${SRC_PATH:-.}
curl https://awp-assets.meituan.net/klfe/web_plugin_talos_common_ci/script/monitorCheckBeforeBuild.js | node -