const axios = require('axios');

export interface PluginCallbackPayload {
  flowId: string;
  status: string; // 'success' | 'fail' | 'cancel', // 可以 pending 但是最后总要有一次表示结束的状态; CI 插件可通过 pending 传递执行结果；
  service: string;
  stage: string;
  params: {
    log: string;
    url?: string;
    description?: string;
    globalParams: PluginGlobalParams; // 将插件结果存放于此
    [key: string]: any; // 其他参数
  };
}

/** 全局插件回调参数，存储在 flow.callback 中可全局存取 */
interface PluginGlobalParams {
  [key: string]: any;
  approveMsg?: string; // 业务方插件提供的，给 Approve 类型使用的消息
  groupMsg?: string; // 业务方插件提供的，给 GroupMessage 使用的消息
  groupId?: string; // Talos 自动拉群的群 Id
  zipUrl?: string[]; // 业务方插件提供的构建包链接，可直接用于 upload 阶段
  urls?: string[]; // 发布结果
}
export async function getPortmData(
  url: string,
  type = 'default',
  initValue: any = []
) {
  try {
    const { data } = await axios.get(url);
    return data || initValue;
  } catch (error) {
    console.log(`${type}接口异常`, error);
    return initValue;
  }
}

export async function postServiceCallback(params: PluginCallbackPayload) {
  const url = 'http://talos-api.sankuai.com/serviceCallback';
  try {
    const { data } = await axios.post(url, params);
    return data;
  } catch (error) {
    return null;
  }
}
