/**
 * 判断两个版本字符串的大小
 * @param  {string} v1 原始版本
 * @param  {string} v2 目标版本
 * @return {number}    如果原始版本大于目标版本，则返回大于0的数值, 如果原始小于目标版本则返回小于0的数值。0当然是两个版本都相等拉。
 */
function compareVersion(v1: string, v2: string): number {
  const _v1 = v1.split('.');
  const _v2 = v2.split('.');
  const len = Math.max(_v1.length, _v2.length);

  while (_v1.length < len) {
    _v1.push('0');
  }
  while (_v2.length < len) {
    _v2.push('0');
  }

  for (let i = 0; i < len; i++) {
    const num1 = parseInt(_v1[i]);
    const num2 = parseInt(_v2[i]);

    if (num1 > num2) {
      return 1;
    } else if (num1 < num2) {
      return -1;
    }
  }
  return 0;
}

export default compareVersion;
