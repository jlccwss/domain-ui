import { getPortmData } from './http';

interface IPluginConfig {
  whiteList: Array<{
    appId: string;
    skip: boolean;
    customConfig: any;
  }>;
  customConfig: any;
}

/**
 * 获取白名单配置数据和是否需要跳过当前发布项
 * @param pluginKey 插件唯一key，规则是talos插件名称去掉KLFE；比如增量lint插件标示为KLFE-DIFF-LINT，所以pluginKey = DIFF-LINT
 * @param appId 当前发布项目ID，使用talos注入环境变量AWP_APP_ID
 * @returns pluginConfig 当前插件全部配置 理解为IPluginConfig
 * @returns isPass 是否直接跳过
 * @returns curAppConfig当前插件对应有白名单APP的配置项 理解为whiteList中appid为当前发布项的配置内容
 *  */
export const getPluginConfig = async (pluginKey: string, appId: string) => {
  const allConfig = await getPortmData(
    'http://portal-portm.meituan.com/kladmin/fe/talos-plugin-config',
    'getPluginConfig',
    {}
  );
  const pluginConfig: IPluginConfig = allConfig[pluginKey] || {};
  const isPass = pluginConfig.whiteList.some(
    (item) => item.appId === appId && item.skip
  );
  const curAppConfig = pluginConfig.whiteList.find(
    (item) => item.appId === appId
  );
  if (curAppConfig) {
    console.log('当前项目自定义配置', curAppConfig);
  }
  return { pluginConfig, isPass, curAppConfig };
};
