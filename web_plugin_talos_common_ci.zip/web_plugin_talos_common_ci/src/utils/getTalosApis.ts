import getAPI from '@nibfe/talos-public-api';
// BA key 和 secret，请联系 Talos 客服获得
const clientId = 'kl_fe_talos';
const clientSecret = '33b7dfac1b4941aa94b78b571d6af6e6';

const talosApis = getAPI({ clientId, clientSecret, env: 'production' });
export default talosApis;
