/***
 * 输出diff文件
 * 功能描述：https://km.sankuai.com/page/588923567
 */

import talosApis from './getTalosApis';
const { execSync } = require('child_process');

const testData = {
  curBranch: '',
  curEnv: '',
  appId: 0
};

async function getChangedFiles(): Promise<any> {
  console.log('/////////进入diff对比//////////');
  let output = null;
  try {
    const deploy_env = process.env.AWP_DEPLOY_ENV || testData.curEnv;
    if (!deploy_env) {
      console.log('不是在talos环境,返回缓存区的文件diff');
      output = execSync(`git diff --cached --name-only --diff-filter=ACMR`, {
        encoding: 'utf-8'
      });
    } else {
      const appId = process.env.AWP_APP_ID || testData.appId;
      const currentCommitId = process.env.AWP_GIT_COMMIT_ID;
      const branch = process.env.AWP_GIT_BRANCH_NAME || testData.curBranch;
      // 同步一下分支信息
      execSync(`git fetch origin master ${branch} --tags --unshallow`);

      let curlastCommitId = await getLastSuccessCommit({
        curBranch: branch,
        curEnv: deploy_env,
        appId: +appId
      });
      if (curlastCommitId !== null) {
        try {
          // 获取一下这个commitID所属分支
          const lastCommitBelongBranch = execSync(
            `git branch -r --contains ${curlastCommitId}`,
            {
              encoding: 'utf-8'
            }
          );
          console.log('当前commit所属分支:', lastCommitBelongBranch);
        } catch (error) {
          console.log('没有这个commit:', curlastCommitId);
          curlastCommitId = null;
        }
      }

      let masterLastCommitId = '';
      // 1.如果此分支和此环境没有发布过，
      // 2.发布过但是commit不存在了，
      // 则和master在prod环境最新的发布进行对比
      if (curlastCommitId === null) {
        console.log('进入和master分支对比的逻辑');
        //对比master分支最新打tag的commitID
        try {
          const ID = execSync('git rev-list --tags --max-count=1', {
            encoding: 'utf-8'
          }).trim();
          masterLastCommitId = ID;
          console.log('获取master最新tag的commitID做对比:', masterLastCommitId);
        } catch (error) {
          console.log('master没有tag,全量lint');
        }
      }
      const lastCommitId = curlastCommitId || masterLastCommitId;
      // 新项目第一次发布
      if (!lastCommitId) {
        return 'newProject';
      }
      console.log(
        '最后一次提交commit:',
        lastCommitId,
        '当前commit:',
        currentCommitId
      );
      /**
       * A Added
       * C Copied
       * D Deleted
       * M Modified
       * R Renamed
       * T have their type (mode) changed
       * U Unmerged
       * X Unknown
       * B have had their pairing Broken
       * * All-or-none
       */
      output = execSync(
        `git diff ${lastCommitId}...${currentCommitId} --name-only --diff-filter=ACMR`,
        {
          encoding: 'utf-8'
        }
      );
    }
  } catch (error) {
    console.log('diff记录获取失败');
    process.exit(1);
  }
  const diffFiles = output.trim().length ? output.trim().split('\n') : [];
  console.log(diffFiles, '差异文件夹');

  return diffFiles;
}

/*****
 * 获取当前分支和环境的最后一次发布成功的commitID
 * @param {Number} appId talos id
 * @param {String} curEnv 发布环境
 * @param {String} curBranch 发布分支
 *  */
async function getLastSuccessCommit({
  curBranch,
  curEnv,
  appId
}: {
  curBranch: string;
  curEnv: string;
  appId: number;
}): Promise<string | null> {
  try {
    // eslint-disable-next-line @typescript-eslint/ban-types
    const { list = [] } = await (talosApis.getAppFlows as Function)({
      id: appId,
      target: curEnv
    });
    const res = list.find(
      (item: any) =>
        item.publish_config.branch === curBranch && item.status === 'success'
    );
    if (!res) {
      console.log(`暂无${curBranch}分支在${curEnv}环境的发布记录`);
      return null;
    }
    return res.commit;
  } catch (error) {
    console.log('获取commit id失败', error);
    return null;
  }
}
export default getChangedFiles;
