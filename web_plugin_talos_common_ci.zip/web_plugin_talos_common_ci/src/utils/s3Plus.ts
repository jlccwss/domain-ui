// 线上环境
export const tenant_id = 'd1fd79bf8dca4a48b89eec256ac57a5c';
export const static_bucket_name = 'kl-talos-common';
export const mssConfig = {
  endpoint: 's3plus.vip.sankuai.com',
  accessKeyId: 'f9gm25pfw2fp5qc60000000000cdb443',
  accessKeySecret: '4kpm64bzfvrkdgwfg77pwk66wsp72zsw'
};
