/**
 * 插件地址：https://talos.sankuai.com/#/plugin/981/detail
 * Option	Description	Default value
 * -t, --threshold [number]	The minimum percentage of coverage required.	80
 * -o, --outputDir [string]	The output directory where to generate the report.	coverage-ts
 * -s, --strict [boolean]	Run the check in strict mode.	true
 * -d, --debug [boolean]	Show debug information.	false
 * -c, --cache [boolean]	Save and reuse type check result from cache.	false
 * -p, --project [string]	File path to tsconfig file, eg: --project "./app/tsconfig.app.json"
 * -i, --ignore-files [boolean]	Ignore specified files, eg: --ignore-files "demo1/*.ts" --ignore-files "demo2/foo.ts"	false
 * -u, --ignore-unread [boolean]	Allow writes to variables with implicit any types	false
 * Params:
 * threshold 所需的最低覆盖率。
 * project tsconfig文件的文件路径，例如:"./app/tsconfig.app.json"
 * ignoreFiles "demo1/*.ts,demo2/foo.ts" glob 语法 https://km.sankuai.com/page/626189407
 * TODO:
 * 压缩包上传S3 并暴露地址可以访问细节,
 * 总数据上传数据库 参考 http://dev.sankuai.com/code/repo-detail/klfe/node_system_metrics/file/detail?branch=refs%2Fheads%2Fmaster&path=src%2Fconfig%2Fdatabase.ts
 **/

import { static_bucket_name, mssConfig } from '../utils/s3Plus';
import { getPortmData } from '../utils/http';
const MSS = require('mos-mss');
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');
const rd = require('rd');

/**
 * 输出日志操作
 */
const outputdata = (outputDirDefault: string) => {
  const totalDataHtml = fs
    .readFileSync(`${outputDirDefault}/index.html`)
    .toString();
  const $ = cheerio.load(totalDataHtml);
  const [summaryTable, filesTable] = $('table');
  const summaryData = dataFormat(summaryTable, $);
  const filesData = dataFormat(filesTable, $);
  return {
    summaryData,
    filesData
  };
};
const dataFormat = (data: any, $: any) => {
  const returnArray: string[][] = [];
  const trs = $(data).find('tr');
  [...trs].forEach((tr: any) => {
    const tddata: string[] = [];
    const tds = $(tr).find('td');
    [...tds].forEach((td: any) => {
      tddata.push($(td).text());
    });
    returnArray.push(tddata);
  });
  return returnArray;
};
const showOutput = (summaryData: any[]) => {
  console.log('TypeScript覆盖率报告\n\n');
  console.log('概览\n');
  const outsummaryData = summaryData[1];
  console.log(`整体覆盖率:${outsummaryData[0]}  临界值:${outsummaryData[1]}`);
  console.log(
    `总数:${outsummaryData[2]}  已覆盖:${outsummaryData[3]}  未覆盖:${outsummaryData[4]}\n\n`
  );
};

const {
  threshold,
  project,
  ignoreFiles,
  AWP_GIT_KEY,
  AWP_GIT_SLUG,
  AWP_BUSINESS_TYPE,
  AWP_GIT_COMMIT_ID
} = process.env;
const coverType = process.env.coverType || 'file';
const tsConverageConfigUrl = process.env.tsConverageConfigUrl;

(async () => {
  let sourcePath = process.cwd();
  if (AWP_BUSINESS_TYPE === 'MP') {
    console.log('小程序项目');
    sourcePath += path.sep + AWP_GIT_SLUG;
  } else if (AWP_BUSINESS_TYPE === 'web') {
    console.log('web项目');
    sourcePath;
  }
  const outputDirDefault = `${sourcePath}/coverage-ts`;

  console.log('outputDirDefault', outputDirDefault);
  spawnSync('npm', ['install', '-g', 'typescript-coverage-report'], {
    stdio: 'ignore'
  });

  const params = [
    `--threshold=${threshold}`,
    '--strict=true',
    '--ignore-unread=false'
  ];
  if (project) {
    params.push(`--project=${project}`);
  }
  (ignoreFiles || '').split(',').forEach((item: string) => {
    if (item) {
      params.push(`--ignore-files=${item}`);
    }
  });
  console.log('输入的参数', params);
  const result = spawnSync('typescript-coverage-report', params, {
    stdio: 'ignore',
    cwd: sourcePath
  });

  const { summaryData, filesData } = outputdata(outputDirDefault);

  showOutput(summaryData);
  try {
    const fileName = `${AWP_GIT_KEY || 'test'}-${AWP_GIT_SLUG || 'test'}-${
      AWP_GIT_COMMIT_ID || ''
    }-coverage-ts`;

    const client: any = new MSS({
      ...mssConfig,
      bucket: static_bucket_name
    });
    const files = rd.readSync(outputDirDefault);
    for (const item of files) {
      const stat = fs.statSync(item);
      if (stat.isFile()) {
        const name = item.split(`${outputDirDefault}/`)[1];
        const filePath = path.join(`${outputDirDefault}/`, `${name}`);
        await client.putObject(`${fileName}/${name}`, filePath);
      }
    }
    console.log('\n////////点击下方链接查看详细报告////////\n');
    console.log(
      `http://kltalosstatic.fe.st.sankuai.com/${fileName}/index.html`
    );
  } catch (error) {
    console.log('上传文件的错误', error);
  }
  spawnSync('rm', ['-rf', outputDirDefault]);

  // 特殊文件的配置
  let pathWhiteList: [] = [];
  if (tsConverageConfigUrl) {
    const res = await getPortmData(
      tsConverageConfigUrl,
      'ts覆盖率特殊文件配置',
      {}
    );
    pathWhiteList = res?.fileList || [];
    console.log('\n特殊文件的配置:', pathWhiteList);
  }

  if (coverType === 'file') {
    console.log('\n文件级别覆盖率检测');

    const unavailableList = filesData.filter((item) => {
      const whiteItem: { path: string; threshold: string } = pathWhiteList.find(
        (cur: any) => cur.path === item[0]
      );
      if (whiteItem) {
        return (
          item[1] && Number(item[1].split('%')[0]) < Number(whiteItem.threshold)
        );
      }
      return item[1] && Number(item[1].split('%')[0]) < Number(threshold);
    });
    if (unavailableList.length) {
      unavailableList.forEach((Litem) => {
        console.log(`文件${Litem[0]}的ts覆盖率为${Litem[1]},未达到要求值`);
      });
      process.exit(1);
    }
  }
  if (coverType === 'project' && result.status !== 0) {
    console.log(`项目整体的ts覆盖率未达到要求值${threshold}`);
    process.exit(1);
  }
  console.log('检测通过!');
  process.exit(0);
})();
