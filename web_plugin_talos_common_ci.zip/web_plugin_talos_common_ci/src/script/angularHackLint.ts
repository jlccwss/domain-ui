/****
 * anuglar与vue混合的项目lint的特殊处理脚本
 */
export {};
const fs = require('fs');
const { spawnSync } = require('child_process');

(async () => {
  console.log('///////进入angular与vue共存项目lint hack处理脚本//////');
  const files = process.argv.slice(2) || [];
  console.log('diff文件:', files);

  const vuePatt = /^hybrid\/src\.*/;
  const angularPatt = /^src\/app\.*/;
  const angularFiles = files.filter((val) => angularPatt.test(val));
  const vueFiles = files
    .filter((val) => vuePatt.test(val))
    .map((item) => item.slice(7));

  let process1_status = 0; // angular同名检测
  let process2_status = 0; // angular lint
  let process3_status = 0; // vue lint
  const angularControllerLint = () => {
    spawnSync('curl', [
      '-o',
      'duplicatedNameLint.json',
      'https://awp-assets.meituan.net/hfe/fep/e825cffabe3a4efdbc11ed82200bfdf4.json'
    ]);
    const childProcess1 = spawnSync(
      'eslint',
      ['-c', './duplicatedNameLint.json', '--no-eslintrc', 'src/app'],
      {
        stdio: 'inherit'
      }
    );
    fs.unlinkSync('./duplicatedNameLint.json');
    process1_status = childProcess1.status;
  };
  const angularLint = (lintFiles: any) => {
    console.log('angular修改的文件:', lintFiles);
    if (!lintFiles.length) return;
    console.log('进入angular的lint');
    const childProcess2 = spawnSync(
      './node_modules/.bin/linter',
      [...lintFiles],
      {
        stdio: 'inherit'
      }
    );
    // 因为是子进程，所以需要手动获取结果，判断是否成功
    process2_status = childProcess2.status;
  };
  const vueLint = (lintFiles: any) => {
    console.log('vue修改的文件:', lintFiles);
    if (!lintFiles.length) return;
    console.log('进入vue的lint');
    const childProcess3 = spawnSync(
      'npm',
      ['run', 'lint', '--', '--no-fix', ...lintFiles],
      {
        cwd: process.cwd() + '/hybrid',
        stdio: 'inherit'
      }
    );
    process3_status = childProcess3.status;
  };

  // angular 同名ctrl检测，需全量
  angularControllerLint();
  if (!files.length) {
    console.log('没有变更文件不执行lint,退出');
    return;
  }
  // angular代码lint
  angularLint(angularFiles);
  // vue代码lint
  vueLint(vueFiles);

  console.log(
    `状态:
      angular同名检测:${process1_status}
      angular lint:${process2_status}
      vue lint:${process3_status}`
  );
  if (process1_status || process2_status || process3_status) {
    process.exit(1);
  }
  process.exit(0);
})();
