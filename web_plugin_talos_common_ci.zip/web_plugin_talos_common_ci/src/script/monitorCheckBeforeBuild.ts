import axios from 'axios';
const path = require('path');
const fs = require('fs');

// 环境变量
const sourcePath = path.resolve('.');
const projectName = process.env.PROJECT_NAME;
const OWLConfigCheck = process.env.OWL_CONFIG_CHECK;
const exceedOWLSDKCheck = process.env.EXCEED_OWL_SDK_CHECK;
const raptorConfigCheck = process.env.RAPTOR_CONFIG_CHECK;
const commonInfoCheck = process.env.COMMON_INFO_CHECK;

// 检查结果以及错误信息
const errors: string[] = [];

// 检查项是否检查完成
const checkComplete = {
  OWLConfigCheck: false,
  commonInfoCheck: false
};

// 需要检查的插件
const fileCheckPlugins = [];
if (OWLConfigCheck === 'true') {
  fileCheckPlugins.push(owlConfigPlugin);
}
if (exceedOWLSDKCheck === 'true') {
  fileCheckPlugins.push(exceedOwlSDKPlugin);
}
if (commonInfoCheck === 'true') {
  fileCheckPlugins.push(commonInfoCheckPlugin);
}

// 搜索文件夹，检查其中每个文件
function checkDirs(filePath: any, plugin: any) {
  const files = fs.readdirSync(filePath);
  files.forEach((file: any) => {
    const currentFilePath = path.join(filePath, file);
    const stats = fs.statSync(currentFilePath);
    const isFile = stats.isFile(); //是文件
    const isDir = stats.isDirectory(); //是文件夹
    if (isDir) {
      checkDirs(currentFilePath, plugin);
    } else if (isFile) {
      checkFile(file, currentFilePath, plugin);
    }
  });
}

/**
 *  对单个文件进行处理
 * */
function checkFile(file: any, filePath: any, plugin: any) {
  // 将每个插件应用在文件处理中
  plugin(file, filePath);
}
/**
 *  获取文件中的指定对象
 * */
function getObject(content: string, objectName: string, mode = 'object') {
  // 定位对象所在位置
  let reg;
  if (mode === 'object') {
    reg = new RegExp(objectName + '[\\s]?\\=[\\s]?');
  } else if (mode === 'json') {
    reg = new RegExp(objectName + '[\\s]?:');
  }
  let start = content.search(reg);
  // 解决括号嵌套问题
  if (start >= 0) {
    const left = content.indexOf('{', start);
    const lefts = [];
    lefts.push(left);
    start = left + 1;
    let right = start;
    while (lefts.length) {
      if (content[start] === '{') {
        lefts.push(start);
      } else if (content[start] === '}') {
        right = start;
        lefts.pop();
      }
      start++;
    }
    return content.slice(left, right + 1);
  }
  return '';
}
/**
 *  启动参数检查：检查owl初始化配置必需的参数是否配置
 *  web端检查html文件中是否有klOwlConfig，klOwlConfig下是否配置了project、webVersion、runtimeEnv这3个必配参数。
 * */
function owlConfigPlugin(file: string, filePath: any) {
  // 检查只针对html文件
  const reg = /\.html|\.ejs$/;
  if (reg.test(file)) {
    const fd = fs.openSync(filePath, 'r');
    owlConfigPluginFileCheck(fd, filePath);
  }
}

function owlConfigPluginFileCheck(fd: any, filePath: string) {
  const content = fs.readFileSync(fd).toString();
  // 提取klOwlConfig
  const klOwlConfig = content.indexOf('klOwlConfig');
  if (klOwlConfig >= 0) {
    const config = getObject(content, 'klOwlConfig');
    console.log('klOwlConfig:', config);
    const result = {
      project: false,
      webVersion: false,
      runtimeEnv: false,
      _OWL_: false,
      window_raptor: false
    };
    result.project = config.indexOf('project') >= 0;
    result.webVersion = config.indexOf('webVersion') >= 0;
    result.runtimeEnv = config.indexOf('runtimeEnv') >= 0;
    result._OWL_ = content.indexOf('_Owl_') >= 0;
    result.window_raptor = content.indexOf('window.raptor = {}') >= 0;
    if (!result._OWL_) {
      errors.push(
        'klOwlConfig检查失败：不存在“_Owl_”。文件路径为：' + filePath
      );
    }
    if (!result.window_raptor) {
      errors.push(
        'klOwlConfig检查失败：不存在“window.raptor = {}”。文件路径为：' +
          filePath
      );
    }
    if (!result.project) {
      errors.push(
        'klOwlConfig检查失败：未配置project。文件路径为：' + filePath
      );
    }
    if (!result.webVersion) {
      errors.push(
        'klOwlConfig检查失败：未配置webVersion。文件路径为：' + filePath
      );
    }
    if (!result.runtimeEnv) {
      errors.push(
        'klOwlConfig检查失败：未配置runtimeEnv。文件路径为：' + filePath
      );
    }
    let checkResult = true;
    Object.values(result).forEach((item) => {
      if (!item) {
        checkResult = false;
      }
    });
    if (checkResult) {
      checkComplete.OWLConfigCheck = checkResult;
    }
  }
}
/**
 *  公共信息检查：检查异常上报自定义信息中是否附加了baseTag - userId
 *
 * */
function commonInfoCheckPlugin(file: string, filePath: any) {
  // 检查只针对html文件
  const reg = /\.html|\.ejs|\.js$/;
  if (reg.test(file)) {
    const fd = fs.openSync(filePath, 'r');
    commonInfoFileCheck(fd, filePath);
  }
}

function commonInfoFileCheck(fd: any, filePath: string) {
  const content = fs.readFileSync(fd).toString();
  // 提取baseTags
  const baseTags = content.indexOf('baseTags');
  if (baseTags >= 0) {
    const config = getObject(content, 'baseTags', 'json');
    console.log('commonInfo:', config);
    const result = {
      userId: false
    };
    result.userId = config.indexOf('userId') >= 0;
    if (!result.userId) {
      errors.push('公共信息检查失败：未配置userId。文件路径为：' + filePath);
    } else {
      checkComplete.commonInfoCheck = true;
    }
  }
}
/**
 *  越权上报检查：检查是否存在越过sdk封装，直接调用Owl.addError等方法
 *  start
 *  config
 *  addError
 *  addPoint
 *  addApi
 *  reportPv
 *  resetPv
 *  自定义指标相关
 *  setDimension
 *  addLog
 *  updateFilter
 *  createInstance
 * */
const OwlAPIs = [
  'Owl.addError',
  'Owl.start',
  'Owl.addPoint',
  'Owl.addApi',
  'Owl.reportPv',
  'Owl.resetPv',
  'Owl.addLog',
  'Owl.updateFilter',
  'Owl.setDimension',
  'Owl.createInstance'
];

function exceedOwlSDKPlugin(file: string, filePath: any) {
  // 检查只针对ts | html | js文件
  const reg = /\.ts|\.ts|\.html|\.vue|\.ejs$/;
  if (reg.test(file)) {
    const fd = fs.openSync(filePath, 'r');
    exceedOwlFileCheck(fd, filePath);
  }
}

function exceedOwlFileCheck(fd: any, filePath: string) {
  const content = fs.readFileSync(fd).toString();
  let result = false;
  OwlAPIs.forEach((API) => {
    result = content.indexOf(API) >= 0;
    if (result) {
      errors.push(
        '越权上报检查失败：使用了非法API: ' + API + ' 文件路径为：' + filePath
      );
    }
  });
}
/**
 *  告警配置检查：检查当前项目是否在raptor配置了告警
 *
 * */
function raptorConfigCheckPlugin(ProjectName: string) {
  return axios
    .get(
      'http://cat.service.sankuai.com/cat/fe/meta/project/listForScene?name=' +
        ProjectName +
        '&scene=PROJECT_VIEW'
    )
    .then((response) => {
      // console.log(response.data);
      const data = response.data;
      if (data.result && data.result.length) {
        return data.result[0].id;
      }
    })
    .then((code) => {
      if (code === 10000) {
        errors.push('告警配置检查失败：projectName不正确，项目不存在');
      } else {
        return axios
          .get(
            'http://cat.service.sankuai.com/raptor/alarmMeta/strategyList?scopeType=frontend-project&scope=' +
              code +
              '&category='
          )
          .then((response) => {
            if (response.data.result && response.data.result.length > 0) {
              console.log('告警配置检查完成');
            } else {
              errors.push('告警配置检查失败：未配置告警或 projectName 不正确');
            }
          })
          .catch((error) => {
            console.warn(error);
          });
      }
    })
    .catch((error) => {
      console.warn(error);
    });
}

function printError() {
  if (OWLConfigCheck && !checkComplete.OWLConfigCheck) {
    errors.push('启动参数检查失败：owl未进行初始化');
  }
  if (commonInfoCheck && !checkComplete.commonInfoCheck) {
    errors.push('公共信息检查：异常上报自定义信息中没有附加 baseTag - userId');
  }
  if (errors.length > 0) {
    errors.forEach((err) => {
      console.log(err);
    });
    process.exit(1);
  } else {
    console.log('全部项目检查完成没有异常');
  }
}
fileCheckPlugins.forEach((plugin) => {
  checkDirs(sourcePath, plugin);
});

if (raptorConfigCheck === 'true') {
  raptorConfigCheckPlugin(projectName).then(() => {
    printError();
  });
} else {
  printError();
}
