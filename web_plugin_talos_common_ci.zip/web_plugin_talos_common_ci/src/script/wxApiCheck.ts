import compareVersion from '../utils/compareVersion';
import { getPortmData } from '../utils/http';
const fs = require('fs');
const rd = require('rd');
const MINI_PROGRAM_VERSION = process.env.MINI_PROGRAM_VERSION || '';
const AWP_MP_BUILD_DIR = process.env.AWP_MP_BUILD_DIR || '';
const IGNOREWXAPILIST = process.env.IGNOREWXAPILIST || '';

const IGNOREPATH = process.env.IGNOREPATH || '';
function getUnavailableAPIList(list: any[]): any[] {
  const res: any = list
    .filter((item: any) => {
      // 过滤掉非wx.*** 的API
      if (!/^(wx\.).+$/.test(item.name)) {
        return false;
      }
      // 可以使用的基础版本高于当前版本;
      if (
        item.baseUse &&
        compareVersion(item.baseUse, MINI_PROGRAM_VERSION) > 0
      ) {
        return true;
      }
      // 当前版本此API已被废弃
      if (
        item.discardUse &&
        compareVersion(item.discardUse, MINI_PROGRAM_VERSION) <= 0
      ) {
        return true;
      }
      return false;
    })
    .sort((a: any, b: any) => {
      if (a.name > b.name) {
        return 1;
      } else {
        return -1;
      }
    });
  return res || [];
}

function readJSFile(path: string) {
  let contentText = '';
  try {
    contentText = fs.readFileSync(path, { encoding: 'utf-8' });
  } catch (error) {
    console.log(error, path, '读取文件异常');
    return '';
  }
  return contentText;
}
async function getPathAndIgnoreApiObj() {
  const pathAndIgnoreApiObj: any = {};
  let pahtAndApiList: string[] = [];
  // 如果有白名单文件portm
  if (IGNOREPATH) {
    const data: any = await getPortmData(IGNOREPATH, 'wxAPI检测白名单', null);
    if (data !== null) {
      const res = Object.keys(data).reduce(
        (acc, cur) => ({ ...acc, [`/${AWP_MP_BUILD_DIR}${cur}`]: data[cur] }),
        {}
      );
      return res;
    }
  }
  pahtAndApiList = IGNOREWXAPILIST.split(',');
  pahtAndApiList.forEach((item: string) => {
    const [path, api] = item.split(':');
    if (path && api) {
      // 输入时相对目录,检测时相对build后路径保持一致增加转换
      const key = `/${AWP_MP_BUILD_DIR}${path}`;
      if (!pathAndIgnoreApiObj[key]) {
        pathAndIgnoreApiObj[key] = {};
      }
      pathAndIgnoreApiObj[key][api] = true;
    }
  });
  return pathAndIgnoreApiObj;
}
function getErrorAPILog(
  unavailableAPIList: any[],
  filesContext: string,
  path: string,
  ignoreApiObj: any
) {
  const errorLogs: any[] = [];
  let lastAPIName = '';
  unavailableAPIList.forEach((item: any) => {
    const { name, url } = item;
    if (ignoreApiObj[name]) {
      console.log(`路径为${path}的文件中，${name}已被忽略检测\n`);
      // 不再进行匹配
      return;
    }
    const pattTemp = new RegExp(name);
    if (pattTemp.test(filesContext)) {
      // 处理API名字类似，只有后几位不相等情况，例如：wx.getStorageSync和 wx.getStorage
      if (new RegExp(lastAPIName).test(name)) {
        errorLogs[errorLogs.length - 1] = {
          ...errorLogs[errorLogs.length - 1],
          longName: name,
          longUrl: url
        };
      } else {
        errorLogs.push({ ...item });
      }
    }
    lastAPIName = name;
  });
  if (!errorLogs.length) {
    return '';
  }

  let log = `路径为${path}的文件中，有以下API：\n`;

  errorLogs.forEach((item) => {
    if (item.longName) {
      log += `${item.name}或${item.longName}不支持使用;详情见官方文档：\n${item.url}\n${item.url}\n`;
    } else {
      log += `${item.name}不支持使用;详情见官方文档：${item.url}\n`;
    }
  });
  return log;
}

function changeDir() {
  console.log(`当前小程序版本:${MINI_PROGRAM_VERSION}`);
  const oldPathStr = process.cwd();
  try {
    // 修改当前node执行目录
    process.chdir(
      `${oldPathStr}/${process.env.AWP_GIT_SLUG || ''}/${
        process.env.projectRoot || ''
      }`
    );
  } catch (error) {
    console.log('执行路径修改报错!');
    process.exit(1);
  }

  const curPathStr = process.cwd();
  return curPathStr;
}
// 数据加工白名单拟合
async function getWXAPIList() {
  const wxAPIObj: any = {};
  const returnData: any[] = [];
  const wxAPIList = await getPortmData(
    'http://portal-portm.meituan.com/kladmin/fe/WXAPIList',
    'getWXAPIList'
  );
  const wxAPIWhiteList = await getPortmData(
    'http://portal-portm.meituan.com/kladmin/fe/WXAPIWhiteList',
    'getWXAPIWhiteList'
  );
  wxAPIList.forEach((el: any) => {
    wxAPIObj[el.name] = el;
  });
  wxAPIWhiteList.forEach((el: any) => {
    wxAPIObj[el.name] = el;
  });
  for (const i in wxAPIObj) {
    returnData.push(wxAPIObj[i]);
  }
  return returnData;
}

(async () => {
  // 修改执行路径
  const curPathStr = changeDir();
  console.log('当前路径:', curPathStr);

  const default_version_patt_check = /^[0-9]{1,}\.[0-9]{1,}.[0-9]{1,}$/;
  if (!default_version_patt_check.test(MINI_PROGRAM_VERSION)) {
    console.log(`版本号:${MINI_PROGRAM_VERSION},不符合三位版本号规范`);
    process.exit(1);
  }

  const wxAPIList = await getWXAPIList();

  if (!wxAPIList.length) {
    console.log('暂无微信小程序API数据，具体请联系yangfan78，退出!');
    process.exit(1);
  }

  const unavailableAPIList: any[] = getUnavailableAPIList(wxAPIList);
  const logs = [];
  const pathAndIgnoreApiObj: any = await getPathAndIgnoreApiObj();
  try {
    // 同步遍历目录下的所有文件
    rd.eachFilterSync(
      AWP_MP_BUILD_DIR,
      /\.js$/,
      function (f: string) {
        // 每找到一个文件都会调用一次此函数
        const context = readJSFile(f);
        const path = f.split(curPathStr)[1];
        const ignoreApiObj = pathAndIgnoreApiObj[path] || {};
        const log = getErrorAPILog(
          unavailableAPIList,
          context,
          path,
          ignoreApiObj
        );
        if (log) {
          console.log(log);
          logs.push(log);
        }
      },
      function (err: any) {
        if (err) throw err;
      }
    );
  } catch (error) {
    console.log('读文件目录错误:', error);
    process.exit(1);
  }

  if (logs.length) {
    console.log('有不支持的API使用了，退出!');
    process.exit(1);
  }
  console.log('测试通过!');
})();
