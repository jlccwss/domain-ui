(() => {
  try {
    // 当前页面是否启用了 cookie
    if (navigator.cookieEnabled) {
      // 用户 随机埋点key
      const klRandomGraySignName = '_kl_random_gray_sign';
      // talos灰度标识key
      const grayFlagName = 'gray_flag';
      // 获取cookie
      const getCookie = function (name: string) {
        const reg = new RegExp(`(^| )${name}=([^;]*)(;|$)`, 'i');
        const r = document.cookie.match(reg);
        if (r && r.length) return decodeURIComponent(r[2]);
        return null;
      };
      // 修改cookie
      const setCookie = function (name: string, tag: number) {
        const interval = 1000 * 60 * 60 * 24 * 365 * 10;
        let docCookie = `${name}=${tag}; expires=${new Date(
          Date.now() + interval
        ).toUTCString()} ;max-age=${interval / 1000}; path=/;`;
        // 在iframe中使用可能会遇到不同域名无法发送cookie 问题,增加SameSite兼容
        if (window.parent !== window && location.protocol === 'https:') {
          docCookie = `${docCookie} SameSite=None; Secure;`;
        }
        document.cookie = docCookie;
      };
      // 校验cookie值是否为一到两位数字 非 -1
      const cookieTagEffect = function (name: string) {
        return /^\d{1,2}$|^-1$/.test(getCookie(name));
      };
      // 强制页面刷新
      const reloadPage = function () {
        window.location.reload(true);
      };

      // 种 klRandomGraySignCookie
      if (!cookieTagEffect(klRandomGraySignName)) {
        setCookie(klRandomGraySignName, Math.floor(Math.random() * 100));
      }

      // 种 taolsGrayFlagCookie
      const klRandomGraySign = getCookie(klRandomGraySignName);
      const oldFlag = cookieTagEffect(grayFlagName)
        ? +getCookie(grayFlagName)
        : 0;
      // horn平台配置的 灰度比例标识
      const grayPrecent = (window.mcc && window.mcc.grayPrecent) || 0;
      const newFlg = grayPrecent - +klRandomGraySign > 0 ? 1 : 0;
      setCookie(grayFlagName, newFlg);
      // 比对 grayFlag 并决定是否刷新
      if (oldFlag !== newFlg) {
        reloadPage();
      }
    }
  } catch (err) {
    setTimeout(function () {
      window.Owl &&
        window.Owl.addError(
          { name: 'TalosGraySet error', msg: (err || {}).message },
          { level: 'error', tags: err }
        );
    }, 2000);
  }
})();
