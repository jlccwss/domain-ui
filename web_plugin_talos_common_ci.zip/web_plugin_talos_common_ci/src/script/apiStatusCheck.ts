/* eslint-disable eqeqeq */
const fs = require('fs');
const path = require('path');
const execSync = require('child_process').execSync;
// const exec = require('child_process').exec;
const readline = require('readline');
const axios = require('axios');
const getAPI = require('@nibfe/talos-public-api').default;

// 环境变量-----------------------------> start
const {
  AWP_GIT_SLUG,
  AWP_MP_BUILD_DIR,
  distApipackages,
  srcApipackages,
  baseUrl,
  tokenKey,
  groupUsers,
  sendRepeatApiWarnMsg
  //   AWP_FLOW_ID
} = process.env;
let tokenValue = process.env.tokenValue;
const AWP_APP_ID: string | number = process.env.AWP_APP_ID;
// AWP_APP_ID = 'test';

// 环境变量-----------------------------> end

let server_cache_name_arr: string[] = []; // 网络读取的方法缓存列表
const local_complied_name_arr: string[] = []; // 本地编译后apipackages目录下的 文件名数组
const upload_local_complied_name_cache: string[] = []; // 本地编译后apipackages目录下的 json cache  上传更新用
const curlMethedApiArr: string[] = []; // 本地新增api列表里 api 状态数组
const skipChekApiDic: { [prop: string]: Array<string> } = {};

// portfile token
const PortmServerApiUrl = 'http://portm.sankuai.com/api/nisper';
const PortmAppKey = 'com.sankuai.kl.mpappsellerapi.httpcodecheck';
const PortmAppSecret = '8d744f5d-f5e2-4171-aee8-6b5f805befe6';
const PortmToken = '06aa6b01-93fe-43ed-a777-c1bc5fc4d086';
const apiNameCacheListFileNetUrl = `http://portal-portm.sankuai.com/api-name-cache-list/${AWP_APP_ID}`;
const projectRoot = `${process.cwd()}`;
const rootProject = `${projectRoot}/${AWP_GIT_SLUG}`;
const compliedApiPackageDir = `${rootProject}/${AWP_MP_BUILD_DIR}`;
const srcApiPackageDir = `${rootProject}/src`;
const apiNameCacheListFile = `${rootProject}/talos-plugin-tmp-api-name-cache-list`;
const distApiFilePathPatterns = distApipackages.split(',');
const srcApiFilePathPatterns = srcApipackages.split(',');

console.log('srcApiFilePathPatterns=>', srcApiFilePathPatterns);
console.log('distApiFilePathPatterns=>', distApiFilePathPatterns);

let checkNum = 0;
let exitCode = 0;

//  talos 大象消息推送
const clientId = 'kl_api_status_check_talos_plugin';
const clientSecret = '1e23806c6a6844ef914ca88ebf65d263';

// 更新上传缓存文件
async function uploadApiNameCacheListFileToPortamServer() {
  const uploadJson = upload_local_complied_name_cache;
  const body = [
    'files.asyncSave',
    {
      type: 1,
      uri: apiNameCacheListFileNetUrl,
      value: JSON.stringify(uploadJson)
    }
  ];
  console.log('body=>', JSON.stringify(body));
  try {
    const { data } = await axios({
      url: PortmServerApiUrl,
      method: 'POST',
      headers: {
        'Portm-AppKey': PortmAppKey,
        'Portm-AppSecret': PortmAppSecret,
        'Portm-token': PortmToken
      },
      data: JSON.stringify(body),
      timeout: 20000
    });
    console.log('data=>', data); // -> 'test'
  } catch (error) {
    console.error('上传接口缓存失败', error);
  }
}

// 网络请求接口获取status码
function curlMethod(methed: string, subPath: string, fileName: string) {
  console.log('\n网络请求接口获取status码  start');
  //   console.log( "subPath =$subPath  \\n  fileName=$fileName  >>>>>>>>>>>>>>>>>>> '
  const fullUrl = `${baseUrl}${subPath}`;
  let http_status = '-1';
  let cmdStr = '';
  let msg = '';
  console.log(`fullUrl = ${fullUrl}`);
  console.log(`token  ${tokenKey}==${tokenValue}`);
  if (methed === 'get') {
    // get请求
    console.log('发送get请求>>>>>>>>>>>>');
    cmdStr = `curl -I --retry 3 --retry-max-time 10 -G -H ''${tokenKey}':'${tokenValue}''  -o /dev/null -w %{http_code}  ${fullUrl}`;
  } else if (methed === 'post') {
    // post请求
    console.log('发送post请求>>>>>>>>>>>>');
    cmdStr = `curl -I --retry 3 --retry-max-time 10  -X POST -H ''${tokenKey}':'${tokenValue}''  -o /dev/null -w %{http_code}  ${fullUrl}`;
  } else {
    console.log('警告 无法确定 请求类型');
  }
  if (!cmdStr) {
    exitCode = 1;
    // console.log('网络请求失败:' + error);
    console.log('cmdStr 为空 filename=' + fileName);
    curlMethedApiArr.push(`${-1}-----无法确定请求类型---------${fileName}`);
    return;
  }
  try {
    const stdout = execSync(cmdStr);
    http_status = stdout.toString('utf8');
    console.log(`请求返回  http_status == ${stdout}`);
    curlMethedApiArr.push(`${http_status}--------------${fileName}`);
    if (http_status !== '200') {
      msg = `\n http_status 为 $http_status 接口未通过 fullUrl=${fullUrl}  fileName=${fileName} \n`;
      console.log(msg);
      exitCode = 1;
    }
    console.log('网络请求接口获取status码  end \n');
  } catch (error) {
    console.log('网络请求失败:' + error);
  }
}

// 逐行读取文件
async function readFile(file: string) {
  console.log('逐行读取文件  start \n');
  const subStr = 'consturl=';
  let subApiPath = '';
  let methed = '';
  let continueLineTimes = 0;
  let cacheLine = '';
  const readStream = fs.createReadStream(file);
  let fileNameExcludeExt = '';
  const rl = readline.createInterface({
    input: readStream,
    output: process.stdout,
    terminal: false
  });
  for await (let line of rl) {
    // readline 输入中的每一行将会在此处作为 `line`。
    // console.log('逐行读取内容=>' + line);
    line = line.replace(/\s+/g, '');
    // console.log('去除空格后' + line);
    if (line.indexOf(subStr) != -1) {
      // 包含consturl=字符串
      line = line.substring(subStr.length);
      // eslint-disable-next-line no-useless-escape
      const disStr = '`';
      line = line.split(disStr)[1];
      console.log(`找到了path = ${line}` + '\nfilename ==>' + file);
      subApiPath = line;
      const arr = file.split('/');
      if (
        Array.isArray(arr) &&
        arr.length > 1 &&
        arr[arr.length - 1].split('.').length > 0
      ) {
        fileNameExcludeExt = arr[arr.length - 1].split('.')[0];
        if (fileNameExcludeExt.substring(0, 3) === 'get') {
          // get请求
          methed = 'get';
        } else if (fileNameExcludeExt.substring(0, 4) === 'post') {
          // post请求
          methed = 'post';
        } else {
          console.log('file名不带请求方式 继续逐行扫描确认请求方式');
        }
        if (methed) {
          curlMethod(methed, subApiPath, fileNameExcludeExt);
          console.log('curlMethod 完毕');
          rl.close();
          readStream.destroy();
          break;
        }
      }
    } else if (subApiPath) {
      //
      // console.log('进入subApiPath' + subApiPath + fileNameExcludeExt + continueLineTimes);
      if (continueLineTimes < 2) {
        cacheLine += line;
        cacheLine = cacheLine.replace(/\s+/g, '');
        if (continueLineTimes == 1) {
          const flagStr = 'return$http.';
          cacheLine = cacheLine.split(flagStr)[1];
          // console.log('cacheLine0' + cacheLine + fileNameExcludeExt);
          cacheLine = cacheLine.split('(')[0];
          // console.log('cacheLine1' + cacheLine + fileNameExcludeExt);
          if (cacheLine === 'get') {
            // get请求
            methed = 'get';
          } else if (cacheLine === 'post') {
            // post请求
            methed = 'post';
          }
          if (methed) {
            curlMethod(methed, subApiPath, fileNameExcludeExt);
          } else {
            exitCode = 1;
            // console.log('网络请求失败:' + error);
            curlMethedApiArr.push(
              `${-1}-----无法确定请求类型---------${fileNameExcludeExt}`
            );
            console.log('file名不带请求方式 再次逐行扫描2行后仍未找到');
          }
          rl.close();
          readStream.destroy();
          break;
        }
        continueLineTimes++;
      }
    }
  }
  rl.close();
  readStream.destroy();
}
//跳过检测的缓存
function pushSkipApiFileNameToCache(fileName: string, filePath: string) {
  if (!fileName || !filePath) {
    return;
  }
  const dic = skipChekApiDic;
  let arr = dic[fileName];
  if (!arr) {
    arr = [];
    dic[fileName] = arr;
  }
  if (arr.length > 0) {
    console.log(`readSrcApiDir 发现重复名称 + ${fileName}`);
  }
  arr.push(filePath);
}

// 递归遍历src文件夹
async function readSrcApiDir(filePath: string) {
  console.log(`递归遍历src文件夹 file = ${filePath} start`);
  // 根据文件路径读取文件，返回文件列表
  const files = fs.readdirSync(filePath);
  if (Array.isArray(files)) {
    for (const filename of files) {
      // 不可用foreach 因为需要同步
      //   console.log('文件名为' + filename);
      const filedir = path.join(filePath, filename);
      const stats = fs.statSync(filedir);
      const isFile = stats.isFile(); // 是文件
      const isDir = stats.isDirectory(); // 是文件夹
      const fileNameExcludeExt = filename.substring(0, filename.indexOf('.'));
      //   console.log('fileNameExcludeExt==' + fileNameExcludeExt);
      if (
        isFile &&
        fileNameExcludeExt &&
        fileNameExcludeExt !== 'index' &&
        isMatchApiFilePathPattern(filedir, true) &&
        local_complied_name_arr.indexOf(fileNameExcludeExt) != -1
      ) {
        if (server_cache_name_arr.indexOf(fileNameExcludeExt) != -1) {
          checkNum++;
          pushSkipApiFileNameToCache(fileNameExcludeExt, filedir);
          //    console.log(`检测到已存在接口 fileName = ${fileNameExcludeExt} \n`);
          //   console.log(`\r检测到已存在接口 checkNUm = ${checkNum} \n`);
        } else {
          console.log(`检测到新增接口 filename = ${fileNameExcludeExt}`);
          try {
            await readFile(filedir);
          } catch (error) {
            exitCode = 1;
            console.log('readFile 错误' + error);
            throw new Error(error);
          }
          console.log('readFile 完毕' + filedir + '\n');
        }
      } else if (
        isDir &&
        filename !== '__types__' &&
        filename !== 'apihub.cache'
      ) {
        try {
          await readSrcApiDir(filedir); // 递归，如果是文件夹，就继续遍历该文件夹下面的文件
        } catch (error) {
          exitCode = 1;
          console.log(error);
          throw new Error(error);
        }
      }
    }
    console.log(`递归遍历src文件夹 file = ${filePath} end`);
  }
}

function pushToUploadCache(value: string) {
  upload_local_complied_name_cache.push(value);
}
function isMatchApiFilePathPattern(filePath: string, isSrcPattern: boolean) {
  let isMatch = false;
  const patterns = isSrcPattern
    ? srcApiFilePathPatterns
    : distApiFilePathPatterns;
  patterns.some((pattern) => {
    const reg = RegExp(`${pattern}`);
    isMatch = reg.test(filePath);
    return isMatch;
  });
  // if (isMatch) {
  //   console.log(`file=>${filePath}`);
  // }
  return isMatch;
}
// 递归遍历编译后的apipackage文件夹生成用到的api数组
function readCompiledApiDir(filePath: string) {
  console.log(`递归遍历编译后的文件夹 file = ${filePath} start`);
  // 根据文件路径读取文件，返回文件列表
  const files = fs.readdirSync(filePath);
  if (Array.isArray(files)) {
    // 遍历读取到的文件列表
    files.forEach((filename) => {
      // 获取当前文件的绝对路径
      //   console.log('文件名为' + filename);
      const filedir = path.join(filePath, filename);
      // 根据文件路径获取文件信息，返回一个fs.Stats对象
      const stats = fs.statSync(filedir);
      const isFile = stats.isFile(); // 是文件
      const isDir = stats.isDirectory(); // 是文件夹
      const fileNameExcludeExt = filename.substring(0, filename.indexOf('.'));
      //   console.log('fileNameExcludeExt==>'+fileNameExcludeExt + 'path.extname==>'+ path.extname(filedir))
      if (
        isFile &&
        path.extname(filedir) === '.js' &&
        fileNameExcludeExt !== 'index' &&
        isMatchApiFilePathPattern(filedir, false)
      ) {
        pushToUploadCache(fileNameExcludeExt);
        if (local_complied_name_arr.indexOf(fileNameExcludeExt) != -1) {
          console.log('发现重复名称' + fileNameExcludeExt);
        }
        local_complied_name_arr.push(`${fileNameExcludeExt}`);
      } else if (isDir) {
        readCompiledApiDir(filedir); // 递归，如果是文件夹，就继续遍历该文件夹下面的文件
      }
    });
  }
  console.log(`递归遍历编译后的文件夹 file = ${filePath} end`);
}

// fetch 网络缓存列表
async function fetchNetApiNameCacheListFile() {
  const promise = new Promise<void>(function (resolve, reject) {
    fs.access(apiNameCacheListFile, fs.constants.F_OK, (err: any) => {
      if (!err) {
        console.log('apiNameCacheListFile文件存在 删除文件从新创建');
        fs.unlinkSync(apiNameCacheListFile);
      }
      const cmdStr = `curl --retry 3 --retry-max-time 10 -o ${apiNameCacheListFile} ${apiNameCacheListFileNetUrl}`;
      try {
        execSync(cmdStr);
        resolve();
        console.log('拉取网络 apiNameCacheListFile 到本地 成功');
      } catch (error) {
        reject(error);
        console.log('获取网络api缓存文件文件失败:' + error);
      }
    });
  });
  return promise;
}
// 读取接口api缓存列表文件
async function getApiNameCacheArr() {
  try {
    await fetchNetApiNameCacheListFile();
  } catch (error) {
    exitCode = 1;
    console.error(error);
    throw new Error(error);
  }
  console.log('读取接口api缓存列表文件 start\n');
  // 拉去网络缓存列表
  let tmp = null;
  try {
    tmp = JSON.parse(fs.readFileSync(apiNameCacheListFile));
  } catch (error) {
    console.log('解析json失败=>' + error);
  } finally {
    if (Array.isArray(tmp)) {
      server_cache_name_arr = tmp;
    }
    fs.unlinkSync(apiNameCacheListFile);
  }
  console.log(
    `读取接口api缓存列表文件 共计 ${server_cache_name_arr.length} 个 end \n`
  );
}

// 发送大像消息
async function sendDXMessage(message: string) {
  // console.log('当前路径=》' + process.cwd());
  const { sendDxPlainMessage } = getAPI({
    clientId,
    clientSecret
  });
  const fainalMessage = message;
  try {
    let users = groupUsers;
    if (AWP_APP_ID == 'test') {
      users = 'wangwei241';
    }
    const result = await sendDxPlainMessage({
      op: users,
      message: fainalMessage
    });
    console.log(result);
  } catch (error) {
    console.error('大象消息发送错误', error);
  }
}

async function getEPToken() {
  console.log('getEPToken');
  const uuid = 'qazxswedcvfr';
  let url = '';
  let login = '';
  let password = '';
  const appid = AWP_APP_ID;

  // eslint-disable-next-line
  if (appid == 6697) {
    url = 'https://epassport.meituan.com/gw/login/password';
    login = 'cggys202107060023';
    password = 'bEt7W7SQ';
  } else if (appid == 'test') {
    url = 'https://fepassport.sjst.test.sankuai.com/gw/login/password';
    login = 'klklsqr';
    password = 'Ceshi123';
  }

  const loginInfo = {
    login: login,
    password: password,
    secondVerify: false,
    requestCode: '',
    responseCode: '',
    utmParam: {
      appKey: 'com.sankuai.klfe.sellermp',
      bgSource: 22,
      platform: 'wxapp',
      uuid
    }
  };
  try {
    const { data } = await axios({
      url: url,
      method: 'POST',
      data: loginInfo,
      timeout: 20000
    });
    // console.log('data=>', data); // -> 'test'
    // const bizInfo = {
    //   bizlogintoken: data.accessToken.accessToken,
    //   bizAcctId: data.bizAcct.id,
    //   bizLogin: data.bizAcct.login,
    //   bizMaskMobile: data.bizAcct.maskMobile,
    //   avatarUrl: '',
    //   uuid
    // };
    tokenValue = data.data.accessToken.accessToken;
    console.log('tokenValue=>' + tokenValue);
  } catch (error) {
    console.log('getEPToken error', error); // -> 'test'
  }
}

//检测跳过检测的api是否有重复
async function checkHasRepeatSkipApiName() {
  console.log('检测是否有重复名称 \n');
  // Object.assign(
  //   skipChekApiDic,
  //   { name1: ['pahth1', 'pahth2'] },
  //   { name2: ['pahth1', 'pahth2'] }
  // );
  const repeatArr = [];
  console.log('skipChekApiDic=>' + JSON.stringify(skipChekApiDic));
  for (const key in skipChekApiDic) {
    const arr = skipChekApiDic[key];
    if (arr.length > 1) {
      repeatArr.push(JSON.stringify({ [key]: arr }));
    }
  }
  if (repeatArr.length > 0) {
    const msg = repeatArr.join('\n');
    console.log('repeatArr=>' + msg);
    try {
      await sendDXMessage(
        `waring ！！！！！！！！！！！！！！！！！检测到有重复名称，请确认接口是否可用\n ${msg}`
      );
    } catch (error) {
      console.error('发送重复api名称消息错误', error);
    }
  }
}
// 开启检测流程
async function checkIncApiStatues() {
  console.log('开启检测流程 当前路径=> ' + process.cwd());
  console.log('rootProject路径=>' + rootProject);
  try {
    process.chdir(rootProject);
    console.log(`切换到 新路径=> ${process.cwd()}`);
  } catch (err) {
    console.error(`chdir: ${err}`);
  }
  console.log('接口检测  start\n');
  try {
    // eslint-disable-next-line
    if (AWP_APP_ID == 6697 || AWP_APP_ID == 'test') {
      await getEPToken();
    }
    await getApiNameCacheArr();
    readCompiledApiDir(compliedApiPackageDir);
    await readSrcApiDir(srcApiPackageDir);
    console.log(`\r检测到已存在接口 checkNUm = ${checkNum} \n`);
  } catch (error) {
    exitCode = 1;
    console.log(error);
  }
  if (sendRepeatApiWarnMsg) {
    try {
      await checkHasRepeatSkipApiName();
    } catch (error) {
      console.error('checkHasRepeatSkipApiName', error);
    }
  }

  if (exitCode == 0) {
    console.log('检测结束  结果 succeed \n');
    if (curlMethedApiArr.length > 0) {
      console.log('有新增接口 开始上传更新缓存文件到portm\n');
      try {
        await uploadApiNameCacheListFileToPortamServer();
      } catch (error) {
        console.error('uploadApiNameCacheListFileToPortamServer err', error);
      }
    }
  } else {
    console.log('检测结束  结果 failure \n');
    const exceptionList: string[] = [];
    curlMethedApiArr.forEach((str) => {
      if (str.indexOf('200') == -1) {
        console.log(str);
        exceptionList.push(str);
      }
    });
    const msg = exceptionList.join('\n');
    try {
      await sendDXMessage(
        `警告！！！！！！！！！！！！！！！！！！！下列接口检测异常\n ${msg}`
      );
    } catch (error) {
      console.error('发送消息错误', error);
    }
  }

  process.exit(exitCode);
}

checkIncApiStatues();

export {}; //解决编译变量重名报错问题
