import * as parse5 from 'parse5';
import axios from 'axios';
import 'allsettled-polyfill';
const path = require('path');
const fs = require('fs');
const rd = require('rd');
// 环境变量
const sourcePath = path.resolve('.');
const scriptCheck = process.env.scriptCheck;
const sourceMapCheck = process.env.sourceMapCheck;
const sourceMapUrl = process.env.SOURCEMAP_PUBLIC_URL;
const checkComplete = {
  // sourceMap 检查为检查到有接入则检查完成 所以初始值为 false
  sourceMapCheck: false,
  // script 检查为检查到有未设置跨域的标签则检查失败 初始值为 true
  scriptCheck: true
};

// 检查结果以及错误信息
const scripts: string[] = [];
const errors: string[] = [];

// 异步 Promises
const promises: any[] = [];

axios.defaults.timeout = 10000;

// 搜索文件夹，检查其中每个文件
function checkDirs(filePath: any, plugin: any, reg: any) {
  rd.eachFilterSync(
    filePath,
    reg,
    function (f: string) {
      plugin(f);
    },
    function (err: any) {
      if (err) throw err;
    }
  );
}

/**
 *  script标签跨域检查
 *  跨域设置检查：构建出来的文件中，script未设置crossorigin属性
 * */

function scriptCheckPlugin(filePath: any) {
  // 检查针对ts | html | js | ejs | vue文件
  const fd = fs.openSync(filePath, 'r');
  scriptPluginFileCheck(fd);
}

function scriptPluginFileCheck(fd: any) {
  const content = fs.readFileSync(fd).toString();
  //提取script标签
  const reg = /<[\b]?script[\b]?[^>]*>[\b]?<\/script>/g;
  const matchScripts = content.match(reg);
  if (matchScripts) {
    matchScripts.forEach((script: any) => scriptPluginTagChecke(script));
  }
}

//检查文件内script标签是否跨域
function scriptPluginTagChecke(script: string) {
  // 生成标签AST获取属性
  const documentFragment = parse5.parseFragment(script);
  // @ts-ignore
  const attrs = documentFragment.childNodes[0].attrs;
  const srcObj = {
    src: '',
    crossorigin: ''
  };
  attrs.forEach((item: { name: string; value: string }) => {
    if (item.name === 'src') {
      srcObj.src = item.value;
    } else if (item.name === 'crossorigin') {
      srcObj.crossorigin = item.value;
    }
  });
  if (srcObj.src) {
    let reg = /^\/\//;
    srcObj.src = reg.test(srcObj.src) ? 'https:' + srcObj.src : srcObj.src;
    reg = /^http/;
    // 如果url是链接且需要设置跨域则需要进行检查
    if (reg.test(srcObj.src) && !srcObj.crossorigin) {
      promises.push(scriptPluginSourceUrlCheck(srcObj.src, script));
    }
  }
}
// 请求 js 文件查看是否需要设置crossorigin
function scriptPluginSourceUrlCheck(url: string, script: string) {
  const timestamp = new Date().getTime();
  if (scripts.indexOf(script) > -1) {
    return Promise.resolve();
  } else {
    scripts.push(script);
  }

  return axios
    .get(url)
    .then((response) => {
      if (response.headers['access-control-allow-origin'] === '*') {
        errors.push('存在script标签未设置 crossorigin , 标签为\n' + script);
        checkComplete.scriptCheck = false;
      }
      const duringTime = (timestamp - new Date().getTime()) / 1000;
      console.log(script);
      console.log('持续时间：', duringTime);
    })
    .catch(() => {
      const duringTime = (new Date().getTime() - timestamp) / 1000;
      console.log(script);
      console.log('请求失败');
      console.log('持续时间：', duringTime);
    });
}
function sourceMapPlugin(filePath: any) {
  if (!checkComplete.sourceMapCheck) {
    const fd = fs.openSync(filePath, 'r');
    console.log('check:', filePath);
    sourceMapPluginFileCheck(fd);
  }
}
function sourceMapPluginFileCheck(fd: any) {
  const content = fs.readFileSync(fd).toString();
  const sourceMapIndex = content.indexOf('//# sourceMappingURL=');
  if (sourceMapIndex >= 0) {
    if (sourceMapUrl) {
      const sourceMapEndIndex = content.indexOf('/n');
      let sourceMapPath;
      if (sourceMapEndIndex > -1) {
        sourceMapPath = content.slice(
          sourceMapIndex + '//# sourceMappingURL='.length,
          sourceMapEndIndex
        );
      } else {
        sourceMapPath = content.slice(
          sourceMapIndex + '//# sourceMappingURL='.length
        );
      }

      const reg = /^((http(s)?:)?\/\/)\w+[^\s]+(\.[^\s]+){1,}$/;
      if (reg.test(sourceMapPath) || reg.test(sourceMapUrl + sourceMapPath)) {
        checkComplete.sourceMapCheck = true;
      } else {
        errors.push(
          'sourceMappingURL不是可请求的链接，存在无效的风险',
          sourceMapPath
        );
      }
    } else {
      checkComplete.sourceMapCheck = true;
    }
  }
}
function checkEnd() {
  console.log('-----------------------------------------------');
  console.log('错误信息记录：');
  if (scriptCheck === 'true' && !checkComplete.sourceMapCheck) {
    errors.push('script 标签跨域设置检查失败');
  }
  if (sourceMapCheck === 'true' && !checkComplete.sourceMapCheck) {
    errors.push('未接入sourceMap或检查路径不正确');
  }
  if (errors.length) {
    errors.forEach((error) => {
      console.log(error);
    });
    process.exit(1);
  }
}
if (sourceMapCheck === 'true') {
  console.log('sourceMap检查开始');
  checkDirs(sourcePath, sourceMapPlugin, /\.js$/);
  console.log('sourceMap检查完成');
}
if (scriptCheck === 'true') {
  console.log('script检查开始');
  checkDirs(sourcePath, scriptCheckPlugin, /\.html$/);
  console.log('script检查完成');
}
// @ts-ignore
Promise.allSettled(promises)
  .then(() => {
    checkEnd();
  })
  .catch((err: any) => {
    checkEnd();
    console.error(err);
  });
