/**
 * web项目标准化检测 https://km.sankuai.com/page/1060474055
 * 第一版：
 * 1.检测新建项目是否使用了非标准框架（vue），如果使用则卡控不能发布
 */
import { getPluginConfig } from '../utils/getConfig';
import talosApis from '../utils/getTalosApis';
const rd = require('rd');

const { execSync } = require('child_process');

/*****
 * 检测当前发布项是否为新项目
 * 调用talos接口查当前项目发布记录，如果有成功发布的prod记录，则为老项目
 * @param {Number} appId talos id
 *  */
async function checkNewProject({ appId }: { appId: string }): Promise<boolean> {
  try {
    // eslint-disable-next-line @typescript-eslint/ban-types
    const { list = [] } = await (talosApis.getAppFlows as Function)({
      id: appId,
      target: 'production'
    });
    const hasDeploy = list.find((item: any) => item.status === 'success');
    return !hasDeploy;
  } catch (error) {
    console.log('检测是否为新项目失败', error);
    return false;
  }
}
// 修改目录
const changeDir = (path = '') => {
  const oldPathStr = process.cwd();
  try {
    // 修改当前node执行目录
    process.chdir(`${oldPathStr}/${path}`);
  } catch (error) {
    console.log('执行路径修改报错!');
    process.exit(1);
  }

  const curPathStr = process.cwd();
  return curPathStr;
};
// const testConfig = {
//   AWP_APP_ID: '8945',
//   projectRoot: './'
// };
const { AWP_APP_ID, projectRoot } = process.env;
(async () => {
  // cd到项目根目录
  execSync(`cd ${projectRoot || ''}`);
  changeDir(projectRoot);

  const { isPass } = await getPluginConfig(
    'CHECK-PROJECT-STANDARD',
    AWP_APP_ID
  );
  if (isPass) {
    console.log(`当前发布项已配置白名单,直接跳过当前插件`);
    process.exit(0);
  }

  const isNewProject = await checkNewProject({ appId: AWP_APP_ID });
  console.log('isNewProject：', isNewProject);
  if (!isNewProject) {
    console.log('存量项目，不需要检测是否使用了标准框架');
    process.exit(0);
  }

  const fileList = rd.readSync('./');

  // 判断是否有.vue文件
  const hasVue = fileList.find((item: string) => /\.vue$/.test(item));
  if (hasVue) {
    console.log(
      '当前为新项目第一次发布,不能使用vue框架，需遵循终端组统一技术栈react/js/ts'
    );
    process.exit(1);
  }

  console.log('项目标准化检测通过');
  process.exit(0);
})();
