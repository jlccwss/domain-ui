/**
 * 2021.0621 自动更新版本号插件进行改造
 * 由sh修改为node
 * 功能变化：
 * 1.不进行打commit和push，在一步在后续插件操作
 * 2.删除自定义文件修改的功能，去掉VERSION_KEYWOEDS、FILEURLS参数
 * 3.执行完成后，通过回调函数传参数，给后续push的http插件
 */
import { postServiceCallback, PluginCallbackPayload } from '../utils/http';
export {};
// eslint-disable-next-line import/first
const { execSync } = require('child_process');
const fs = require('fs');

// const mock: null | any = {
//   AWP_BUSINESS_TYPE: 'web',
//   projectRoot: './',
//   UPDATE_VERSION_TYPE: 'version',
//   CUSTOM_VERSION_NUM: '3.2.225',
//   AWP_COMMENT: '',
//   AWP_GIT_BRANCH_NAME: 'feauture/auto-update-refactor',
//   AWP_OP: 'xxxx',
//   MERGEBRANCH_GROUPID_COMPATIBLE: 'xxxx',
//   FILEURLS: 'sonar-project.properties,./public/version.json',
//   VERSION_KEYWOEDS: `sonar.projectVersion=v,version": "v`,
//   AWP_FLOW_ID: 1332662
// };

const {
  AWP_GIT_BRANCH_NAME,
  AWP_BUSINESS_TYPE,
  AWP_GIT_SLUG,
  AWP_COMMENT,
  projectRoot,
  UPDATE_VERSION_TYPE,
  MERGEBRANCH_GROUPID_COMPATIBLE,
  FILEURLS,
  VERSION_KEYWOEDS,
  CUSTOM_VERSION_NUM,
  AWP_FLOW_ID,
  AWP_OP
} = process.env;
// ！使用测试插件记得修改 正式插件ID：755
const PACKAGE_JSON_FILE = `./package.json`;
// const default_version_patt = '[0-9]{1,}.[0-9]{1,}.[0-9]{1,}';

const default_version_patt_check = /^[0-9]{1,}\.[0-9]{1,}.[0-9]{1,}$/;
let last_version = '';

// 更新package.json
const updateVersion = (type: string, filePath: string, newVersion?: any) => {
  const fileContent = checkPackageJson(filePath);
  if (!fileContent) {
    process.exit(1);
  }
  last_version = fileContent.version;
  console.log(`升级前版本号：${last_version}`);

  const version = newVersion || CUSTOM_VERSION_NUM;

  switch (type) {
    case 'major':
      execSync('npm version major --no-git-tag-version');
      break;
    case 'minor':
      execSync('npm version minor --no-git-tag-version');
      break;
    case 'patch':
      execSync('npm version patch --no-git-tag-version');
      break;
    case 'version':
      if (default_version_patt_check.test(version)) {
        console.log('版本号符合规范');
        execSync(`npm version ${version} --no-git-tag-version`);
      } else {
        console.log('版本号不符合规范:\nhttps://km.sankuai.com/page/573394150');
        process.exit(1);
      }
      break;
    case 'none':
      console.log('不升级版本号');
      break;
  }
};

// 检查文件是否存在于当前目录中
const checkPackageJson = (filePath: string) => {
  try {
    fs.accessSync(filePath, fs.constants.F_OK);
    const file = fs.readFileSync(filePath);
    return JSON.parse(file);
  } catch (error) {
    console.log(`package.json 文件没有找到，请确认projectRoot参数配置`);
    return null;
  }
};

// push代码和tag
const pushCodeAndTag = (lastVersion: string, packageJson: any) => {
  // 获取项目名称
  const PROJECT_NAME = packageJson.name;
  // 获取package.json更新后的版本号
  const NEW_VERSION_STRING = packageJson.version;

  execSync(`git add ${PACKAGE_JSON_FILE}`);
  execSync(
    `git commit -n -m "Merge: ${AWP_OP}: ${PROJECT_NAME}版本号自动升级，从${lastVersion}升级到${NEW_VERSION_STRING}"`
  );

  // 不需要push到仓库的项目类型
  const NOT_NEED_PUSH_LIST = ['MP'];
  if (NOT_NEED_PUSH_LIST.includes(AWP_BUSINESS_TYPE)) {
    console.log(`${AWP_BUSINESS_TYPE}类型项目不push代码到仓库`);
  } else {
    try {
      execSync(`git push origin HEAD:${AWP_GIT_BRANCH_NAME}`);
    } catch (error) {
      console.log('git push 代码时出错', error);
      process.exit(1);
    }
  }

  // tag发布
  const TAG_STR = `v${NEW_VERSION_STRING}`;
  try {
    // 先删除机器上的tag,以防有重复的
    execSync(`git tag | xargs git tag -d`);
    execSync(`git tag ${TAG_STR}`);
    execSync(`git push origin ${TAG_STR}`);
  } catch (error) {
    console.log('git push tag时出错', error);
    process.exit(1);
  }
  console.log(
    `自动升级版本号: ${lastVersion} to ${NEW_VERSION_STRING} successfully.`
  );
  process.exit(0);
};

// 给流水线中插件传参数
const pluginCallback = async (packageJson: any, needUpdateVersion: boolean) => {
  try {
    const params: PluginCallbackPayload = {
      flowId: AWP_FLOW_ID,
      service: 'jenkins',
      stage: process.env.STAGE_NAME,
      status: 'pending',
      params: {
        log: `${needUpdateVersion}?需要更新版本号，并且merge到master:''`,
        globalParams: {
          needUpdateVersion,
          version: packageJson.version,
          PROJECT_NAME: packageJson.name,
          last_version,
          FILEURLS,
          VERSION_KEYWOEDS
        }
      }
    };

    const callBackRes = await postServiceCallback(params);
    console.log(JSON.stringify(callBackRes), '结果');
    if (!callBackRes || callBackRes.statusCode !== 200) {
      console.log('向后续插件传参数失败');
      process.exit(1);
    }
    console.log(`退出`);
    process.exit(0);
  } catch (error) {
    console.log('tryCatch的失败：向后续插件传参数失败', error);
    process.exit(1);
  }
};

// 修改目录
const changeDir = () => {
  const oldPathStr = process.cwd();
  try {
    // 修改当前node执行目录
    process.chdir(
      `${oldPathStr}/${process.env.AWP_GIT_SLUG || ''}/${
        process.env.projectRoot || ''
      }`
    );
  } catch (error) {
    console.log('执行路径修改报错!');
    process.exit(1);
  }

  const curPathStr = process.cwd();
  return curPathStr;
};

// 处理自定义的文件版本更新
const changeCustomFile = (
  fileUrls: string,
  version_keywords: string,
  NEW_VERSION: string
) => {
  const updateCustomVersionPatch = (file: string, keyWord: string) => {
    console.log('更新的匹配文件:', file);
    console.log('更新的文件版本号前缀：', keyWord);
    const content = fs.readFileSync(file).toString();
    fs.writeFileSync(
      file,
      content.replace(
        new RegExp(keyWord + '[0-9]{1,}.[0-9]{1,}.[0-9]{1,}', 'gim'),
        `${keyWord}${NEW_VERSION}`
      )
    );
    execSync(`git add ${file}`);
    console.log('////////////////');
  };
  if (fileUrls && version_keywords) {
    const fileUrlArr = fileUrls.trim().split(',');
    const versionKeyWordArr = version_keywords.trim().split(',');
    console.log(fileUrlArr, versionKeyWordArr);
    if (fileUrlArr.length !== versionKeyWordArr.length) {
      console.log('输入的自定修改文件与关键字数量不匹配');
      console.log('文件', fileUrls);
      console.log('关键字', version_keywords);
      process.exit(1);
    }
    for (let i = 0; i < fileUrlArr.length; i++) {
      console.log('更新的匹配文件：');
      updateCustomVersionPatch(fileUrlArr[i], versionKeyWordArr[i]);
    }
  }
};

// 代码开始执行
(async () => {
  console.log(`当前分支:${AWP_GIT_BRANCH_NAME}`);
  console.log(`看下参数更新类型:${UPDATE_VERSION_TYPE}`);
  if (CUSTOM_VERSION_NUM) {
    console.log('自定义版本号', CUSTOM_VERSION_NUM);
  }
  try {
    execSync(`git config --global user.email "hfe_stash@meituan.com"`);
    execSync(`git config --global user.name "hfe_stash"`);

    if (AWP_BUSINESS_TYPE === 'MP') {
      console.log('小程序项目');
      execSync(`cd ${AWP_GIT_SLUG}/${projectRoot || '.'}`);
      const curPathStr = changeDir();
      console.log('当前路径:', curPathStr);
      const { version } = JSON.parse(AWP_COMMENT);
      console.log(
        JSON.parse(AWP_COMMENT).version,
        JSON.parse(AWP_COMMENT).note,
        '发布信息'
      );
      // 如果不为空，则代表是线上环境发布，有发布版本环境变量
      if (version) {
        updateVersion('version', PACKAGE_JSON_FILE, version);
      } else {
        updateVersion(UPDATE_VERSION_TYPE, PACKAGE_JSON_FILE);
      }
    } else {
      console.log('非小程序项目');
      console.log(process.cwd(), '看下路径');
      execSync(`git fetch origin ${AWP_GIT_BRANCH_NAME} --tags --depth=1`);
      const lastCommitID = execSync(`git rev-parse HEAD`).toString().trim();
      console.log(lastCommitID, 'commitID');
      // 获取某次commitID上的tag
      const curTag = execSync(`git tag --contains ${lastCommitID}`)
        .toString()
        .trim();
      console.log(curTag, '数据');
      if (curTag) {
        console.log(
          `本次发布commitID:${lastCommitID}已有打tag:${curTag}，不进行版本号升级`
        );
        // 需要判断一下是否有merge插件
        if (MERGEBRANCH_GROUPID_COMPATIBLE) {
          await pluginCallback({}, false);
        } else {
          console.log(`退出`);
          process.exit(0);
        }
      }
      updateVersion(UPDATE_VERSION_TYPE, PACKAGE_JSON_FILE);
    }

    const packageJson = checkPackageJson(PACKAGE_JSON_FILE);

    // 处理自定义文件更新
    changeCustomFile(FILEURLS, VERSION_KEYWOEDS, packageJson.version);

    console.log(MERGEBRANCH_GROUPID_COMPATIBLE, '看看merge插件参数默认是什么');

    const needUpdateVersion = UPDATE_VERSION_TYPE === 'none' ? false : true;
    // 如果有最后merge master的插件。则不做push
    if (MERGEBRANCH_GROUPID_COMPATIBLE) {
      console.log('当前工作区版本号已更新为', packageJson.version);
      console.log('在最后merge-master插件再做push操作');
      execSync(`git reset HEAD`);
      await pluginCallback(packageJson, needUpdateVersion);
      return;
    }
    // 如果没有merge master插件，且需要更新版本号，则push
    if (needUpdateVersion) {
      pushCodeAndTag(last_version, packageJson);
      return;
    }
  } catch (error) {
    console.log('更新版本号流程出错', error);
    process.exit(1);
  }
})();
