export {};
const { spawnSync } = require('child_process');
const path = require('path');

function freepackConfigTest() {
  console.log('执行freepack检测脚本\n');
  const result = spawnSync('./node_modules/.bin/xg', [
    'freepack',
    'test',
    '--module-coverage'
  ]);

  if (result.status !== 0) {
    console.log('freepack coverage 命令执行错误，请检查！\n');
    console.log('【INFO】freepack fail');
    console.log(result.stderr.toString());
    process.exit(1);
  }

  const lines = result.stdout.toString().split('\n');
  console.log(lines.join('\n'));

  // 判断是否有未覆盖的文件
  const uncoverLine = lines.some((line: string) =>
    line.includes('Uncover files')
  );
  if (uncoverLine) {
    console.log('上面文件没有被freepack配置文件覆盖，请检查!');
    process.exit(1);
  }
}

function freepack() {
  console.log('执行freepack代码变更操作执行\n');
  const result = spawnSync('./node_modules/.bin/xg', ['freepack'], {
    cwd: path.resolve('.'),
    stdio: 'inherit'
  });
  if (result.status !== 0) {
    console.log('freepack 执行错误，请检查！\n');
    process.exit(1);
  }
}

function reset() {
  console.log('执行reset代码变更操作执行');
  const result = spawnSync('./node_modules/.bin/xg', ['freepack', 'reset'], {
    cwd: path.resolve('.'),
    stdio: 'inherit'
  });
  if (result.status !== 0) {
    console.log('freepack 执行错误，请检查！\n');
    process.exit(1);
  }
}
function codeChangeAfter() {
  console.log('执行hybrid install');
  const result = spawnSync(
    'npm',
    ['install', '--production=false', '--unsafe-perm'],
    {
      // 执行freepack依赖变更此处写死hybrid主要为了不和其他插件产生依赖关联
      cwd: path.resolve('./hybrid'),
      stdio: 'inherit'
    }
  );
  if (result.status !== 0) {
    console.log('hybrid install执行错误，请检查！\n');
    process.exit(1);
  }
}
freepackConfigTest();
freepack();
reset();
codeChangeAfter();
