import getChangedFiles from '../utils/diffFiles';
import { getPluginConfig } from '../utils/getConfig';
const { spawnSync } = require('child_process');
const fs = require('fs');
const rd = require('rd');
const AWP_APP_ID = process.env.AWP_APP_ID || '6135';
const AWP_GIT_SLUG = process.env.AWP_GIT_SLUG;

const vueLintRules = `{
  "extends": [
    "@kl/recommended/vue"
  ]
}`;
const reactLintRules = `{
  "extends": [
    "@kl/recommended/react"
  ]
}`;
const baseLintRules = `{
  "extends": [
    "@kl/recommended/base"
  ]
}`;
const lintRules: { [key: string]: string } = {
  vue: vueLintRules,
  react: reactLintRules,
  base: baseLintRules
};

(async () => {
  // 先判断是否跳过
  let status = 0;
  const { isPass, curAppConfig } = await getPluginConfig(
    'DIFF-LINT',
    AWP_APP_ID
  );
  if (isPass) {
    console.log(`当前发布项:${AWP_GIT_SLUG}\n已配置白名单直接跳过当前插件`);
    process.exit(0);
  }

  const diffFiles = await getChangedFiles();
  let files = [];
  // 不是新项目发布
  if (diffFiles !== 'newProject') {
    files = diffFiles
      .filter((val: string) => /\.(js|ts|jsx|tsx|vue)$/.test(val))
      .filter((val: string) => {
        let flg = false;
        try {
          fs.readFileSync(val, { encoding: 'utf-8' });
          flg = true;
        } catch {}
        return flg;
      });
    if (!files.length) {
      console.log('不执行lint,退出');
      return;
    }
  }

  console.log('///////执行lint//////');
  if (diffFiles !== 'newProject') {
    console.log('需要lint文件:', files);
  } else {
    console.log('全量lint');
  }
  // 如果使用hackLint
  if (curAppConfig?.customConfig?.useLocalScript) {
    const {
      status: useLocalScriptStatus,
      error: useLocalScriptError
    } = spawnSync('npm', ['run', 'lint', ...files], {
      stdio: 'inherit'
    });
    if (useLocalScriptError) {
      console.log(useLocalScriptError);
    } else {
      console.log('使用本地lint script');
    }
    process.exit(useLocalScriptStatus);
  }
  // 如果使用本地lint规则
  if (curAppConfig?.customConfig?.useLocal) {
    const { status: useLocalStatus, error: useLocalError } = spawnSync(
      './node_modules/.bin/eslint',
      [...files],
      {
        stdio: 'inherit'
      }
    );
    if (useLocalError) {
      console.log(useLocalError);
    } else {
      console.log('使用本地lint规则');
    }
    process.exit(useLocalStatus);
  }

  const { stdout: klStdout } = spawnSync('npm', [
    'list',
    '@kl/eslint-config-recommended'
  ]);
  const hasLintNPM = /@kl\/eslint-config-recommended/.test(klStdout.toString());
  if (!hasLintNPM) {
    console.log(
      '当前项目未安装标准lint库，需按照下面文档操作：https://km.sankuai.com/page/738416510#id-%E4%BD%BF%E7%94%A8'
    );
    console.log(
      '如有特殊需求，不需要使用标准lint库检测，请联系大象liuxukang/gaochao20进行沟通配置'
    );
    process.exit(1);
  }

  spawnSync('npm', ['install', '-g', 'eslint'], {
    stdio: 'inherit'
  });

  let lintMode = 'base';
  // 使用标准lint规则
  try {
    const fileList = rd.readSync('./src');
    if (fileList.find((item: string) => /\.vue$/.test(item))) {
      lintMode = 'vue';
    } else if (fileList.find((item: string) => /\.tsx?$/.test(item))) {
      lintMode = 'react';
    } else {
      lintMode = 'base';
    }
  } catch (error) {
    console.log('读文件报错了，lint', error);
  }
  console.log(`使用标准${lintMode}lint规则`);

  const ruleName = 'normalLint.json';
  fs.writeFileSync(ruleName, lintRules[lintMode]);

  status = spawnSync(
    'eslint',
    ['-c', `./${ruleName}`, '--no-eslintrc', ...files, '--quiet'],
    {
      stdio: 'inherit'
    }
  ).status;

  fs.unlinkSync(ruleName);
  process.exit(status);
})();
