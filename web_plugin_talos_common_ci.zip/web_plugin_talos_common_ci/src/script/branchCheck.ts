/**
 * 分支检测
 * 1.分支名是否合法
 * 2.发布分支是否合并最新master
 */
import { getPluginConfig } from '../utils/getConfig';
const { execSync } = require('child_process');
// const envList = ['test01', 'test02', 'newtest', 'staging', 'production'];

type IENV = 'production' | 'staging' | 'test02' | 'test01' | 'newtest';
/**
 * 所有规则内的分支 https://km.sankuai.com/page/631942823
 */
const devPatt = [/^feature\/.*/, /^bugfix\/.*/, /^release\/dev-.*$/];
const testPatt = [
  /^test\/.*(-\d{8})$/,
  /^hotfix\/.*/,
  /^release\/test-.*/,
  /^mergefix\/\d{8}-.*/
];
const stagingPatt = [/^release\/staging(-canary)?$/, /^master$/];
const prodPatt = [
  /^release\/hotfix-.*$/,
  /^release\/\d{8}(-v\d+\.\d+\.\d+)?(-canary)?$/
];

const demoBranch: any = {
  test01: 'feature/231231-xxx',
  test02: 'test/xxx-20210720',
  newtest: 'feature/231231-xxx',
  staging: 'release/staging',
  production: 'release/20210720',
  default: 'feature/231231-xxx'
};
const envPattMap: { [key: string]: RegExp[] } = {
  test01: [...devPatt, ...testPatt, ...stagingPatt, ...prodPatt],
  test02: [...testPatt, ...stagingPatt, ...prodPatt],
  staging: [...stagingPatt, ...prodPatt],
  production: prodPatt,
  default: [...devPatt, ...testPatt, ...stagingPatt, ...prodPatt]
};
const { AWP_GIT_SLUG, projectRoot } = process.env;

const checkByEnv = (name: string, deploy_env: IENV): boolean => {
  const curPatt = envPattMap[deploy_env] || envPattMap.default;
  if (curPatt.some((item: RegExp) => item.test(name))) {
    return true;
  }
  console.log(
    `\n在当前发布环境${deploy_env}，发布分支名：${name}不符合快驴终端组分支规范，符合规范的例子${
      demoBranch[deploy_env] || demoBranch.default
    }`
  );
  return false;
};

const branchChek = (
  branchName: string,
  deploy_env: IENV,
  AWP_BUSINESS_TYPE: string
) => {
  if (deploy_env === 'newtest') {
    return checkByEnv(branchName, 'test01');
  }
  // 如果不是web类型，且不是production环境，则直接认为是dev
  if (AWP_BUSINESS_TYPE !== 'web' && deploy_env !== 'production') {
    return checkByEnv(branchName, 'test01');
  }
  return checkByEnv(branchName, deploy_env);
};

// 修改目录
const changeDir = () => {
  const oldPathStr = process.cwd();
  try {
    // 修改当前node执行目录
    process.chdir(
      `${oldPathStr}/${process.env.AWP_GIT_SLUG || ''}/${
        process.env.projectRoot || ''
      }`
    );
  } catch (error) {
    console.log('执行路径修改报错!');
    process.exit(1);
  }

  const curPathStr = process.cwd();
  return curPathStr;
};
const checkBranchMaster = (branchName: string, AWP_BUSINESS_TYPE: string) => {
  // 小程序需要切换一下目录
  if (AWP_BUSINESS_TYPE === 'MP') {
    execSync(`cd ${AWP_GIT_SLUG}/${projectRoot || '.'}`);
    changeDir();
  }
  execSync(`git fetch origin ${branchName} --unshallow`);
  execSync('git fetch origin master --no-tag --depth=1');
  try {
    execSync(
      `git merge-base --is-ancestor $(git rev-parse --short origin/master) HEAD`
    );
    console.log('已合并过最新master');
    return true;
  } catch (error) {
    console.log('当前分支没有合并过最新master');
    return false;
  }
};

(async () => {
  const branchName = process.env.AWP_GIT_BRANCH_NAME;
  const deploy_env: IENV = (process.env.AWP_DEPLOY_ENV || 'newtest') as IENV;
  const AWP_BUSINESS_TYPE = process.env.AWP_BUSINESS_TYPE;

  const AWP_APP_ID = process.env.AWP_APP_ID;
  console.log(branchName, '当前分支名');
  console.log(deploy_env, '当前发布环境');

  const { isPass } = await getPluginConfig('BRANCH-CHECK', AWP_APP_ID);
  if (isPass) {
    console.log(`当前发布项已配置白名单,直接跳过当前插件`);
    process.exit(0);
  }
  if (process.env.AWP_GIT_REF_TYPE !== 'branch') {
    console.log('目前只支持按照分支发布');
    process.exit(1);
  }

  if (!branchChek(branchName, deploy_env, AWP_BUSINESS_TYPE)) {
    console.log(
      `具体请查看分支规范文档：https://km.sankuai.com/page/862712255`
    );
    console.log('分支检测规则文档：https://km.sankuai.com/page/1060208114');

    process.exit(1);
  }

  console.log('分支名合法！');

  // 泳道和prod不需要 检测是否合并最新master
  if (
    deploy_env !== 'newtest' &&
    !checkBranchMaster(branchName, AWP_BUSINESS_TYPE)
  ) {
    process.exit(1);
  }
  process.exit(0);
})();
