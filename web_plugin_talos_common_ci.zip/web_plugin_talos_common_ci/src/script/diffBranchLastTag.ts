import talosApis from '../utils/getTalosApis';
const fs = require('fs');
(async () => {
  const { spawnSync } = require('child_process');
  spawnSync('npm', ['install', '-g', '@xgfe/diff-tags'], {
    stdio: 'inherit'
  });
  spawnSync('diff-tags', ['-o', 'diff-tags.output.log'], {
    stdio: 'inherit'
  });
  try {
    const groupId = process.env.groupId;
    console.log('groupId', groupId);
    const data = fs.readFileSync('diff-tags.output.log', 'utf8');
    await talosApis.sendDxPlainMessageToGroup({
      id: groupId,
      message: data
    });
  } catch (err) {
    console.log(err);
  }
})();
