/**
 * 插件地址：https://talos.sankuai.com/#/plugin/941/setting
 * Params：
 * onlyCheckTls: 此为校验配置；默认值false, 只check http/ws，不允许存在
 * configUrl：此为校验配置；白名单配置文件，格式参考https://portal-portm.meituan.com/klfe/seller/domainwhitelist.json
 *
 * checkTest：此为域名过滤配置；默认值true，是否检验含有test/dev/st字符串的域名，false会过滤测试域名不检验
 * checkEnterprise：此为域名过滤配置；默认值true，是否检验非公司内域名，false会过滤非公司域名不检验
 **/
const fs = require('fs');
const childProcess = require('child_process');
const path = require('path');
const https = require('https');

const {
  configUrl,
  WORKSPACE = process.cwd(),
  AWP_GIT_SLUG,
  MMP_BUILD_PATH,
  AWP_BUSINESS_TYPE,
  AWP_MP_BUILD_DIR
} = process.env;

let sourcePath = WORKSPACE;

const checkTest = process.env.checkTest === 'false' ? false : true;
const checkEnterprise = process.env.checkEnterprise === 'false' ? false : true;
const onlyCheckTls = process.env.onlyCheckTls === 'false' ? false : true;

const regUrl = /(http|ws)(s)?:\/\/([a-zA-Z0-9.-]+)(\/|'|"|`)/g;
const testRegUrl = /(st|test|dev)/;
const enterpriseRegUrl = /(meituan|sankuai)/;
const legalExt = ['.wxml', '.wxss', '.js', '.wxs', '.html', '.css'];
const isLegalExt = (name: string) =>
  legalExt.some((ext) => ext === path.extname(name));
const findUrls = (str: string) => str.match(regUrl);

if (!onlyCheckTls && !configUrl) {
  console.error('需要白名单配置文件的url');
  process.exit(1);
}

const warnUrls = new Set();
const errUrls = new Set();
let DOMAIN_WHITELIST_URL = new Set();
// 拉取白名单
function getConfiglist() {
  if (onlyCheckTls) {
    return Promise.resolve();
  }
  return new Promise<void>((resolve) => {
    https
      .get(
        configUrl,
        (res: {
          on: (arg0: string, arg1: (response: any) => void) => void;
        }) => {
          res.on('data', (response: { toString: () => string }) => {
            try {
              const data = JSON.parse(response.toString());
              const temp = Object.keys(data).reduce((prev, curr) => {
                return prev.concat(data[curr]);
              }, []);
              DOMAIN_WHITELIST_URL = new Set(temp);
              resolve();
            } catch (e) {
              resolve();
            }
          });
        }
      )
      .on('error', (e: any) => {
        console.error(e);
        errUrls.add('白名单拉取失败！请重试' + configUrl);
        resolve();
      })
      .end();
  });
}

const filter = (urls: any[]) => {
  const u = new Set();
  urls.forEach((item: string) => {
    const url = item.replace(/(\/|'|"|`)$/, '');
    if (!checkTest && testRegUrl.test(url)) {
      warnUrls.add(url);
    } else if (!checkEnterprise && !enterpriseRegUrl.test(url)) {
      warnUrls.add(url);
    } else {
      u.add(url);
    }
  });

  u.forEach((item: string) => {
    if (item.startsWith('http://') || item.startsWith('ws://')) {
      errUrls.add(item);
    } else if (!onlyCheckTls && !DOMAIN_WHITELIST_URL.has(item)) {
      errUrls.add(item);
    }
  });
};

// eslint-disable-next-line @typescript-eslint/ban-types
function walk(current: any, cb: Function) {
  const stat = fs.statSync(current);
  if (stat.isDirectory()) {
    fs.readdirSync(current).forEach((file: any) => {
      walk(path.resolve(current, file), cb);
    });
  } else {
    cb && cb(current);
  }
}

function getMMPDir(tempRoot: string) {
  const tempZip = path.resolve(tempRoot, MMP_BUILD_PATH);
  const tempCheckDir = path.resolve(tempRoot, './tempCheck');
  childProcess.execSync(`unzip -o ${tempZip} -d ${tempCheckDir}`);

  walk(tempCheckDir, (current: string) => {
    if (!current.endsWith('.dio.zip') && current.endsWith('.zip')) {
      // console.log('解压文件:', current);
      childProcess.execSync(`unzip -o ${current} -d ${tempCheckDir}`);
    }
  });
  return tempCheckDir;
}

// 统计结果
function printError() {
  if (warnUrls.size > 0) {
    console.log('发现测试域名，请检测是否前置增加环境变量判断：');
    warnUrls.forEach((err) => {
      console.warn(err);
    });
  }
  if (errUrls.size > 0) {
    console.error('发现不合法域名！请检查：');
    errUrls.forEach((err) => {
      console.error(err);
    });
    process.exit(1);
  } else {
    console.log('域名白名单检查完成，没有异常');
    process.exit(0);
  }
}

if (AWP_BUSINESS_TYPE === 'MP') {
  sourcePath += path.sep + AWP_GIT_SLUG;
  sourcePath = path.resolve(sourcePath, AWP_MP_BUILD_DIR);
} else if (AWP_BUSINESS_TYPE === 'MMP') {
  sourcePath = getMMPDir(sourcePath);
} else {
  sourcePath = path.resolve(sourcePath, './build');
}
console.log('文件路径：', sourcePath);

getConfiglist().then(() => {
  walk(sourcePath, (current: string) => {
    if (isLegalExt(current)) {
      // console.log('校验文件:', current);
      const urls = findUrls(fs.readFileSync(current).toString());
      if (urls && urls.length) {
        filter(urls);
      }
    }
  });
  printError();
});
