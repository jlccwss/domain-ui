import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./pages";
import reportWebVitals from "./reportWebVitals";
import {
  QueryClient,
  QueryClientProvider,
} from "react-query";
import { ConfigProvider } from "antd";
import zh_CN from "antd/lib/locale-provider/zh_CN";

const queryClient = new QueryClient();

ReactDOM.render(
  <ConfigProvider locale={zh_CN}>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </ConfigProvider>,
  document.getElementById("root")
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
