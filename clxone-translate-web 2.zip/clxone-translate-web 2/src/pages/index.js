import React from "react";
import { HashRouter as Router } from "react-router-dom";
import { renderRoutes } from "react-router-config";

import config from "../routes";

export default function App(params) {
  return (
    <Router>
      {renderRoutes(config)}
    </Router>
  );
}
