import React, { useState, useEffect } from "react";
import {
  Table,
  Button,
  Input,
  Space,
  Switch,
  Modal,
  Typography,
  DatePicker,
  Form,
  message,
} from "antd";
import { ExclamationCircleOutlined } from "@ant-design/icons";

import { get, del, post, put } from "../../utils/request";

import dayjs from "dayjs";

const { Text } = Typography;
const { RangePicker } = DatePicker;

export default function AllowList() {
  const [dataSource, setDataSource] = useState([{}]);
  const [loading, setLoading] = useState(false);

  const [page_num, setPageNum] = useState(1);
  const [page_size, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);
  const [parameters, setParameters] = useState("");
  const [count, setCount] = useState(0);

  const [visible, setVisible] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [links, setLinks] = useState({});
  const [isEdit, setIsEdit] = useState(false);
  const [form] = Form.useForm();

  useEffect(() => {
    if (!visible) {
      form.resetFields();
    }
  }, [form, visible]);

  useEffect(() => {
    setLoading(true);
    get("/apis/linkingthing.com/auth/v1/whitelists/whitelist/whitelistips", {
      page_num,
      page_size,
      ip: parameters,
    })
      .then(({ data, links, pagination }) => {
        setDataSource(data);
        setPageNum(pagination.pageNum);
        setTotal(pagination.total);
        setLinks(links);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [count, page_num, page_size, parameters]);

  function handleSearch() {
    setCount(count + 1);
  }

  function handleOk() {
    const params = form.getFieldsValue(true);
    params.isEnabled = true;
    setConfirmLoading(true);
    post(links.self, params)
      .then((res) => {
        message.success("创建成功");
        setVisible(false);
        setCount(count + 1);
      })
      .catch((err) => {
        message.error(err.response.message);
      })
      .finally(() => {
        setConfirmLoading(false);
      });
  }

  // function handleToggle(record) {
  //   console.log(record);
  //   put(record.links.remove, {
  //     isEnabled: record.isEnabled,
  //     ip: record.ip
  //   })
  //     .then((res) => {

  //     })
  //     .catch((err) => {
  //       message.error(err.response.message);
  //     });
  // }
  function handleDelete(record) {
    Modal.confirm({
      title: "删除确认",
      icon: <ExclamationCircleOutlined />,
      content: "点击确认后将继续删除该记录",
      onOk: () => {
        del(record.links.remove)
          .then(() => {
            message.success("删除成功");
            setCount(count + 1);
          })
          .catch((err) => {
            message.error(err.response.message);
          });
      },
    });
  }
  const columns = [
    {
      title: "IP",
      dataIndex: "ip",
    },
    // {
    //   title: "是否启用",
    //   dataIndex: "isEnabled",
    //   render: (text, row) => {
    //     return (
    //       <Switch
    //         checkedChildren="开启"
    //         unCheckedChildren="关闭"
    //         onClick={() => handleToggle(row)}
    //       />
    //     );
    //   },
    // },
    {
      title: "操作",
      dataIndex: "action",
      render: (text, record) => (
        <>
          <Text
            style={{ color: "#1890ff", cursor: "pointer" }}
            onClick={() => handleDelete(record)}
          >
            删除
          </Text>
        </>
      ),
    },
  ];

  const pagination = {
    current: page_num,
    pageSize: page_size,
    total: total,
    showSizeChanger: false,
    onChange: (page, pageSize) => {
      setPageNum(page);
      setPageSize(pageSize);
    },
  };
  return (
    <div>
      <div className="search-bar">
        <div className="right">
          <Input
            placeholder="请输入关键字搜索"
            className="input-width"
            onChange={(e) => setParameters(e.target.value.trim())}
            allowClear
          />
          <Button type="primary" onClick={handleSearch}>
            查询
          </Button>
          <Button
            type="primary"
            onClick={() => setVisible(true)}
            style={{ marginLeft: "20px" }}
          >
            新增
          </Button>
        </div>
      </div>
      <Modal
        title={isEdit ? "编辑" : "新增"}
        getContainer={false}
        visible={visible}
        onOk={handleOk}
        confirmLoading={confirmLoading}
        onCancel={() => setVisible(false)}
        forceRender
      >
        <Form
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 18 }}
          layout="horizontal"
          form={form}
        >
          <Form.Item label="IP" name="ip">
            <Input placeholder="例如：240e:a:b::12或者240e:a:b::1-240e:a:b::ffff" />
          </Form.Item>
        </Form>
      </Modal>

      <Table
        dataSource={dataSource}
        columns={columns}
        loading={loading}
        pagination={pagination}
        rowKey={(record) => record.id}
      />
    </div>
  );
}
