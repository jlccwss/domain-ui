import React, { useState, useEffect } from "react";
import {
  Skeleton,
  Space,
  Modal,
  message,
  Button,
  Form,
  Select,
  Input,
  Checkbox,
  Typography,
  Pagination,
  Empty,
} from "antd";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import { get, del, post, put, getUrlByPath } from "../../utils/request";
import { mapToOptions } from "../../utils/helper";
import { upgradeMode, funMap } from "../../config";
import * as ImageData from "../../assets";

import Website from "../Website";
const { Title, Text } = Typography;

// import * as rq from "react-query";

// console.log(rq)

export default function Ipv6ApplicationUpgrade({ route }) {
  const [visible, setVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const [count, setCount] = useState(0);
  const [page_num, setPageNum] = useState(1);
  const [page_size] = useState(10);
  const [total, setTotal] = useState(0);
  const [dataSource, setDataSource] = useState([]);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [vips, setVips] = useState([]);
  const [links, setLinks] = useState({});
  const [currentLinks, setCurrentLinks] = useState({});

  const [isEdit, setIsEdit] = useState(false);
  const [searchName, setSearchName] = useState("");

  const [form] = Form.useForm();

  // Access the client
  // const queryClient = useQueryClient();

  // Queries
  // const query = useQuery("todos", get("/clusters/001/webgroups"));

  // console.log(query)

  // Mutations
  // const mutation = useMutation(postTodo, {
  //   onSuccess: () => {
  //     // Invalidate and refetch
  //     queryClient.invalidateQueries("todos");
  //   },
  // });

  useEffect(() => {
    get(
      "/apis/linkingthing.com/business/v1/clusters/001/balances/001/availablevips/availablevip",
      {
        availableipcount: 5,
      }
    )
      .then(({ vips }) => {
        if (Array.isArray(vips)) {
          setVips(vips);
        } else {
          setVips([]);
        }
      })
      .finally(() => {});
  }, []);

  useEffect(() => {
    if (!visible) {
      form.resetFields();
    }
  }, [form, visible]);

  useEffect(() => {
    setLoading(true);
    get("/apis/linkingthing.com/business/v1/clusters/001/websitegroups", {
      page_num,
      page_size,
      name: searchName,
    })
      .then(({ data, links, pagination }) => {
        setDataSource(data);
        setLinks(links);
        setPageNum(pagination.pageNum);
        setTotal(pagination.total);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [count, page_num, page_size]);

  function handleSearch() {
    setCount(count + 1);
  }

  function handleOk() {
    const params = { ...form.getFieldsValue(true) };
    params.clusterid = "001";

    const funArr = Object.keys(funMap);
    const updateSwitch = params.updateSwitch ? [...params.updateSwitch] : [];
    params.updateSwitch = {};
    funArr.forEach((item) => {
      params.updateSwitch[item] = updateSwitch.includes(item);
    });

    setConfirmLoading(true);

    if (isEdit) {
      put(currentLinks.self, params)
        .then((res) => {
          message.success("编辑成功");
          setVisible(false);
          setCount(count + 1);
        })
        .catch((err) => {
          message.error(err.response.message);
        })
        .finally(() => {
          setConfirmLoading(false);
        });
    } else {
      post(links.self, params)
        .then((res) => {
          message.success("创建成功");
          setVisible(false);
          setCount(count + 1);
        })
        .catch((err) => {
          message.error(err.response.message);
        })
        .finally(() => {
          setConfirmLoading(false);
        });
    }
  }

  function handleEdit(record) {
    setVisible(true);
    setIsEdit(true);
    get(record.links.self).then(
      ({ name, domain, ipv6Addr, updateSwitch, links }) => {
        setCurrentLinks(links);
        form.setFields([
          {
            name: ["name"],
            value: name,
          },
          {
            name: ["domain"],
            value: domain,
          },
          {
            name: ["ipv6Addr"],
            value: ipv6Addr,
          },
          {
            name: ["updateSwitch"],
            value: Object.keys(updateSwitch).filter(
              (item) => updateSwitch[item]
            ),
          },
        ]);
      }
    );
  }

  function handleDelete(record) {
    Modal.confirm({
      title: "删除确认",
      icon: <ExclamationCircleOutlined />,
      content: "点击确认后将继续删除该记录",
      onOk: () => {
        del(record.links.remove)
          .then(() => {
            message.success("删除成功");
            setCount(count + 1);
          })
          .catch((err) => {
            message.error(err.response.message);
          });
      },
    });
  }

  function handlePageChange(current) {
    setPageNum(current);
  }

  const plainOptions = mapToOptions(funMap);

  const ipv6Options = vips.map((item) => {
    return {
      label: item,
      value: item,
    };
  });

  return (
    <div>
      <div className="page-title">{route.title}</div>

      <div className="search-bar">
        <Button
          type="primary"
          className="right"
          style={{ marginLeft: "20px" }}
          onClick={() => {
            setVisible(true);
            setIsEdit(false);
          }}
        >
          新增配置组
        </Button>
        <div className="right">
          <Input
            placeholder="请输入应用名"
            className="input-width"
            onChange={(e) => setSearchName(e.target.value.trim())}
            allowClear
          />
          <Button type="primary" onClick={handleSearch}>
            查询
          </Button>
        </div>
      </div>
      <Modal
        title={isEdit ? "编辑" : "新增"}
        getContainer={false}
        visible={visible}
        onOk={handleOk}
        confirmLoading={confirmLoading}
        onCancel={() => setVisible(false)}
        forceRender
      >
        <Form
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 18 }}
          layout="horizontal"
          form={form}
        >
          <Form.Item label="名称" name="name">
            <Input />
          </Form.Item>
          <Form.Item label="域名" name="domain">
            <Input disabled={isEdit} />
          </Form.Item>
          <Form.Item label="功能开关" name="updateSwitch">
            <Checkbox.Group options={plainOptions} />
          </Form.Item>
          <Form.Item label="IPv6地址" name="ipv6Addr">
            <Select options={ipv6Options} allowClear />
          </Form.Item>
        </Form>
      </Modal>

      <div className="website-group">
        {Boolean(dataSource.length) || (
          <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
        )}
        <Skeleton loading={loading} active>
          {dataSource.map((data) => {
            return (
              <div className="website-item" key={data.id}>
                <div className="website-header">
                  <Title className="website-header-title m-title" level={4}>
                    {data.name}
                  </Title>
                  <Space size="middle">
                    <Text>
                      域名： <span>{data.domain}</span>
                    </Text>
                    <Text>
                      IPv6地址： <span>{data.ipv6Addr}</span>{" "}
                    </Text>
                  </Space>

                  <img
                    className="websitegroup-operate"
                    style={{ marginLeft: "auto" }}
                    src={ImageData.del}
                    alt="del"
                    onClick={() => handleDelete(data)}
                  />
                  <img
                    className="websitegroup-operate"
                    src={ImageData.edit}
                    alt="edit"
                    onClick={() => handleEdit(data)}
                  />
                </div>

                <Website data={data} />
              </div>
            );
          })}
          <div className="m-overflow">
            <Pagination
              className="right"
              total={total}
              current={page_num}
              onChange={handlePageChange}
            />
          </div>
        </Skeleton>
      </div>
    </div>
  );
}
