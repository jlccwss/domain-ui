import React, { useState, useEffect } from "react";
import {
  Table,
  Button,
  Input,
  message,
  Modal,
  Typography,
  DatePicker,
} from "antd";
import { get, post } from "../../utils/request";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import DownloadFile from "../../components/DownloadFile";

import dayjs from "dayjs";

const { Text } = Typography;
const { RangePicker } = DatePicker;

export default function Log({ route }) {
  const [dataSource, setDataSource] = useState([]);
  const [loading, setLoading] = useState(false);

  const [page_num, setPageNum] = useState(1);
  const [page_size, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);
  const [parameters, setParameters] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [count, setCount] = useState(0);
  const [links, setLinks] = useState({});

  const [attackType, setAttackType] = useState("");
  const [clientip, setClientip] = useState("");
  const [url, setUrl] = useState("");

  useEffect(() => {
    setLoading(true);
    get("/apis/linkingthing.com/log/v1/waflogs", {
      page_num,
      page_size,
      from,
      to,
      parameters,
      attackType,
      clientip,
      url,
    })
      .then(({ data, links, pagination }) => {
        setDataSource(data);
        setPageNum(pagination.pageNum);
        setPageSize(pagination.pageSize);
        setTotal(pagination.total);

        setLinks(links);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [
    count,
    page_num,
    page_size,
    from,
    to,
    parameters,
    attackType,
    clientip,
    url,
  ]);

  function handleSearch() {
    setCount(count + 1);
  }

  function handleChangeData(_, dateStr) {
    const [from, to] = dateStr;
    setFrom(from);
    setTo(to);
  }

  function handleDelete(record) {
    Modal.confirm({
      title: "拉黑确认",
      icon: <ExclamationCircleOutlined />,
      content: "点击确认后将继续拉黑该IP",
      onOk: () => {
        post(
          "/apis/linkingthing.com/business/v1/clusters/001/blacklists/blacklist/blacklistips",
          {
            ip: record.clientip,
          }
        )
          .then(() => {
            message.success("拉黑成功");
            setCount(count + 1);
          })
          .catch((err) => {
            message.error(err.response.message);
          });
      },
    });
  }

  const columns = [
    {
      title: "攻击拦截时间",
      dataIndex: "time",
      render: (text) => {
        return <span>{dayjs(text).format("YYYY-MM-DD HH:mm:ss")}</span>;
      },
    },
    {
      title: "攻击源IP",
      dataIndex: "clientip",
    },
    {
      title: "攻击目标",
      dataIndex: "url",
    },
    {
      title: "攻击类型",
      dataIndex: "attackType",
    },
    {
      title: "操作",
      dataIndex: "action",
      render: (text, record) => {
        return (
          <Text
            style={{ color: "#1890ff", cursor: "pointer" }}
            onClick={() => handleDelete(record)}
          >
            拉黑
          </Text>
        );
      },
    },
  ];

  const pagination = {
    current: page_num,
    pageSize: page_size,
    total: total,
    showSizeChanger: false,
    onChange: (page, pageSize) => {
      setPageNum(page);
      setPageSize(pageSize);
    },
  };
  return (
    <div>
      <div className="page-title">{route.title}</div>
      <div className="search-bar">
        <div className="right">
          <RangePicker onChange={handleChangeData} />
          <Input
            placeholder="请输入攻击源IP搜索"
            className="input-width"
            onChange={(e) => setClientip(e.target.value.trim())}
            allowClear
          />
          <Input
            placeholder="请输入攻击目标搜索"
            className="input-width"
            onChange={(e) => setUrl(e.target.value.trim())}
            allowClear
          />
          <Input
            placeholder="请输入攻击类型搜索"
            className="input-width"
            onChange={(e) => setAttackType(e.target.value.trim())}
            allowClear
          />
          <Button type="primary" onClick={handleSearch}>
            查询
          </Button>
          <DownloadFile
            links={links}
            params={{
              from,
              to,
              attackType,
              clientip,
              url,
            }}
          />
        </div>
      </div>
      <Table
        dataSource={dataSource}
        columns={columns}
        loading={loading}
        pagination={pagination}
        rowKey={(record) => record.id}
      />
      ;
    </div>
  );
}
