import React, { useState, useEffect } from "react";
import {
  Table,
  Space,
  Button,
  Modal,
  message,
  Form,
  Input,
  Select,
  Typography,
} from "antd";
import { get, del, post, put } from "../../utils/request";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import UploadCertModal from "./UploadCertModal";
const { Text } = Typography;

export default function Website({ data }) {
  const [links, setLinks] = useState({});
  const [dataSource, setDataSource] = useState([]);
  const [loading, setLoading] = useState(false);
  const [visible, setVisible] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [count, setCount] = useState(0);
  const [currentLinks, setCurrentLinks] = useState({});

  const [isEdit, setIsEdit] = useState(false);
  const [form] = Form.useForm();

  const [cvisible, setCvisible] = useState(false);
  const [confirmCLoading, setConfirmCLoading] = useState(false);
  const [record, setRecord] = useState({});

  useEffect(
    function getData() {
      setLoading(true);
      get(data.links.websites)
        .then(({ data, links }) => {
          setDataSource(data);
          setLinks(links);
        })
        .finally(() => {
          setLoading(false);
        });
    },
    [count, data.links.websites]
  );

  function handleOk() {
    const params = form.getFieldsValue(true);

    params.protocolPorts = [
      {
        destPort: +params.ports,
        destProtocol: params.protocol,
        sourcePort: +params.ports,
        sourceProtocol: params.protocol,
      },
    ];
    setConfirmLoading(true);

    if (isEdit) {
      put(currentLinks.self, params)
        .then((res) => {
          message.success("编辑成功");
          setVisible(false);
          setCount(count + 1);
        })
        .catch((err) => {
          message.error(err.response.message);
        })
        .finally(() => {
          setConfirmLoading(false);
        });
    } else {
      post(data.links.websites, params)
        .then((res) => {
          message.success("创建成功");
          setVisible(false);
          setCount(count + 1);
        })
        .catch((err) => {
          message.error(err.response.message);
        })
        .finally(() => {
          setConfirmLoading(false);
        });
    }
  }

  function handleSaveCOk(form) {
    const params = form.getFieldsValue(true);
    setConfirmCLoading(true);
    post("/apis/linkingthing.com/business/v1/clusters/001/httpskeys", params)
      .then((res) => {
        message.success("上传成功");
        setCvisible(false);
        setCount(count + 1);
      })
      .catch((err) => {
        message.error(err.response.message);
      })
      .finally(() => {
        setConfirmCLoading(false);
      });
  }

  function handleEdit(record) {
    setVisible(true);
    setIsEdit(true);
    get(record.links.self).then(
      ({ sourceDomain, destDomain, ipv6Addr, protocolPorts, links }) => {
        let ports, protocol;
        if (Array.isArray(protocolPorts) && protocolPorts.length) {
          const [{ destPort, destProtocol }] = protocolPorts;
          ports = destPort;
          protocol = destProtocol;
        }

        setCurrentLinks(links);
        form.setFields([
          {
            name: ["sourceDomain"],
            value: sourceDomain,
          },
          {
            name: ["destDomain"],
            value: destDomain,
          },
          {
            name: ["ipv6Addr"],
            value: ipv6Addr,
          },

          {
            name: ["protocol"],
            value: protocol,
          },
          {
            name: ["ports"],
            value: ports,
          },
        ]);
      }
    );
  }

  function handleDelete(record) {
    Modal.confirm({
      title: "删除确认",
      icon: <ExclamationCircleOutlined />,
      content: "点击确认后将继续删除该记录",
      onOk: () => {
        del(record.links.remove)
          .then(() => {
            message.success("删除成功");
            setCount(count + 1);
          })
          .catch((err) => {
            message.error(err.response.message);
          });
      },
    });
  }

  function handleUploadCertificate(record) {
    setRecord(record);
    setCvisible(true);
  }

  function handleDeleteCertificate(record) {
    Modal.confirm({
      title: "删除确认",
      icon: <ExclamationCircleOutlined />,
      content: "点击确认后将继续删除该证书",
      onOk: () => {
        del(
          `/apis/linkingthing.com/business/v1/clusters/001/httpskeys/${record.id}`
        )
          .then(() => {
            message.success("删除成功");
            setCount(count + 1);
          })
          .catch((err) => {
            message.error(err.response.message);
          });
      },
    });
  }

  const columns = [
    {
      title: "网站域名",
      dataIndex: "sourceDomain",
    },
    {
      title: "目标域名",
      dataIndex: "destDomain",
    },

    {
      title: "协议",
      dataIndex: "protocolPorts",
      render: (text) => {
        if (Array.isArray(text) && text.length) {
          const [{ destPort, destProtocol }] = text;
          return (
            <span>
              {destProtocol}/{destPort}
            </span>
          );
        } else {
          return <span>-</span>;
        }
      },
    },
    {
      title: "IPv6地址",
      dataIndex: "ipv6Addr",
    },
    {
      title: "证书",
      dataIndex: "isUploadCertFile",
      render: (text, record) => {
        return text ? "已上传" : "未上传";
      },
    },

    {
      title: "操作",
      key: "action",
      render: (text, record) => {
        let showUpload = false;

        if (
          Array.isArray(record.protocolPorts) &&
          record.protocolPorts.length
        ) {
          const [{ destProtocol }] = record.protocolPorts;
          if (destProtocol === "https") {
            showUpload = true;
          }
        }
        return (
          <Space size="middle">
            <Text
              style={{ color: "#1890ff", cursor: "pointer" }}
              onClick={() => handleEdit(record)}
            >
              编辑
            </Text>
            <Text
              style={{ color: "#1890ff", cursor: "pointer" }}
              onClick={() => handleDelete(record)}
            >
              删除
            </Text>
            <Text
              style={{
                color: "#1890ff",
                cursor: "pointer",
                display: showUpload ? "block" : "none",
              }}
              onClick={() => handleUploadCertificate(record)}
            >
              上传证书
            </Text>
            <Text
              style={{
                color: "#1890ff",
                cursor: "pointer",
                display: showUpload ? "block" : "none",
              }}
              onClick={() => handleDeleteCertificate(record)}
            >
              删除证书
            </Text>
          </Space>
        );
      },
    },
  ];

  const uploadCertModalProps = {
    cvisible,
    confirmCLoading,
    record,
    setCvisible,
    handleSaveCOk,
  };

  return (
    <div>
      <Modal
        title={isEdit ? "编辑" : "新增"}
        visible={visible}
        onOk={handleOk}
        confirmLoading={confirmLoading}
        onCancel={() => setVisible(false)}
      >
        <Form
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 18 }}
          layout="horizontal"
          form={form}
        >
          <Form.Item label="网站域名" name="sourceDomain">
            <Input />
          </Form.Item>
          <Form.Item label="目标域名" name="destDomain">
            <Input />
          </Form.Item>

          <Form.Item label="协议" name="protocol">
            <Select>
              <Select.Option value="http">http</Select.Option>
              <Select.Option value="https">https</Select.Option>
            </Select>
          </Form.Item>
          <Form.Item label="端口" name="ports">
            <Input />
          </Form.Item>
        </Form>
      </Modal>

      <UploadCertModal {...uploadCertModalProps} />

      <Table
        bordered
        dataSource={dataSource}
        columns={columns}
        loading={loading}
        pagination={false}
        rowKey={(record) => record.id}
      />
      <div className="m-overflow" style={{ marginTop: "20px" }}>
        <Button
          type="primary"
          className="right"
          onClick={() => {
            setIsEdit(false);
            form.resetFields();
            setVisible(true);
          }}
        >
          新建
        </Button>
      </div>
    </div>
  );
}
