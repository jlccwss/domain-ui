import React, { useEffect } from "react";
import { Modal, Form, Input, Upload, Button } from "antd";
import { get } from "../../utils/request";

export default function UploadCertModal({
  cvisible,
  handleSaveCOk,
  confirmCLoading,
  setCvisible,
  record,
}) {
  const [form] = Form.useForm();
  const { id } = record;

  useEffect(() => {
    form.setFields([
      {
        name: ["domainID"],
        value: id,
      },
    ]);
  }, [form, id]);

  useEffect(() => {
    if (cvisible) {
      get(
        `/apis/linkingthing.com/business/v1/clusters/001/httpskeys/${id}`
      ).then(({ privateKeyContent, privateKeyName, certName, certContent }) => {
        form.setFields([
          {
            name: ["privateKeyName"],
            value: privateKeyName,
          },
          {
            name: ["privateKeyContent"],
            value: privateKeyContent,
          },
          {
            name: ["certName"],
            value: certName,
          },
          {
            name: ["certContent"],
            value: certContent,
          },
        ]);
      });
    }
  }, [cvisible, id]);

  const certProps = {
    name: "file",
    fileList: [],
    beforeUpload(file) {
      const reader = new FileReader();
      reader.onload = function (event) {
        form.setFields([
          {
            name: ["certName"],
            value: file.name,
          },
          {
            name: ["certContent"],
            value: event.target.result,
          },
        ]);
      };
      reader.readAsText(file);
      return false;
    },
  };

  const keyProps = {
    name: "file",
    fileList: [],
    beforeUpload(file) {
      const reader = new FileReader();
      reader.onload = function (event) {
        form.setFields([
          {
            name: ["privateKeyName"],
            value: file.name,
          },
          {
            name: ["privateKeyContent"],
            value: event.target.result,
          },
        ]);
      };
      reader.readAsText(file);
      return false;
    },
  };

  return (
    <Modal
      title="上传证书"
      visible={cvisible}
      onOk={() => handleSaveCOk(form)}
      confirmLoading={confirmCLoading}
      onCancel={() => setCvisible(false)}
    >
      <Form form={form} labelCol={{ span: 4 }} wrapperCol={{ span: 18 }}>
        <Form.Item label="域名" name="domainID">
          <Input disabled />
        </Form.Item>

        <Form.Item label="证书" name="cert">
          <Upload {...certProps}>
            <Button>上传证书</Button>
          </Upload>
        </Form.Item>
        <Form.Item label="证书名" name="certName">
          <Input disabled />
        </Form.Item>
        <Form.Item style={{ display: "none" }} label="证书" name="certContent">
          <Input />
        </Form.Item>
        <Form.Item label="秘钥" name="key">
          <Upload {...keyProps}>
            <Button>上传秘钥</Button>
          </Upload>
        </Form.Item>
        <Form.Item label="密钥名" name="privateKeyName">
          <Input disabled />
        </Form.Item>
        <Form.Item
          style={{ display: "none" }}
          label="密钥"
          name="privateKeyContent"
        >
          <Input />
        </Form.Item>
      </Form>
    </Modal>
  );
}
