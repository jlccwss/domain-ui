import React from "react";
import {
  Chart,
  Line,
  Point,
  Tooltip,
  Axis,
  Interaction,
  Legend,
  Interval,
  Annotation,
  Facet,
  Rect,
  Geom,
} from "bizcharts";
import DataSet from "@antv/data-set";

export default function FlowBar({ deviceInfo }) {
  const { v4DownFlow, v4UpFlow, v6DownFlow, v6UpFlow } = deviceInfo;
  const datat = [
    { name: "IPv4 下行", type: "IPv4", data: 18.9 },
    { name: "IPv4 上行", type: "IPv4", data: 35.6 },
    { name: "IPv6 下行", type: "IPv6", data: 12.4 },
    { name: "IPv6 上行", type: "IPv6", data: 42.4 },
  ];

  const datad = [
    { name: "IPv4 下行", type: "IPv4", data: +v4DownFlow },
    { name: "IPv4 上行", type: "IPv4", data: +v4UpFlow },
    { name: "IPv6 下行", type: "IPv6", data: +v6DownFlow },
    { name: "IPv6 上行", type: "IPv6", data: +v6UpFlow },
  ];


  const scale = {
    data: {
      alias: "流量", // 为属性定义别名
    },
  };
  return (
    <Chart
      height={260}
      data={datad}
      scale={scale}
      autoFit
      padding={[50, 20, 50, 90]}
    >
      <Axis
        name="data"
        label={{
          formatter: (val) => `${val}Mbps`,
        }}
        title
      />
      <Geom
        type="interval"
        adjust={[
          {
            type: "dodge",
            marginRatio: 0,
          },
        ]}
        color="name"
        position="type*data"
        label={[
          'data',
          (val) => {
            return {
              content: `${val}`,  // Mbps
              style: {
                fill: '#777',
                fontSize: 14,
              },
            };
          },
        ]}
        tooltip={[
          "type*data",
          (type, data) => {
            return {
              name: type,
              value: `${data}Mbps`,
            };
          },
        ]}
      />
      {/* <Interval
        adjust={[
          {
            type: "dodge",
            marginRatio: 0,
          },
        ]}
        color="name"
        position="type*data"
      /> */}
      <Tooltip shared />
    </Chart>
  );
}
