import React from "react";
import { Form, Input, Button, message } from "antd";
import JsEncrypt from "jsencrypt";
import { get, post } from "../../utils/request";
import * as Icon from "../../assets";
import { Route } from "react-router-dom";

const publicKey = `-----BEGIN RSA Public Key-----
MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAK+W1jWdJh9S0WvOmv19ET6TRG2IdR5G
Vw5rKhcIZ4DQTRbsDXJ8/B5FNDrGIK5viPi7KZhi88lDAUwIDfrLzl8CAwEAAQ==
-----END RSA Public Key-----`;

export default function Login({ history }) {
  const [form] = Form.useForm();

  const formItemLayout = {
    labelCol: { span: 4 },
    wrapperCol: { span: 8 },
  };
  const formTailLayout = {
    labelCol: { span: 4 },
    wrapperCol: { span: 8, offset: 4 },
  };

  // eslint-disable-next-line no-undef
  const jse = new JSEncrypt();
  jse.setPublicKey(publicKey);

  function onFinish(params) {
    params.password = jse.encrypt(params.password);

    post("/login", params, { withBaseUrl: false })
      .then(() => {
        message.success("登录成功");
        history.push("/business/dashboard");
      })
      .catch((err) => {
        message.error(err.response.message);
      });
  }

  return (
    <div className="login">
      <div className="login-content">
        <img src="login-logo.png" alt="logo" className="logo" />
        <Form form={form} onFinish={onFinish}>
          <Form.Item
            style={{ marginBottom: "36px" }}
            name="username"
            rules={[
              {
                required: true,
                message: "请输入账号",
              },
            ]}
          >
            <Input
              placeholder="请输入账号"
              prefix={<img src={Icon.user} alt="user" />}
            />
          </Form.Item>

          <Form.Item
            style={{ marginBottom: "60px" }}
            name="password"
            rules={[
              {
                required: true,
                message: "请输入密码",
              },
            ]}
          >
            <Input.Password
              placeholder="请输入密码"
              prefix={<img src={Icon.password} alt="password" />}
            />
          </Form.Item>

          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              block
              style={{ background: "#3B65EF" }}
            >
              登录
            </Button>
          </Form.Item>
        </Form>
      </div>
    </div>
  );
}
