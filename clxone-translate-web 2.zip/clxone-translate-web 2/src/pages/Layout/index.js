import React, { useEffect, useState } from "react";
import { renderRoutes } from "react-router-config";
import { Layout, Menu, Dropdown, Modal, Form, Input, message } from "antd";
import * as Icon from "@ant-design/icons";
import { Redirect } from "react-router-dom";
import "./style.css";
import { getMenuPathList } from "../../utils/helper";
import { post } from "../../utils/request";
const { MenuUnfoldOutlined, MenuFoldOutlined, DownOutlined } = Icon;

const { Header, Content, Sider } = Layout;

export default function Frame(props) {
  const { pathname } = props.location;

  const { routes } = props.route;
  const [collapsed, setCollapsed] = useState(false);

  const [selectedKeys, setSelectedKeys] = useState([]);
  const [openKeys, setOpenKeys] = useState([]);

  const [isModalVisible, setIsModalVisible] = useState(false);

  const [form] = Form.useForm();

  useEffect(() => {
    const { pathname } = props.location;
    setSelectedKeys([pathname]);
    setOpenKeys(getMenuPathList(pathname, routes));
  }, [props, routes]);

  const handleClickMenu = (route, a) => {
    props.history.push(route.key);
  };

  const handleToggleSubMenu = ({ key }) => {
    if (Array.isArray(openKeys) && openKeys.includes(key)) {
      setOpenKeys([]);
    } else {
      setOpenKeys([key]);
    }
  };

  const renderMenu = (routes) => {
    return routes.map((route) => {
      const MenuIcon = Icon[route.icon];
      if (route.routes && Array.isArray(route.routes) && route.routes.length) {
        return (
          <Menu.SubMenu
            key={route.path}
            icon={<MenuIcon />}
            title={route.title}
            onTitleClick={handleToggleSubMenu}
          >
            {renderMenu(route.routes)}
          </Menu.SubMenu>
        );
      } else {
        return (
          <Menu.Item
            key={route.path}
            icon={route.icon ? <MenuIcon /> : null}
            onClick={handleClickMenu}
          >
            {route.title}
          </Menu.Item>
        );
      }
    });
  };

  function handleLogout(params) {
    post("/apis/linkingthing.com/auth/v1/webusers/admin?action=logout").then(
      (res) => {
        if (res.result) {
          localStorage.removeItem("token");
          props.history.push("/login");
        }
      }
    );
  }

  function handleOk() {
    const params = form.getFieldsValue(true);
    post(
      "/apis/linkingthing.com/auth/v1/webusers/admin?action=changePassword",
      params
    )
      .then(() => {
        message.success("修改成功");
        setIsModalVisible(false);
      })
      .catch((err) => {
        message.error(err.response.message);
      });
  }

  const dropMenu = (
    <Menu>
      <Menu.Item onClick={() => setIsModalVisible(true)}>修改密码</Menu.Item>
      <Menu.Item onClick={handleLogout}>退出</Menu.Item>
    </Menu>
  );

  function loopRoutes(routes, result = []) {
    routes.forEach((item) => {
      result.push(item);
      if (Array.isArray(item.routes)) {
        loopRoutes(item.routes, result);
      }
    });
    return result;
  }

  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 16 },
  };
  const flatRoutes = loopRoutes(props.route.routes);

  console.log(pathname, 11111111111111);
  if (pathname === "/") {
    return <Redirect to="/business/dashboard" />;
  }
  return (
    <Layout
      className="site-layout"
      theme="light"
      style={{ background: "#F7F9FB", overflow: "hidden" }}
    >
      <Header
        theme="light"
        trigger={null}
        className="site-layout-background"
        style={{
          position: "relative",
          zIndex: 10,
          "box-shadow": " 0px 0px 24px 0px rgba(64, 64, 64, 0.07)",
        }}
      >
        <Modal
          title="修改密码"
          visible={isModalVisible}
          onOk={handleOk}
          onCancel={() => {
            form.resetFields();
            setIsModalVisible(false);
          }}
        >
          <Form
            {...layout}
            name="basic"
            form={form}
            initialValues={{ username: "admin", remember: true }}
          >
            <Form.Item
              label="用户名"
              name="username"
              rules={[{ required: true, message: "请输入用户名" }]}
            >
              <Input value="admin" disabled/>
            </Form.Item>

            <Form.Item
              label="密码"
              name="password"
              rules={[{ required: true, message: "请输入密码" }]}
            >
              <Input.Password />
            </Form.Item>
          </Form>
        </Modal>
        <div
          style={{
            position: "absolute",
            left: "10px",
            height: "64px",
            color: "#fff",
            fontWeight: "bolder",
            fontSize: "20px",
            lineHeight: "64px",
          }}
        >
          <img
            src="logo.png"
            alt="logo.png"
            style={{ width: "180px", margin: "0 10px" }}
          />
        </div>
        {React.createElement(
          collapsed ? MenuUnfoldOutlined : MenuFoldOutlined,
          {
            style: {
              marginLeft: "-30px",
            },
            className: "trigger",
            onClick: () => setCollapsed(!collapsed),
          }
        )}

        <div className="right">
          <Dropdown overlay={dropMenu}>
            <a
              className="ant-dropdown-link"
              onClick={(e) => e.preventDefault()}
            >
              Admin <DownOutlined />
            </a>
          </Dropdown>
        </div>
      </Header>
      <Layout
        style={{
          height: "calc(100vh - 64px)",
        }}
      >
        <Sider
          theme="light"
          trigger={null}
          collapsible
          collapsed={collapsed}
          style={{
            overflow: "auto",
            height: "100vh",
          }}
        >
          <Menu
            // theme="dark"
            selectedKeys={selectedKeys}
            openKeys={openKeys}
            mode="inline"
          >
            {renderMenu(routes)}
          </Menu>
        </Sider>

        <Content
          style={{
            padding: "24px 32px",
            overflow: "auto",
          }}
        >
          {renderRoutes(flatRoutes)}
        </Content>
      </Layout>
    </Layout>
  );
}
