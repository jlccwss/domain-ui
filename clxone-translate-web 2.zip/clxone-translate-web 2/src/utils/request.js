import qs from "qs";
import { isQuery } from "./helper";

function afterResponse(response) {
  const { headers } = response;

  if (headers.has("authorization")) {
    console.log(
      headers.authorization,
      typeof headers.authorization,
      headers.has("authorization"),
      headers.get("authorization")
    );
    localStorage.setItem("token", headers.get("authorization"));
  }

  return response;
}

async function checkRequest(response) {
  if (response.ok) {
    if (response.status === 204) {
      return response;
    }
    return response.json();
  } else {

    if (String(response.status) === "401") {
      window.location.href = "/#/login";
      return false;
    }
    const error = {
      message: response.statusText,
    };
    error.response = await response.json();
    throw error;
  }
}

function request(url, method, options) {
  const authorization = localStorage.getItem("token");
  const headers = new Headers({
    authorization,
  });

  const defaults = {
    method,
    headers,
    credentials: "include",
  };

  const params = {
    ...defaults,
    ...options,
  };

  return fetch(url, params).then(afterResponse).then(checkRequest);
}

export const get = (url, query, params) => {
  let targetUrl = url;

  if (isQuery(query)) {
    targetUrl = `${url}${url.includes("?") ? "&" : "?"}${qs.stringify(
      clearEmptyQuery(query)
    )}`;
  }

  return request(targetUrl, "GET", params);
};

export const post = (url, data, params) => {
  let body = JSON.stringify(data);
  if (data instanceof FormData) {
    body = data;
  }

  return request(url, "POST", {
    body,
    ...params,
  });
};

export const put = (url, data, params) => {
  let body = JSON.stringify(data);
  if (data instanceof FormData) {
    body = data;
  }

  return request(url, "PUT", {
    body,
    ...params,
  });
};

export const del = (url, data, params) => {
  return request(url, "DELETE", {
    withBaseUrl: false,
    ...params,
  });
};

const getUrl = (module, resource) => {
  return `/apis/linkingthing.com/${module}/v1${resource}`;
};

export const action = () => {};

export const getDataResource = (module, resource) => {
  // const fullUrlPath = params.withBaseUrl ? `${baseUrl}${url}` : url;
  getUrl(module, resource);
  return;
};

export const getUrlByPath = (props) => {
  console.log(props);
};

export function clearEmptyQuery(query) {
  const result = Object.create(null);
  for (let key in query) {
    if (query[key] !== "") {
      result[key] = query[key];
    }
  }
  return result;
}
