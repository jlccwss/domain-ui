<template>
  <div class="bg">
    <div class="login">
      <el-card class="box-card">
        <!-- <h1>GDNS</h1> -->
        <h1>
          <img src="../../assets/logo.svg" />
        </h1>
        <el-form ref="form" :model="form" @keyup.enter.native="onSubmit" label-width="80px">
          <el-input v-model="form.name" prefix-icon="el-icon-user-solid"></el-input>
          <el-input v-model="form.password" show-password prefix-icon="el-icon-lock"></el-input>
          <el-button type="primary" @click="onSubmit" round>登　　陆</el-button>
        </el-form>
      </el-card>
    </div>
  </div>
</template>

<style lang="sass" scoped>
  .bg
    width: 100vw
    height: 100vh
    background-image: url("../../assets/bg.png")
    background-size: 100%
    background-repeat: no-repeat
    .el-card, .el-card__body
      background-color: #2b2b2b

    .login
      width: 500px
      float: right
      margin-top: 150px
      margin-right: 60px
      h1
        color: #fff
        text-align: center
        img
          height: 40px
      .el-input, button
        margin-bottom: 42px
        
    .el-card
      border: 1px solid #2b2b2b
      .el-input--prefix .el-input__inner
        padding-left: 40px
      .el-input__icon
        font-size: 30px
      .el-button
        width: 100%
</style>

<script>
import store from "@/store";
import config from "@/config";

export default {
  data() {
    return {
      form: {
        name: "",
        password: ""
      }
    };
  },
  created() {
    this.keyupEnter();
  },
  methods: {
    keyupEnter() {
      document.onkeydown = e => {
        let body = document.getElementsByTagName("body")[0];
        if (
          e.keyCode === 13 &&
          e.target.baseURI.match(/inputbook/) &&
          e.target === body
        ) {
          this.onSubmit();
        }
      };
    },
    onSubmit() {
      let url =  config.url + "apis/web/login";
      let param = {
        "username": this.form.name,
	      "passwd": this.form.password
      }
      store.state.token = this.form.name;
      this.$http.post(url, param).then(res => {
        let data = res.data;
        if(data.status == 0){
          // store.state.token = this.form.name;
          sessionStorage.setItem("userName", this.form.name);
          this.getRole();
        }
        else {
          this.$message.error(data.msg);
        }
      })
      .catch(err => {
        console.log(err);
        
        this.$message.error("登陆失败");
      });
    },
    getRole() {
      let url =  config.url + "apis/web/role";
      let param = {}
      this.$http.get(url, param).then(res => {
        let data = res.data;
        if(data.group){
          sessionStorage.setItem("sysRole", data.group);
          sessionStorage.setItem("wslink", data.wslink);
          this.$router.push({ path: "/admin" });
        }
        else {
          this.$message.error(data.msg || "获取权限失败");
        }
      })
      .catch(err => {
        console.log(err);
        this.$message.error("获取权限失败");
      });
    }
  }
};
</script>
