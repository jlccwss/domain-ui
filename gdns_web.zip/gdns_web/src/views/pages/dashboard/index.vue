<template>
  <div>
    <!-- <HeaderSelect></HeaderSelect> -->
    <div class="table" :style="'max-height:' + (height-140) + 'px;'">
      开发中
    </div>
  </div>
</template>

<style lang="sass" scoped>
  
</style>

<script>
import store from "@/store";
import utils from '@/lib/utils'
import config from "@/config";
import HeaderSelect from "@/components/HeaderUser.vue";
import DataSet from '@antv/data-set';
import vueSeamlessScroll from 'vue-seamless-scroll';

let chart = {};

// import * as Three from 'three';

export default {
  data() {
    return {
      timer: null,
      timerQPM: null,
      onLoadG2: true,
      height: 0
    };
  },
  mounted() {
    console.log("dashboard");

    this.height = window.innerHeight;
    window.onresize = () => {
      this.height = window.innerHeight;
    };


  },
  computed: {
    classOption() {
      return {
        step: 0.5, //数值越大速度滚动越快
        limitMoveNum: 12, //开始无缝滚动的数据量
        hoverStop: true, //是否开启鼠标悬停stop
        direction: 1, // 0向下 1向上 2向左 3向右
        openWatch: true, //开启数据实时监控刷新dom
        singleHeight: 0, //单步运动停止的高度(默认值0是无缝不停止的滚动) direction => 0/1
        singleWidth: 0, //单步运动停止的宽度(默认值0是无缝不停止的滚动) direction => 2/3
        waitTime: 1000 //单步运动停止的时间(默认值1000ms)
      }
    },
    classOption2() {
      return {
        step: 0.5, //数值越大速度滚动越快
        limitMoveNum: 12, //开始无缝滚动的数据量
        hoverStop: true, //是否开启鼠标悬停stop
        direction: 1, // 0向下 1向上 2向左 3向右
        openWatch: true, //开启数据实时监控刷新dom
        singleHeight: 0, //单步运动停止的高度(默认值0是无缝不停止的滚动) direction => 0/1
        singleWidth: 0, //单步运动停止的宽度(默认值0是无缝不停止的滚动) direction => 2/3
        waitTime: 1000 //单步运动停止的时间(默认值1000ms)
      }
    }
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  methods: {
    
  },
  components: {
    HeaderSelect,
    vueSeamlessScroll
  }
};
</script>