<template>
  <div class="bg">
    <!-- <a class="close" @click="goHome">
      <img src="../../assets/images/icon/close.png" />
    </a> -->
    <div class="left">
      <div class="h1">接口组1</div>
      <div class="box1">
        <el-col :span="6">
          <div style="min-height:160px;">
            <div id="dropmalformation1"></div>
          </div>
          <div class="title">格式清洗</div>
        </el-col>
        <el-col :span="6">
          <div style="min-height:160px;">
            <div id="dropblack1"></div>
          </div>
          <div class="title">名单清洗</div>
        </el-col>
        <el-col :span="6">
          <div style="min-height:160px;">
            <div id="dropwild1"></div>
          </div>
          <div class="title">通配清洗</div>
        </el-col>
        <el-col :span="6">
          <div style="min-height:160px;">
            <div id="droplimit1"></div>
          </div>
          <div class="title">出口限速清洗</div>
        </el-col>
      </div>
      <div class="box1">
        <div style="min-height:160px;">
          <div id="QPS1" class="g2"></div>
        </div>
      </div>
      <div class="box1">
        <div style="min-height:160px;">
          <div id="BPS1" class="g2"></div>
        </div>
      </div>
      <div class="box2">
        <div>
          <el-tooltip  v-for="(item, index) in topnData.ip" :key="index"  effect="dark" :content="item.key + '，归属地：' + item.region + '，请求量：' + item.value + '次，平均QPS：' + item.qps + '。'" placement="top">
            <p class="topP">{{item.key}}，归属地：{{item.region || ""}}，请求量：{{item.value}}次，平均QPS：{{item.qps}}。</p>
          </el-tooltip>
        </div>
      </div>
    </div>
    <div class="middle">
      <div class="title">DNS防护系统-G3</div>
      <div class="box1">
        <div>
          <div id="myChart1" :style="{width: '100%', height: '160px'}"></div>
          <p>累计清洗流量 {{screenData.dropqps | NumFormatCompany}} QPS</p>
        </div>
        <div>
          <div id="myChart2" :style="{width: '100%', height: '160px'}"></div>
          <p>累计清洗流量 {{screenData.dropbps | NumFormatCompany}} BPS</p>
        </div>
      </div>
      <div class="box2">
        <!-- <div id="h1">最近一周</div> -->
        <div id="lineDay" class="g2"></div>
      <!-- </div>
      <div class="box2"> -->
        <!-- <div id="h1">最近8周</div> -->
        <div id="lineWeek" class="g2"></div>
      <!-- </div>
      <div class="box2"> -->
        <!-- <div id="h1">最近一年</div> -->
        <div id="lineMonth" class="g2"></div>
      </div>
      <div class="box3">
        <el-row :gutter="20">
          <el-col :span="9" class="spanFloat">
            <p>IP黑名单：{{countData.ipblack || 0}}个 <span :class="configData.ipblack? 'configOpen': 'configClose'">{{configData.ipblack? "开启": "关闭"}}</span><i></i></p>
            <p>IP白名单：{{countData.ipwhite || 0}}个 <span :class="configData.ipwhite? 'configOpen': 'configClose'">{{configData.ipwhite? "开启": "关闭"}}</span><i></i></p>
            <p>IP PPTC名单：{{countData.ippptc || 0}}个 <span :class="configData.ippptc? 'configOpen': 'configClose'">{{configData.ippptc? "开启": "关闭"}}</span><i></i></p>
            <p>域名黑名单：{{countData.dnblack || 0}}个 <span :class="configData.dnblack? 'configOpen': 'configClose'">{{configData.dnblack? "开启": "关闭"}}</span><i></i></p>
            <p>域名白名单：{{countData.dnwhite || 0}}个 <span :class="configData.dnwhite? 'configOpen': 'configClose'">{{configData.dnwhite? "开启": "关闭"}}</span><i></i></p>
            <p>域名PPTC名单：{{countData.dnpptc || 0}}个 <span :class="configData.dnpptc? 'configOpen': 'configClose'">{{configData.dnpptc? "开启": "关闭"}}</span><i></i></p>
            <p>通配名单：{{countData.wildcard || 0}}个 <span :class="configData.wildcard? 'configOpen': 'configClose'">{{configData.wildcard? "开启": "关闭"}}</span><i></i></p>
          </el-col>
          <el-col :span="15" class="box3_right">
            <p>畸形清洗：<span :class="configData.formatcheck? 'configOpen': 'configClose'">{{configData.formatcheck? "开启": "关闭"}}</span><i></i></p>
            <p>ANY清洗：<span :class="configData.dropany? 'configOpen': 'configClose'">{{configData.dropany? "开启": "关闭"}}</span></p>
            <p>TCP清洗：<span :class="configData.droptcp? 'configOpen': 'configClose'">{{configData.droptcp? "开启": "关闭"}}</span><i></i></p>
            <p>UDP清洗：<span :class="configData.dropudp? 'configOpen': 'configClose'">{{configData.dropudp? "开启": "关闭"}}</span></p>
            <p>出口限速：<span :class="configData.limiten? 'configOpen': 'configClose'">{{configData.limiten? "开启": "关闭"}}</span><i></i></p>
            <p>DNS端口：<span>{{configData.dnsport || null}}</span></p>
            <p>限速阈值：<span>{{configData.limitcnt || null}} KQPS</span><i></i></p>
            <p></p>
            <p>非DNS清洗：<span :class="configData.dropnodns? 'configOpen': 'configClose'">{{configData.dropnodns? "开启": "关闭"}}</span><i></i></p>
            <p>禁止ping：<span :class="configData.dropping? 'configOpen': 'configClose'">{{configData.dropping? "开启": "关闭"}}</span></p>
            <p>板卡版本：<span>{{configData.fpgastatus}}</span><i></i></p>
            <p></p>
            <p><a style="display: inline-block; height: 16px;"></a><span></span><i></i></p>
          </el-col>
        </el-row>
      </div>
      <div class="selectType">
        <div class="icon">
          <a :class="'eth icon1_' + configData.eth1 || 'icon1_0'"></a>
          <a :class="'eth icon2_' + configData.eth2 || 'icon2_0'"></a>
        </div>
        <div :class="configData.guard==1?'select green':'select'" @click="putConfig(1)">
          正常<br/>防护
        </div>
        <div :class="configData.guard==2?'select green':'select'" @click="putConfig(2)">
          应急<br/>预案
        </div>
        <div :class="configData.guard==0?'select green':'select'" @click="putConfig(0)">
          透明<br/>输出
        </div>
        <div class="select" @click="goHome">
          <span>退出<br/>全屏</span>
        </div>
        <!-- <div class="select" @click="goHome">
          退出<br/>大屏
        </div> -->
        <div class="icon">
          <a :class="'eth icon3_' + configData.eth3 || 'icon3_0'"></a>
          <a :class="'eth icon4_' + configData.eth4 || 'icon4_0'"></a>
        </div>
      </div>
    </div>
    <div class="right">
      <div class="h1">接口组2</div>
      <div class="box1">
        <el-col :span="6">
          <div style="min-height:160px;">
            <div id="dropmalformation2"></div>
          </div>
          <div class="title">畸形报文清洗</div>
        </el-col>
        <el-col :span="6">
          <div style="min-height:160px;">
            <div id="dropblack2"></div>
          </div>
          <div class="title">名单清洗</div>
        </el-col>
        <el-col :span="6">
          <div style="min-height:160px;">
            <div id="dropwild2"></div>
          </div>
          <div class="title">通配清洗</div>
        </el-col>
        <el-col :span="6">
          <div style="min-height:160px;">
            <div id="droplimit2"></div>
          </div>
          <div class="title">格式清洗</div>
        </el-col>
      </div>
      <div class="box1">
        <div style="min-height:160px;">
          <div id="QPS2" class="g2"></div>
        </div>
      </div>
      <div class="box1">
        <div style="min-height:160px;">
          <div id="BPS2" class="g2"></div>
        </div>
      </div>
      <div class="box2">
        <div>
          <el-tooltip  v-for="(item, index) in topnData.dn" :key="index"  effect="dark" :content="item.key + '，请求量：' + item.value + '次，平均QPS：' + item.qps + '。'" placement="top">
            <p class="topP">{{item.key}}，请求量：{{item.value}}次，平均QPS：{{item.qps}}。</p>
          </el-tooltip>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="sass" scoped>
  .bg
    position: relative
    width: 100vw
    height: 100vh
    min-width: 1920px
    min-height: 1080px
    background-image: url("../../assets/images/bg_screen.png")
    background-size: 100% 100%
    background-repeat: no-repeat
  .h1
    font-size: 28px
    line-height: 50px
    color: #fff
    text-align: center
  .left
    width: 28%
    height: 80%
    float: left
    margin: 4% 0 0 4%
    .box1
      width: 100%
      height: 25%
      margin-bottom: 2%
      background-image: url("../../assets/images/leftb1.png")
      background-size: 100% 100%
      background-repeat: no-repeat
      text-align: center
      color: #fff
      .title
        font-size: 12px
      /deep/ p.title
        margin-block-end: 0
      /deep/ p.value
        margin-block-start: 0
    .box2
      width: 100%
      height: 24%
      padding-top: 1%
      margin-bottom: 2%
      background-image: url("../../assets/images/leftb1.png")
      background-size: 100% 100%
      background-repeat: no-repeat
      color: #fff
      div
        width: 96%
        height: 96%
        p
          padding-left: 30px
          height: 14px
          font-size: 12px
          line-height: 14px
          overflow: hidden
          text-overflow: ellipsis
          white-space: nowrap
  .right
    width: 27%
    height: 80%
    float: left
    margin: 4% 0 0 2%
    .box1
      width: 100%
      height: 25%
      margin-bottom: 2%
      background-image: url("../../assets/images/leftb1.png")
      background-size: 100% 100%
      background-repeat: no-repeat
      text-align: center
      color: #fff
      .title
        font-size: 12px
      /deep/ p.title
        margin-block-end: 0;
      /deep/ p.value
        margin-block-start: 0;
    .box2
      width: 100%
      height: 24%
      padding-top: 1%
      margin-bottom: 2%
      background-image: url("../../assets/images/leftb1.png")
      background-size: 100% 100%
      background-repeat: no-repeat
      color: #fff
      div
        width: 96%
        height: 96%
        p
          padding-left: 30px
          font-size: 12px
          line-height: 14px
  .middle
    width: 33%
    height: 85%
    float: left
    margin: 1.5% 0 0 2%
    .title
      width: 100%
      height: 10%
      color: #fff
      font-size: 30px
      text-align: center
    .box1
      width: 100%
      height: 22%
      margin-bottom: 1%
      background-image: url("../../assets/images/leftb1.png")
      background-size: 100% 100%
      background-repeat: no-repeat
      div
        width: 50%;
        float: left
        p
          text-align: center
          color: #fff
          font-size: 12px
    .box2
      width: 100%
      height: 42%
      margin-bottom: 1%
      background-image: url("../../assets/images/leftb1.png")
      background-size: 100% 100%
      background-repeat: no-repeat
      text-align: center
      color: #fff
    .box3
      width: 100%
      height: 25%
      margin-bottom: 1%
      background-image: url("../../assets/images/leftb1.png")
      background-size: 100% 100%
      background-repeat: no-repeat
      .el-row
        padding-top: 10px
        padding-left: 10px
      p
        position: relative
        padding-left: 20px
        color: #fff
        font-size: 14px
        line-height: 30px
        margin: 0
      .spanFloat
        span
          float: right
          margin-right: 20px
          height: 20px
        i
          position: absolute
          display: block
          top: 5px
          right: -10px
          height: 20px
          z-index: 1
          border-right: 1px solid #3083ad
      .box3_right
        p
          position: relative
          display: inline-block
          width: 40%
        span
          float: right
          margin-right: 10px
        i
          position: absolute
          display: block
          top: 5px
          right: -5px
          height: 20px
          z-index: 1
          border-right: 1px solid #3083ad
    .selectType
      text-align: center
      .select
        display: inline-block
        width: 80px
        height: 60px
        padding-top: 13px
        padding-left: 3px
        text-align: center
        color: #fff
        background-image: url("../../assets/images/big_six_qd.png")
        background-size: 100% 100%
        background-repeat: no-repeat
        cursor: pointer
        &.green
          color: #33cc66
        &.red
          color: #cc3433
      .icon
        display: inline-block
        width: 140px
        height: 50px
        margin-top: -20px
        a
          display: inline-block
          width: 50px
          height: 50px
          margin: 0 5px
          background-size: 100% 100%
          background-repeat: no-repeat
          &.icon1_0
            background-image: url("../../assets/images/grey_1.svg")
          &.icon2_0
            background-image: url("../../assets/images/grey_2.svg")
          &.icon3_0
            background-image: url("../../assets/images/grey_3.svg")
          &.icon4_0
            background-image: url("../../assets/images/grey_4.svg")
          &.icon1_1
            background-image: url("../../assets/images/yellow_1.svg")
          &.icon2_1
            background-image: url("../../assets/images/yellow_2.svg")
          &.icon3_1
            background-image: url("../../assets/images/yellow_3.svg")
          &.icon4_1
            background-image: url("../../assets/images/yellow_4.svg")
          &.icon1_2
            background-image: url("../../assets/images/green_1.svg")
          &.icon2_2
            background-image: url("../../assets/images/green_2.svg")
          &.icon3_2
            background-image: url("../../assets/images/green_3.svg")
          &.icon4_2
            background-image: url("../../assets/images/green_4.svg")
          &.icon1_3
            background-image: url("../../assets/images/red_1.svg")
          &.icon2_3
            background-image: url("../../assets/images/red_2.svg")
          &.icon3_3
            background-image: url("../../assets/images/red_3.svg")
          &.icon4_3
            background-image: url("../../assets/images/red_4.svg")
  .close
    position: absolute
    top: 50px
    right: 20px
    z-index: 10
    cursor: pointer
    img
      width: 50px
  .configOpen
    color: #33cc66
  .configClose
    color: #cc3433
  .g2
    text-align: left
  .topP
    width: 480px
    height: 14px
    overflow: hidden
    text-overflow: ellipsis
    white-space: nowrap
</style>

<script>
import store from "@/store";
import config from "@/config";
import DataSet from '@antv/data-set';
// import vueSeamlessScroll from 'vue-seamless-scroll';
// import DigitRoll from '@huoyu/vue-digitroll';
import moment, { now } from 'moment';

let chart = {};

export default {
  data() {
    return {
      timer: null,
      websock: null, 
      fullscreen: false,
      onLoadG2line: {
        left_box1: true,
        left_box2: true,
        right_box1: true,
        right_box2: true
      },
      qpsData: [],
      bpsData: [],
      screenData: {},
      countData: {},
      configData: {},
      topnData: {},
      ethState: ["grey", "yellow", "green", "red"]
    };
  },
  beforeCreate() {
    chart = {};
  },
  created() {
    this.initWebSocket();
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  destroyed() {
    this.websock.close();
    //离开路由之后断开websocket连接
  },
  mounted() {
    this.getList();
    this.getCount();
    this.getConfig();
    this.getTopn();

    // this.timer = setInterval(() => {
    //   // this.getList(moment().format("YYYY-MM-DD HH:mm:ss"));
    //   this.getList();
    // }, 1000 * 5)
  },
  methods: {
    getList(time) {
      // this.$loading(config.loading);
      let url =  config.url + "apis/count/list";
      let param = {
        time: time || "0000-00-00 00:00:00"
      };
      this.$http.post(url, param).then(res => {
        let data = res.data;
        
        let groupPie1 = {
          dropmalformation: data.group[0].dropmalformation / data.group1qps,
          dropblack: data.group[0].dropblack / data.group1qps,
          dropwild: data.group[0].dropwild / data.group1qps,
          droplimit: data.group[0].droplimit / data.group1qps
        }
        let groupPie2 = {
          dropmalformation: data.group[1].dropmalformation / data.group2qps,
          dropblack: data.group[1].dropblack / data.group2qps,
          dropwild: data.group[1].dropwild / data.group2qps,
          droplimit: data.group[1].droplimit / data.group2qps
        }

        this.initPieComponent('dropmalformation', 1, groupPie1.dropmalformation, "畸形报文命中", data.group[0].dropmalformation);
        this.initPieComponent('dropblack', 1, groupPie1.dropblack, "黑名单命中", data.group[0].dropblack);
        this.initPieComponent('dropwild', 1, groupPie1.dropwild, "通配名单命中", data.group[0].dropwild);
        this.initPieComponent('droplimit', 1, groupPie1.droplimit, "出口限速清洗", data.group[0].droplimit);

        this.initPieComponent('dropmalformation', 2, groupPie2.dropmalformation, "畸形报文命中", data.group[1].dropmalformation);
        this.initPieComponent('dropblack', 2, groupPie2.dropblack, "黑名单命中", data.group[1].dropblack);
        this.initPieComponent('dropwild', 2, groupPie2.dropwild, "通配名单命中", data.group[1].dropwild);
        this.initPieComponent('droplimit', 2, groupPie2.droplimit, "出口限速清洗", data.group[1].droplimit);

        this.qpsData = data.group[0].data;
        this.bpsData = data.group[1].data;

        this.initLineComponent('QPS', 1, data.group[0].data);
        this.initLineComponent('BPS', 1, data.group[0].data);

        this.initLineComponent('QPS', 2, data.group[1].data);
        this.initLineComponent('BPS', 2, data.group[1].data);

        this.screenData = {
          baseqps: data.baseqps,
          basebps: data.basebps,
          dropqps: data.dropqps,
          dropbps: data.dropbps
        }
        this.drawLine(1, parseInt(data.currentqps/data.baseqps*100).toFixed(2), data.currentqps, data.baseqps);
        this.drawLine(2, parseInt(data.currentbps/data.basebps*100).toFixed(2), data.currentbps, data.basebps);
        
        let lineDay = {
          name: "最近一周数据",
          dropdayqps: {
            name: "QPS",
            data: data.dropdayqps
          },
          dropdaybps: {
            name: "BPS",
            data: data.dropdaybps
          }
        }
        let lineWeek = {
          name: "最近8周数据",
          dropweekqps: {
            name: "QPS",
            data: data.dropweekqps
          },
          dropweekbps: {
            name: "BPS",
            data: data.dropweekbps
          }
        }
        let lineMonth = {
          name: "最近一年数据",
          dropmonthqps: {
            name: "QPS",
            data: data.dropmonthqps
          },
          dropmonthbps: {
            name: "BPS",
            data: data.dropmonthbps
          }
        }
        this.initLineDataComponent("lineDay", lineDay, ["dropdayqps", "dropdaybps"], data.dropday);
        this.initLineDataComponent("lineWeek", lineWeek, ["dropweekqps", "dropweekbps"], data.dropweek);
        this.initLineDataComponent("lineMonth", lineMonth, ["dropmonthqps", "dropmonthbps"], data.dropmonth);

      })
      .catch(err => {
        // this.$loading().close();
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    getCount() {
      let url =  config.url + "apis/list/count";
      let param = {};
      this.$http.get(url, param).then(res => {
        let data = res.data;
        this.countData = data;
      })
      .catch(err => {
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    getConfig() {
      let url =  config.url + "apis/config/list";
      let param = {};
      this.$http.get(url, param).then(res => {
        let data = res.data;
        this.configData = data;
      })
      .catch(err => {
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    putConfig(guard) {
      let url =  config.url + "apis/config/global";
      let param = {
        "formatcheck": this.configData.formatcheck,  // 畸形包清洗
        "droptcp": this.configData.droptcp,      // TCP类型清洗
        "dropany": this.configData.dropany,     // ANY类型清洗
        "limiten": this.configData.limiten,     // 出口限速
        "limitcnt": this.configData.limitcnt,    // 出口限速数值
        "dnsport": this.configData.dnsport,     // DNS端口
        "dropudp": this.configData.dropudp,
        "dropnodns": this.configData.dropnodns,
        "dropping": this.configData.dropping,
        "guard": guard     // 0:透明传输, 1:正常防护, 2:应急预案
      };
      this.$http.put(url, param).then(res => {
        let data = res.data;
        if(data.status == 0) {
          this.configData.guard = guard;
          this.$message.success("设置成功");
        }
        else {
          this.$message.error(data.msg);
        }
      })
      .catch(err => {
        console.log(err);
        // this.$message.error("请求接口失败");
      });
    },
    getTopn() {
      let url =  config.url + "apis/topn/list";
      let param = {};
      this.$http.get(url, param).then(res => {
        let data = res.data || [];
        data.ip = data.ip.length > 7? data.ip.slice(data.ip.length - 7, data.ip.length): data.ip;
        data.dn = data.dn.length > 7? data.dn.slice(data.dn.length - 7, data.dn.length): data.dn;
        
        this.topnData = data;
      })
      .catch(err => {
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    initLineComponent(divId, group, data) {
      let name = divId;
      divId += group;

      // console.log(name, data)

      let lineData = [];
      data.map(function(item, index) {
        item.time = new Date(item.time)
        if(name == "QPS") {
          lineData.push({
            country: "输入QPS",
            date: item.time,
            // date: moment(item.time).format('X') * 1000,
            value: item.qpsin
          })
          lineData.push({
            country: "输出QPS",
            date: item.time,
            // date: moment(item.time).format('X') * 1000,
            value: item.qpsout
          })
          lineData.push({
            country: "ipv4",
            date: item.time,
            // date: moment(item.time).format('X') * 1000,
            value: item.ipv4in
          })
          lineData.push({
            country: "ipv6",
            date: item.time,
            // date: moment(item.time).format('X') * 1000,
            value: item.ipv6in
          })
          lineData.push({
            country: "tcp",
            date: item.time,
            // date: moment(item.time).format('X') * 1000,
            value: item.syncin
          })
          lineData.push({
            country: "dnssec",
            date: item.time,
            // date: moment(item.time).format('X') * 1000,
            value: item.dnssecin
          })
        }
        else if(name == "BPS") {
          lineData.push({
            country: "输入BPS",
            date: item.time,
            // date: moment(item.time).format('X') * 1000,
            value: item.bpsin
          })
          lineData.push({
            country: "输出BPS",
            date: item.time,
            // date: moment(item.time).format('X') * 1000,
            value: item.bpsout
          })
        }
      })
      if(chart[divId]) {
        chart[divId].scale('date', {
          nice: false,
          type: 'timeCat',
          tickCount: 15,
          mask: 'HH:mm:ss',
          range : [ 0 , 1]
        });
        chart[divId].changeData(lineData);
        return false;
      }
      else {
        chart[divId] = new G2.Chart({
          container: divId,
          padding: [50, 40, 50, 70],
          forceFit: true,
          height: 205
        })
        this.onLoadG2line.left_box2 = false;
      }
      chart[divId].source(lineData, {
        x: {
          type: 'cat'
        },
        y: {
          min: 0
        }
      });
      chart[divId].filter('country', val => {
        return val === '输入' + name || val === '输出' + name;
      });
      chart[divId].axis('value', {
        title: {
          fontSize: '12', // 文本大小
          textAlign: 'center', // 文本对齐方式
          fill: '#fff', // 文本颜色
        },
        label: {
          textStyle: {
            fill: '#fff'
          },
          formatter: text => {
            return this.NumFormatCompany(text)
          }
        }
      });
      chart[divId].axis('date', {
        label: {
          textStyle: {
            fill: '#fff'
          },
          // formatter: text => {
          //   return moment.unix(text/1000).format("HH:mm:ss")
          // }
        }
      });
      chart[divId].scale('value', {
        alias: name,
        tickCount: 6,
        min: 0
      });
      chart[divId].scale('date', {
        nice: false,
        type: 'timeCat',
        tickCount: 15,
        mask: 'HH:mm:ss',
        range : [ 0 , 1]
      });
      chart[divId].legend({
        position: 'top-center',
        offsetY: -5
      });
      
      chart[divId].line().position('date*value').tooltip('country*date*value', (title, date, value) => {
        return {
          title: moment.unix(date/1000).format("HH:mm:ss"),
          name: title,
          value: this.NumFormatCompany(value)
        };
      }).color('country').size(2);

      chart[divId].render();
    },
    initLineDataComponent(divId, data, dataName, dataTitle) {
      let name = data.name;
      let lineData = [];
      data[dataName[0]].data.map(function(item, index) {
        lineData.push({
          country: data[dataName[0]].name,
          date: "" + (index+1),
          value: item,
          title: dataTitle[index]
        })
      })
      data[dataName[1]].data.map(function(item, index) {
        lineData.push({
          country: data[dataName[1]].name,
          date: "" + (index+1),
          value: item,
          title: dataTitle[index]
        })
      })
      if(chart[divId]) {
        chart[divId].axis('date', {
          label: {
            textStyle: {
              fill: '#fff'
            },
            formatter: text => {
              return dataTitle[text-1]
            }
          }
        });
        chart[divId].changeData(lineData);
        return false;
      }
      else {
        chart[divId] = new G2.Chart({
          container: divId,
          padding: [25, 50, 20, 70],
          forceFit: true,
          height: 115
        })
        // this.onLoadG2line.left_box2 = false;
      }
      chart[divId].source(lineData);
      chart[divId].axis('value', {
        title: {
          fontSize: '12', // 文本大小
          textAlign: 'center', // 文本对齐方式
          fill: '#fff', // 文本颜色
        },
        label: {
          textStyle: {
            fill: '#fff'
          },
          formatter: text => {
            return this.NumFormatCompany(text)
          }
        }
      });
      chart[divId].axis('date', {
        label: {
          textStyle: {
            fill: '#fff'
          },
          formatter: text => {
            return dataTitle[text-1]
          }
        }
      });
      chart[divId].scale('value', {
        alias: name,
        tickCount: 5,
        min: 0
      });
      chart[divId].scale('date', {
        nice: false,
        tickCount: 12,
        range : [ 0 , 1]
      });
      chart[divId].legend(false);
      
      chart[divId].line().position('date*value').tooltip('country*date*value*title', (title, date, value, tip) => {
        return {
          title: tip || "\t",
          name: title,
          value: this.NumFormatCompany(value)
        };
      }).color('country').size(2);

      chart[divId].render();
    },
    initPieComponent(divId, group, percent, name, total, state) {
      divId+= group;
      total = this.NumFormatCompany(total);

      percent = percent || 0

      if(percent > 1) {
        percent = 1;
      }

      let data = [{
        type: '丢包',
        percent: 1 - percent<0? 0: 1 - percent
      }, {
        type: '正常',
        percent: percent
      }]

      // if(data[0].percent == 1 && data[1].percent == 1) {
      //   data[0].percent = 1;
      //   data[1].percent = 0;
      // }

      if(chart[divId]) {
        chart[divId].guide().clear();
        chart[divId].guide().html({
          position: ['50%', '48%'],
          // html: '<div class="g2-guide-html" style="font-size:12px;"><p class="title">' + name + '</p><p class="value">' + total + '</p></div>',
          html: '<div class="g2-guide-html" style="font-size:12px;"><p class="title">' + total + '</p><p class="value">' + (parseInt(data[1].percent * 100 * 100) / 100).toFixed(2) + '%</p></div>',
          alignX: 'middle',
          alignY: 'middle'
        });
        chart[divId].changeData(data);
        return false;
      }
      else {
         chart[divId] = new G2.Chart({
          container: divId,
          forceFit: true,
          padding: 0,
          height: 150
        })
      }
      
      chart[divId].source(data);
      chart[divId].tooltip(false);
      // chart[divId].legend({
      //   position: 'bottom-center',
      //   offsetY: -35
      // });
      if(data.length == 1){
        chart[divId].legend('type', false);
      }
      
      chart[divId].coord('theta', {
        radius: .7,
        innerRadius: 0.8,
        offsetY: -35
      });
      chart[divId].intervalStack().position('percent').color('type', ['#33cc66', '#cc3433']).opacity(1).label('percent', {
        offset: -8,
        textStyle: {
          fill: 'white',
          fontSize: 0,
          shadowBlur: 2,
          shadowColor: 'rgba(0, 0, 0, .45)'
        },
        rotate: 0,
        autoRotate: false,
        formatter: function formatter(text, item) {
          if(data.length>1){
            return String(parseInt(item.point.percent * 100)) + '%';
          }
        }
      });
      chart[divId].guide().html({
        position: ['50%', '48%'],
        // html: '<div class="g2-guide-html" style="font-size:12px;"><p class="title">' + name + '</p><p class="value">' + total + '</p></div>',
        // html: '<div class="g2-guide-html" style="font-size:12px;"><p class="value">' + total + '</p></div>',
        html: '<div class="g2-guide-html" style="font-size:12px;"><p class="title">' + total + '</p><p class="value">' + (parseInt(data[1].percent * 100 * 100) / 100).toFixed(2) + '%</p></div>',
        alignX: 'middle',
        alignY: 'middle'
      });
      chart[divId].render()
    },
    drawLine(id, count, currentqps, baseqps, drop) {
      // 初始化echarts实例
      let myChart = this.$echarts.init(document.getElementById('myChart' + id))
      // 绘制图表
      myChart.setOption({
        series: [
          {
            type: "gauge",
            center: ["50%", "45%"], // 仪表位置
            radius: "60%", //仪表大小
            startAngle: 200, //开始角度
            endAngle: -20, //结束角度
            startAngle: 20,
            axisLine: {
              show: false,
              lineStyle: { // 属性lineStyle控制线条样式
                width: 1
              }
            },
            splitLine: {
              show: false
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              show: false
            },
            pointer: { //指针样式
              length: '45%'
            },
            detail: {
              show: false
            }
          },
          {
            type: "gauge",
            center: ["50%", "70%"], // 默认全局居中
            radius: "120%",
            min: 0,
            max: 200,
            startAngle: 200,
            endAngle: -20,
            axisLine: {
              show: true,
              lineStyle: { // 属性lineStyle控制线条样式
                color: [ //表盘颜色
                  [0.5, "#20AE51"],//0-50%处的颜色
                  [0.7, "#FFED44"],//51%-70%处的颜色
                  [0.9, "#FF9618"],//70%-90%处的颜色
                  [1, "#DA462C"]//90%-100%处的颜色
                ],
                width: 30//表盘宽度
              }
            },
            splitLine: { //分割线样式（及10、20等长线样式）
              length: 30,
              lineStyle: { // 属性lineStyle控制线条样式
                width: 2
              }
            },
            axisTick: { //刻度线样式（及短线样式）
              length: 20
            },
            axisLabel: { //文字样式（及“10”、“20”等文字样式）
              color: "#fff",
              distance: 5 //文字离表盘的距离
            },
            detail: {
              // formatter: "{score|{value}%}",
              formatter: "{score|" + this.NumFormatCompany(currentqps) + "/" + this.NumFormatCompany(baseqps) +"}",
            	offsetCenter: [0, "50%"],
            	// backgroundColor: '#FFEC45',
            	height: 30,
            	rich: {
            		score: {
            			color: "white",
            			fontFamily: "微软雅黑",
            			fontSize: 14
            		}
            	}
            },
            data: [{
              value: count,
              label: {
                textStyle: {
                  fontSize: 12
                }
              }
            }]
          }
        ]
      });
    },
    goHome() {
      this.$router.push({ path: "/admin/count/ip" });
    },
    outLogin() {

      store.state.token = "";
      sessionStorage.removeItem("userName");
      this.$router.push({ path: "/login" });
    },
    handleFullScreen(){
      let element = document.documentElement;
      // 判断是否已经是全屏
      // 如果是全屏，退出
      if (this.fullscreen) {
          if (document.exitFullscreen) {
              document.exitFullscreen();
          } else if (document.webkitCancelFullScreen) {
              document.webkitCancelFullScreen();
          } else if (document.mozCancelFullScreen) {
              document.mozCancelFullScreen();
          } else if (document.msExitFullscreen) {
              document.msExitFullscreen();
          }
          console.log('已还原！');
      } else {    // 否则，进入全屏
          if (element.requestFullscreen) {
              element.requestFullscreen();
          } else if (element.webkitRequestFullScreen) {
              element.webkitRequestFullScreen();
          } else if (element.mozRequestFullScreen) {
              element.mozRequestFullScreen();
          } else if (element.msRequestFullscreen) {
              // IE11
              element.msRequestFullscreen();
          }
          console.log('已全屏！');
      }
      // 改变当前全屏状态
      this.fullscreen = !this.fullscreen;
    },
    NumFormatCompany(value) {
      if(!value) return 0
      if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000) {
        return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "D"
      }
      else if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000 * 1000 * 1000 * 1000 * 1000) {
        return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "N"
      }
      else if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000 * 1000 * 1000 * 1000) {
        return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "B"
      }
      else if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000 * 1000 * 1000) {
        return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "Y"
      }
      else if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000 * 1000) {
        return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "Z"
      }
      else if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000) {
        return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "E"
      }
      else if(value > 1000 * 1000 * 1000 * 1000 * 1000) {
        return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "P"
      }
      else if(value > 1000 * 1000 * 1000 * 1000) {
        return (parseInt(value / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "T"
      }
      else if(value > 1000 * 1000 * 1000) {
        return (parseInt(value / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "G"
      }
      else if(value > 1000 * 1000) {
        return (parseInt(value / 1000 / 1000 * 100) / 100).toFixed(2) + "M"
      }
      else if(value > 1000) {
        return (parseInt(value / 1000 * 100) / 100).toFixed(2) + "K"
      }
      else {
        return value
      }
    },
    initWebSocket(){
      //初始化weosocket
      const wsuri = sessionStorage.getItem("wslink");
      // const wsuri = config.wsurl + "apis/ws";
      console.log("正在连接：" + wsuri);
      this.websock = new WebSocket(wsuri);
      this.websock.onmessage = this.websocketonmessage;
      this.websock.onopen = this.websocketonopen;
      this.websock.onerror = this.websocketonerror;
      this.websock.onclose = this.websocketclose;
    },
    websocketonopen(){ //连接建立之后执行send方法发送数据
      console.log("连接成功")
      // let actions = {"test":"12345"};
      // this.websocketsend(JSON.stringify(actions));
    },
    websocketonerror(){//连接建立失败重连
      console.log("连接失败")
      this.initWebSocket();
    },
    websocketonmessage(e){ //数据接收
      // const redata = JSON.parse(e.data);
      let data;
      // console.log(e.data)
      if(e.data) {
        data = JSON.parse(e.data);
        if(data.type == "count_list") {
          this.getCountList(data);
        }
        else if(data.type == "config_list") {
          this.configData = data;
        }
        else if(data.type == "topn_list") {
          data.ip = data.ip.length > 7? data.ip.slice(data.ip.length - 7, data.ip.length): data.ip;
          data.dn = data.dn.length > 7? data.dn.slice(data.dn.length - 7, data.dn.length): data.dn;
          this.topnData = data;
        }
        else if(data.type == "list_count") {
          this.countData = data;
        }
      }
    },
    websocketsend(Data){//数据发送
      this.websock.send(Data);
    },
    websocketclose(e){  //关闭
      console.log('断开连接',e);
    },
    getCountList(data) {
      let groupPie1 = {
        dropmalformation: data.group[0].dropmalformation / data.group1qps,
        dropblack: data.group[0].dropblack / data.group1qps,
        dropwild: data.group[0].dropwild / data.group1qps,
        droplimit: data.group[0].droplimit / data.group1qps
      }
      let groupPie2 = {
        dropmalformation: data.group[1].dropmalformation / data.group2qps,
        dropblack: data.group[1].dropblack / data.group2qps,
        dropwild: data.group[1].dropwild / data.group2qps,
        droplimit: data.group[1].droplimit / data.group2qps
      }

      this.initPieComponent('dropmalformation', 1, groupPie1.dropmalformation, "畸形报文命中", data.group[0].dropmalformation);
      this.initPieComponent('dropblack', 1, groupPie1.dropblack, "黑名单命中", data.group[0].dropblack);
      this.initPieComponent('dropwild', 1, groupPie1.dropwild, "通配名单命中", data.group[0].dropwild);
      this.initPieComponent('droplimit', 1, groupPie1.droplimit, "出口限速清洗", data.group[0].droplimit);

      this.initPieComponent('dropmalformation', 2, groupPie2.dropmalformation, "畸形报文命中", data.group[1].dropmalformation);
      this.initPieComponent('dropblack', 2, groupPie2.dropblack, "黑名单命中", data.group[1].dropblack);
      this.initPieComponent('dropwild', 2, groupPie2.dropwild, "通配名单命中", data.group[1].dropwild);
      this.initPieComponent('droplimit', 2, groupPie2.droplimit, "出口限速清洗", data.group[1].droplimit);
      
      if(!data.group[0].data || !data.group[1].data) {
        return false
      }
      
      let _qpsData = this.qpsData.concat(...data.group[0].data).slice(-300);
      let _bpsData = this.bpsData.concat(...data.group[1].data).slice(-300);

      this.qpsData = _qpsData;
      this.bpsData = _bpsData;


      this.initLineComponent('QPS', 1, _qpsData);
      this.initLineComponent('BPS', 1, _qpsData);

      this.initLineComponent('QPS', 2, _bpsData);
      this.initLineComponent('BPS', 2, _bpsData);

      this.screenData = {
        baseqps: data.baseqps,
        basebps: data.basebps,
        dropqps: data.dropqps,
        dropbps: data.dropbps
      }
      this.drawLine(1, parseInt(data.currentqps/data.baseqps*100).toFixed(2), data.currentqps, data.baseqps);
      this.drawLine(2, parseInt(data.currentbps/data.basebps*100).toFixed(2), data.currentbps, data.basebps);
      
      let lineDay = {
        name: "最近一周数据",
        dropdayqps: {
          name: "QPS",
          data: data.dropdayqps
        },
        dropdaybps: {
          name: "BPS",
          data: data.dropdaybps
        }
      }
      let lineWeek = {
        name: "最近8周数据",
        dropweekqps: {
          name: "QPS",
          data: data.dropweekqps
        },
        dropweekbps: {
          name: "BPS",
          data: data.dropweekbps
        }
      }
      let lineMonth = {
        name: "最近一年数据",
        dropmonthqps: {
          name: "QPS",
          data: data.dropmonthqps
        },
        dropmonthbps: {
          name: "BPS",
          data: data.dropmonthbps
        }
      }
      this.initLineDataComponent("lineDay", lineDay, ["dropdayqps", "dropdaybps"], data.dropday);
      this.initLineDataComponent("lineWeek", lineWeek, ["dropweekqps", "dropweekbps"], data.dropweek);
      this.initLineDataComponent("lineMonth", lineMonth, ["dropmonthqps", "dropmonthbps"], data.dropmonth);
    }
  },
  components: {
    // vueSeamlessScroll,
    // DigitRoll
  }
};
</script>
