<template>
  <div>
    <HeaderSelect></HeaderSelect>
    <div>
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{$route.meta.title}}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="table">
      <el-form :model="form">
        <el-form-item>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-date-picker v-model="form.timer"  type="datetimerange" align="left" start-placeholder="开始日期" end-placeholder="结束日期"  value-format="yyyy-MM-dd HH:mm:ss" :default-time="['00:00:00', '23:59:59']"></el-date-picker>
            </el-col>
            <el-col :span="2">
              <el-button type="primary" @click="serarch">查询</el-button>
            </el-col>
          </el-row>
        </el-form-item>
      </el-form>
      <el-table v-loading="loading" element-loading-text="数据加载中" element-loading-spinner="el-icon-loading" element-loading-background="rgba(0, 0, 0, 0.8)" ref="multipleTable" :data="nodeData.tableData" style="width: 100%" :max-height="(height-230)" row-key="nodeId" stripe>
        <el-table-column label="序号" prop="id" header-align="center" align="center" width="60"></el-table-column>
        <el-table-column label="告警内容" prop="alarminfo" header-align="center" align="center"></el-table-column>
        <el-table-column label="告警级别" prop="alarmlevel" header-align="center" align="center"></el-table-column>
        <!-- <el-table-column label="告警类别" prop="nm" header-align="center" align="center"></el-table-column> -->
        <el-table-column label="告警时间" prop="strtime" header-align="center" align="center"></el-table-column>
      </el-table>
      <el-pagination v-if="nodeData.total>0" @current-change="handleCurrentChange" :current-page.sync="thisPage" :page-size="20" layout="total, prev, pager, next, jumper" :total="nodeData.total"></el-pagination>
    </div>
  </div>
</template>

<style lang="sass" scoped>
  .table
    display: block
    overflow: hidden
    padding: 20px
    background-color: #fff
    .table-tool
      padding-bottom: 20px

  .el-menu
    background-color: #1d2336 !important
    &.el-menu--horizontal
      border-bottom: none

  .el-button-group
    padding-bottom: 20px
    button
      width: 100px

  .cell button
    width: 58px

  .dialog-footer button
    width: 80px

  .el-pagination
    float: right
    padding: 20px

  .el-select
    width: 100%
  
  /deep/ .el-range-editor
    width: 100%

  .tool-select
    float: left
    margin-right: 20px
    width: auto
  
  .el-checkbox
    color: #67c23a
  .w40
      width: 40px
  .noGroup
    color: #fff
  .el-col
    &.center
      text-align: center
  
  .info
    text-align: center

  .el-table__body
    tr
      padding: 0 !important
  
  .el-table--enable-row-hover .el-table__body tr>td
    background-color: #fff !important

  .expand_table
    background-color: #1d2336
    padding: 0 20px
    >div
      padding: 0
      &.header
        line-height: 40px
        color: #909399
        border-bottom: 1px solid #909399
      overflow: hidden
      padding: 0 40px 0 20px
      li
        padding: 0
        list-style: none
        float: left
        width: 100px
      &.list
        line-height: 40px
        &:hover
          color: #4c98d2
</style>


<script>
import utils from '@/lib/utils'
import config from "@/config";
import HeaderSelect from "@/components/HeaderUser.vue";
import moment from 'moment';

export default {
  data() {
    return {
      timer: null,
      height: 0,
      thisPage: 1,
      form: {
        timer: []
      },
      nodeData: {
        tableData: [],
        total: 0,
        totalPages: 1
      },
      loading: false,
      formLabelWidth: '70px'
    };
  },
  mounted() {
    this.height = window.innerHeight;
    window.onresize = () => {
      this.height = window.innerHeight;
    };
    // this.$loading(config.loading);
    this.getList();
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  methods: {
    getList(page, pagesize) {
      this.$loading(config.loading);
      let url =  config.url + "apis/alarm/page";
      let param = {
        "begin": this.form.timer[0] || "0000-00-00 00:00:00",
        "end": this.form.timer[1] || "0000-00-00 00:00:00",
        "currpage": page || 1,
        "pagesize": pagesize || 20
      }
      this.$http.post(url, param).then(res => {
        let data = res.data;
        if(data.status == 0) {
          let _nodeData = {
            tableData: data.data || [],
            total: data.total,
            totalPages: data.pagecount
          }
          // _nodeData.tableData.map((item, index)=>{
          //   _nodeData.tableData[index].alarmtime = moment(item.alarmtime).format("YYYY-MM-DD HH:mm:ss")
          // })
          this.nodeData = _nodeData;

        }
        else {
          // this.$message.error(data.msg);
        }
        this.$loading().close();
      })
      .catch(err => {
        this.$loading().close();
        console.log(err);
        // this.$message.error("请求接口失败");
      });
    },
    serarch() {
      this.thisPage = 1;
      this.getList(1);
    },
    handleCurrentChange(val) {
      this.thisPage = val;
      this.getList(val);
    }
  },
  components: {
    HeaderSelect
  }
};
</script>