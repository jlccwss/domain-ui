<template>
  <div>
    <HeaderSelect></HeaderSelect>
    <div>
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{$route.meta.title}}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="card">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>全局设置</span>
        </div>
        <el-form style="width: 600px;">
          <el-form-item label="当前模式" :label-width="formLabelWidth">
            <el-radio-group v-model="formGlobal.guard">
              <el-radio :label="0">透明传输</el-radio>
              <el-radio :label="1">正常防护</el-radio>
              <el-radio :label="2">应急预案</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="出口流量限制" :label-width="formLabelWidth">
            <!-- <el-col :span="4">
              <el-checkbox v-model="formGlobal.limiten" style="display: inline">启用</el-checkbox>
            </el-col> -->
            <el-col :span="18">
              <el-input v-model="formGlobal.limitcnt" clearable maxlength="28" v-only-number="{ min: 1, max: 1000 }" autocomplete="off">
                <template slot="append">KQPS</template>
              </el-input>
            </el-col>
            <el-col :span="6" style="padding-left: 10px;">
              范围1~1000
            </el-col>
          </el-form-item>
          <el-form-item label="DNS格式清洗" :label-width="formLabelWidth">
            <el-checkbox class="w100" v-model="formGlobal.dropany">Any</el-checkbox>
            <el-checkbox class="w100" v-model="formGlobal.formatcheck">畸形</el-checkbox>
          </el-form-item>
          <el-form-item label="DNS类型清洗" :label-width="formLabelWidth">
            <el-checkbox class="w100" v-model="formGlobal.droptcp">TCP</el-checkbox>
            <el-checkbox class="w100" v-model="formGlobal.dropudp">UDP</el-checkbox>
          </el-form-item>
          <el-form-item label="其它清洗" :label-width="formLabelWidth">
            <el-checkbox class="w100" v-model="formGlobal.dropping">禁止PING</el-checkbox>
            <el-checkbox class="w100" v-model="formGlobal.dropnodns">非DNS清洗</el-checkbox>
            <span>（只清洗TCP与UDP非DNS包）</span>
          </el-form-item>
          <el-form-item label="DNS端口" :label-width="formLabelWidth">
            <el-input v-model="formGlobal.dnsport" clearable maxlength="28" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" style="margin-left: 40px" @click="putGlobal">保存</el-button>
          </el-form-item>
        </el-form>
      </el-card>
    </div>
    <div class="card">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>名单配置</span>
        </div>
        <el-form style="width: 500px;">
          <el-row>
            <el-col :span="12">
              <el-form-item label="IP黑名单" :label-width="formLabelWidth">
                <el-checkbox v-model="formListen.ipblack">启用</el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="IP白名单" :label-width="formLabelWidth">
                <el-checkbox v-model="formListen.ipwhite">启用</el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="域名黑名单" :label-width="formLabelWidth">
                <el-checkbox v-model="formListen.dnblack">启用</el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="域名白名单" :label-width="formLabelWidth">
                <el-checkbox v-model="formListen.dnwhite">启用</el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="IP-PPTC名单" :label-width="formLabelWidth">
                <el-checkbox v-model="formListen.ippptc">启用</el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="域名-PPTC名单" :label-width="formLabelWidth">
                <el-checkbox v-model="formListen.dnpptc">启用</el-checkbox>
              </el-form-item>
            </el-col>            <el-col :span="12">
              <el-form-item label="域名通配清洗" :label-width="formLabelWidth">
                <el-checkbox v-model="formListen.wildcard">启用</el-checkbox>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item>
            <el-button type="primary" style="margin-left: 40px" @click="putListen">保存</el-button>
          </el-form-item>
        </el-form>
      </el-card>
    </div>
    <div class="card">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>告警阈值</span>
        </div>
        <el-form>
          <el-row>
            <el-col :span="8">
              <el-form-item label="BPS告警阈值" :label-width="formLabelWidth">
                <el-input v-model="formAlarm.basebps" clearable maxlength="28" autocomplete="off">
                  <template slot="append">QPS</template>
                </el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="QPS告警阈值" :label-width="formLabelWidth">
                <el-input v-model="formAlarm.baseqps" clearable maxlength="28" autocomplete="off">
                  <template slot="append">QPS</template>
                </el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="CPU告警阈值" :label-width="formLabelWidth">
                <el-input v-model="formAlarm.cpu" clearable v-only-number="{ min: 0, max: 90 }" autocomplete="off">
                  <template slot="append">%</template>
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="MEM告警阈值" :label-width="formLabelWidth">
                <el-input v-model="formAlarm.mem" clearable v-only-number="{ min: 0, max: 90 }" autocomplete="off">
                  <template slot="append">%</template>
                </el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="磁盘告警阈值" :label-width="formLabelWidth">
                <el-input v-model="formAlarm.disk" clearable v-only-number="{ min: 0, max: 90 }" autocomplete="off">
                  <template slot="append">%</template>
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item>
            <el-button type="primary" style="margin-left: 40px" @click="putAlarm">保存</el-button>
          </el-form-item>
        </el-form>
      </el-card>
    </div>
    <div class="card">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>告警邮件设置</span>
        </div>
        <el-form :model="form">
          <el-row>
            <el-col :span="12">
              <el-form-item label="发件邮箱" :label-width="formLabelWidth">
                <el-input v-model="sendMailData.email" clearable autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="发件邮箱密码" :label-width="formLabelWidth">
                <el-input v-model="sendMailData.passwd" show-password clearable autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="邮件服务器" :label-width="formLabelWidth">
                <el-input v-model="sendMailData.server" clearable autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="端口" :label-width="formLabelWidth">
                <el-input v-model="sendMailData.port" clearable autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item>
            <el-button type="primary" style="margin-left: 40px" @click="putSendmail">保存</el-button>
          </el-form-item>
          <el-divider></el-divider>
          <el-form-item>
            <el-row :gutter="20">
              <el-form-item>
                <el-button type="primary" size="mini" style="margin-left: 16px" @click="install">添加接收邮箱</el-button>
              </el-form-item>
            </el-row>
          </el-form-item>
        </el-form>
        <el-table v-loading="loading" element-loading-text="数据加载中" element-loading-spinner="el-icon-loading" element-loading-background="rgba(0, 0, 0, 0.8)" ref="multipleTable" :data="nodeData.tableData" style="width: 100%" :max-height="(height-230)" row-key="nodeId" stripe @selection-change="handleSelectionChange">
          <el-table-column label="编号" prop="id" header-align="center" align="center" width="100">
            <template slot-scope="scope">
              {{scope.$index+1}}
            </template>
          </el-table-column>
          <el-table-column label="邮箱地址" prop="email" header-align="center" align="center"></el-table-column>
          <!-- <el-table-column label="告警频率" prop="interval" header-align="center" align="center"></el-table-column>
          <el-table-column label="告警级别" prop="level" header-align="center" align="center"></el-table-column> -->
          <el-table-column label="创建时间 " prop="create" header-align="center" align="center"></el-table-column>
          <el-table-column fixed="right" label="操作" header-align="center" width="150">
            <template slot-scope="scope">
              <el-button size="mini" @click="editRow(scope.$index, nodeData.tableData)">修改</el-button>
              <el-button size="mini" type="danger" @click="deleteRow(scope.row.id)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination v-if="nodeData.total>0" @current-change="handleCurrentChange" :current-page.sync="thisPage" :page-size="20" layout="total, prev, pager, next, jumper" :total="nodeData.total"></el-pagination>
      </el-card>
    </div>
    <el-dialog :title="dialogTitle" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
      <el-form>
        <el-form-item label="邮箱地址" :label-width="formLabelWidth">
          <el-input v-model="formCannel.email" clearable maxlength="28" autocomplete="off"></el-input>
        </el-form-item>
        <!-- <el-form-item label="告警频率" :label-width="formLabelWidth">
          <el-input v-model="formCannel.interval" clearable maxlength="28" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="告警级别" :label-width="formLabelWidth">
          <el-select v-model="formCannel.level" placeholder="请选择">
            <el-option v-for="item in levelOption" :key="item.value" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-form-item> -->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="option">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<style lang="sass" scoped>
  .table
    display: block
    overflow: hidden
    padding: 20px
    background-color: #fff
    .table-tool
      padding-bottom: 20px

  .el-menu
    background-color: #1d2336 !important
    &.el-menu--horizontal
      border-bottom: none

  .el-button-group
    padding-bottom: 20px
    button
      width: 100px

  .cell button
    width: 58px

  .dialog-footer button
    width: 80px

  .el-pagination
    float: right
    padding: 20px

  .el-select
    width: 100%
  
  .el-menu-item
    min-width: 80px
    text-align: center
  
  /deep/ .el-range-editor
    width: 100%

  .tool-select
    float: left
    margin-right: 20px
    width: auto
  
  .el-checkbox
    color: #fff

  .el-radio
    color: #fff

  .w40
      width: 40px
  .noGroup
    color: #fff
  .el-col
    &.center
      text-align: center
  
  .info
    text-align: center

  .el-table__body
    tr
      padding: 0 !important
  
  .el-table--enable-row-hover .el-table__body tr>td
    background-color: #fff !important

  .expand_table
    background-color: #1d2336
    padding: 0 20px
    >div
      padding: 0
      &.header
        line-height: 40px
        color: #909399
        border-bottom: 1px solid #909399
      overflow: hidden
      padding: 0 40px 0 20px
      li
        padding: 0
        list-style: none
        float: left
        width: 100px
      &.list
        line-height: 40px
        &:hover
          color: #4c98d2
  .box
    overflow-y: scroll
    max-height: 400px
    &::-webkit-scrollbar
      width: 6px
      height: 6px
    &::-webkit-scrollbar-thumb
      width: 6px
      height: 6px
      background-color: rgb(76, 152, 210)
      background-clip: padding-box
      border-radius: 5px
  .myTable
    background-color: #DCDFE6
    color: #fff
    tr
      width: 100%
    th, td
      width: 10%
      text-align: center
      background-color: #1a2035;
      span
        display: block
        height: 20px
        line-height: 20px
        padding: 20px
  .hover
    display: block
    cursor: pointer
    color: #409EFF
    text-decoration: underline
    &:hover
      color: #fff
  .w100
    min-width: 85px
</style>


<script>
import utils from '@/lib/utils'
import config from "@/config";
import axios from 'axios'
import Qs from 'qs'
import HeaderSelect from "@/components/HeaderUser.vue";
import moment from 'moment';

export default {
  inject:['reload'],
  data() {
    return {
      timer: null,
      fullPath: this.$route.fullPath,
      height: 0,
      proGroupId: null,
      thisPage: 1,
      levelOption: [{
        value: "高",
        label: "高"
      },{
        value: "中",
        label: "中"
      },{
        value: "低",
        label: "低"
      }],
      form: {
        timer: null,
        search: null
      },
      formCannel: {
        email: null
        // interval: null,
        // level: "中"
      },
      formGlobal: {
        formatcheck: false,  // 畸形包清洗
        droptcp: false,      // TCP类型清洗
        dropudp: false,      // UDP类型清洗
        dropany: false,     // ANY类型清洗
        limiten: false,     // 出口限速
        dropnodns: false,
        dropping: false,
        limitcnt: 100,    // 出口限速数值
        dnsport: null,     // DNS端口
        guard: 1     // 0:透明传输, 1:正常防护, 2:应急预案
      },
      formAlarm: {
        basebps: null,
        baseqps: null,
        cpu: null,
        mem: null,
        disk: null
      },
      formListen: {
        ipblack: false,     // ip黑名单
        dnblack: false,  // 域名黑名单
        ipwhite: false,    // ip白名单
        dnwhite: false,  // 域名白名单
        ippptc: false,    // IP PPTC名单
        dnpptc: false,    // 域名PPTC名单
        wildcard: false   // 域名通配名单
      },
      formList: {
        id: null,
        oldlist: null,
        newlist: null,
        pptc: 0
      },
      opt: "post",
      elInput: null,
      expands: [],
      nodeData: {
        tableData: [],
        total: 0,
        totalPages: 1
      },
      sendMailData: {},
      loading: false,
      multipleSelection: [],
      dialogTitle: "添加告警方式",
      dialogFormVisible: false,
      formLabelWidth: '120px'
    };
  },
  mounted() {
    this.height = window.innerHeight;
    window.onresize = () => {
      this.height = window.innerHeight;
    };
    // this.$loading(config.loading);
    this.getGlobal();
    this.getListen();
    this.getAlarm();
    this.getList(1);
    this.getSendmail();
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  methods: {
    getGlobal() {
      let url =  config.url + "apis/config/global";
      let param = {};
      this.$http.get(url, param).then(res => {
        let data = res.data;
        this.formGlobal = {
          formatcheck: data.formatcheck == 1? true: false,
          droptcp: data.droptcp == 1? true: false,
          dropudp: data.dropudp == 1? true: false,
          dropany: data.dropany == 1? true: false,
          limiten: data.limiten == 1? true: false,
          dropnodns: data.dropnodns == 1? true: false,
          dropping: data.dropping == 1? true: false,
          limitcnt: +data.limitcnt || 0,
          dnsport: +data.dnsport || null,
          guard: +data.guard
        }
      })
      .catch(err => {
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    putGlobal() {
      let _formGlobal = this.formGlobal;
      let url =  config.url + "apis/config/global";
      let param = {
        formatcheck: _formGlobal.formatcheck? 1: 0,
        droptcp: _formGlobal.droptcp? 1: 0,
        dropudp: _formGlobal.dropudp? 1: 0,
        dropany: _formGlobal.dropany? 1: 0,
        limiten: _formGlobal.limiten? 1: 0,
        dropnodns: _formGlobal.dropnodns? 1: 0,
        dropping: _formGlobal.dropping? 1: 0,
        limitcnt: +_formGlobal.limitcnt || null,
        dnsport: +_formGlobal.dnsport || null,
        guard: +_formGlobal.guard
      };
      this.$http.put(url, param).then(res => {
        let data = res.data;
        if(data.status == 0) {
          this.$message.success("保存成功");
        }
        else {
          this.$message.error(data.msg);
        }
      });
    },
    getListen() {
      let url =  config.url + "apis/config/listen";
      let param = {};
      this.$http.get(url, param).then(res => {
        let data = res.data;
        this.formListen = {
          ipblack: data.ipblack == 1? true: false,
          dnblack: data.dnblack == 1? true: false,
          ipwhite: data.ipwhite == 1? true: false,
          dnwhite: data.dnwhite == 1? true: false,
          ippptc: data.ippptc == 1? true: false,
          dnpptc: data.dnpptc == 1? true: false,
          wildcard: data.wildcard == 1? true: false,
        }
      })
      .catch(err => {
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    putListen() {
      let _formListen = this.formListen;
      let url =  config.url + "apis/config/listen";
      let param = {
        ipblack: _formListen.ipblack == true? 1: 0,
        dnblack: _formListen.dnblack == true? 1: 0,
        ipwhite: _formListen.ipwhite == true? 1: 0,
        dnwhite: _formListen.dnwhite == true? 1: 0,
        ippptc: _formListen.ippptc == true? 1: 0,
        dnpptc: _formListen.dnpptc == true? 1: 0,
        wildcard: _formListen.wildcard == true? 1: 0,
      };
      this.$http.put(url, param).then(res => {
        let data = res.data;
        if(data.status == 0) {
          this.$message.success("保存成功");
        }
        else {
          this.$message.error(data.msg);
        }
      });
    },
    getAlarm() {
      let url =  config.url + "apis/config/alarm";
      let param = {};
      this.$http.get(url, param).then(res => {
        let data = res.data;
        this.formAlarm = {
          basebps: data.basebps,
          baseqps: data.baseqps,
          cpu: data.cpu,
          mem: data.mem,
          disk: data.disk
        }
      })
      .catch(err => {
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    putAlarm() {
      let _formAlarm = this.formAlarm;
      let url =  config.url + "apis/config/alarm";
      let param = {
        basebps: +_formAlarm.basebps,
        baseqps: +_formAlarm.baseqps,
        cpu: +_formAlarm.cpu,
        mem: +_formAlarm.mem,
        disk: +_formAlarm.disk
      };
      this.$http.put(url, param).then(res => {
        let data = res.data;
        if(data.status == 0) {
          this.$message.success("保存成功");
        }
        else {
          this.$message.error(data.msg);
        }
      });
    },
    getList() {
      // this.$loading(config.loading);
      let url =  config.url + "apis/config/channel";
      let param = {};
      this.$http.get(url, param).then(res => {
        let data = res.data;
        data.data = data.data || []
        data.data.map((item, index)=>{
          data.data[index].create = moment(item.create).format("YYYY-MM-DD HH:mm:ss");
        })
        let _nodeData = {
          tableData: data.data || [],
          total: data.total,
          totalPages: data.pagecount
        }
        this.nodeData = _nodeData;
        // this.$loading().close();
      })
      .catch(err => {
        // this.$loading().close();
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    install() {
      this.dialogTitle = "添加接收邮箱";
      this.formCannel = {
        email: null,
        interval: null,
        level: "中"
      };
      this.opt = "post";
      this.dialogFormVisible = true;
    },
    option(key) {
      if(this.opt == "post") {
        let url =  config.url + "apis/config/channel";
        let param = this.formCannel;
        if(!param.email) {
          this.$message.error("邮箱地址不能为空");
          return false;
        }
        // if(!param.interval) {
        //   this.$message.error("告警频率不能为空");
        //   return false;
        // }
        param.interval = +param.interval;
        this.$http.post(url, param).then(res => {
          let data = res.data;
          if(data.status == 0) {
            this.getList();
            this.$message.success("添加成功");
            this.dialogFormVisible = false;
          }
          else {
            this.$message.error(data.msg);
          }
        })
        .catch(err => {
          console.log(err);
          // this.$message.error("请求接口失败");
          this.$message.error(err.response.data.error);
        });
      }
      else if(this.opt == "put") {
        let url =  config.url + "apis/config/channel";
        let param = this.formCannel;
        if(!param.email) {
          this.$message.error("邮箱地址不能为空");
          return false;
        }
        // if(!param.interval) {
        //   this.$message.error("告警频率不能为空");
        //   return false;
        // }
        param.interval = +param.interval;
        this.$http.put(url, param).then(res => {
          let data = res.data;
          if(data.status == 0) {
            this.getList();
            this.$message.success("修改成功");
            this.dialogFormVisible = false;
          }
          else {
            this.$message.error(data.msg);
          }
        })
        .catch(err => {
          console.log(err);
          // this.$message.error("请求接口失败");
          this.$message.error(err.response.data.error);
        });
      }
      else if(this.opt == "delete") {
        let url =  config.url + "apis/config/channel/" + key;
        let param = {};
        this.$http.delete(url, param).then(res => {
          let data = res.data;
          if(data.status == 0) {
            this.getList();
            this.$message.success("删除成功");
            this.dialogFormVisible = false;
          }
          else {
            this.$message.error(data.msg);
          }
        })
        .catch(err => {
          console.log(err);
          // this.$message.error("请求接口失败");
          this.$message.error(err.response.data.error);
        });
      }
      else if(this.opt == "deleteDatch") {
        let _list = [];
        this.multipleSelection.map((item) => {
          _list.push(item.key);
        })
        let url =  config.url + "apis/wildcard/batch";
        let param = {
          list: _list
        };
        this.$http.delete(url, {data:param}).then(res => {
          let data = res.data;
          if(data.status == 0) {
            this.getList();
            this.$message.success("删除成功");
            this.dialogFormVisible = false;
          }
          else {
            this.$message.error(data.msg);
          }
        })
        .catch(err => {
          console.log(err);
          // this.$message.error("请求接口失败");
        });
      }
    },

    serarch() {
      this.thisPage = 1;
      this.getList(1);
    },

    editRow(index, rows) {
      this.dialogTitle = "修改接收邮箱";
      this.elInput = rows[index].key;
      this.opt = "put";
      this.formCannel = {
        id: rows[index].id,
        email: rows[index].email
        // interval: rows[index].interval,
        // level: rows[index].level
      }
      this.dialogFormVisible = true;
    },

    deleteRow(key) {
      this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.opt = "delete";
        this.option(key);
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });          
      });
    },

    deleteDatch() {
      this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消', 
        type: 'warning'
      }).then(() => {
        if(this.multipleSelection) {
          this.opt = "deleteDatch";
          this.option();
        }
        else {
          this.$message.error("请选择需要删除的记录");
        }
        // rows.splice(index, 1);
      }).catch((e) => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });          
      });
    },
    getSendmail() {
      let url =  config.url + "apis/config/sendmail";
      let param = {};
      this.$http.get(url, param).then(res => {
        let data = res.data;
        this.sendMailData = data;
        // this.$loading().close();
      })
      .catch(err => {
        // this.$loading().close();
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    putSendmail() {
      let url =  config.url + "apis/config/sendmail";
      let param = this.sendMailData;
      param.port = +param.port;
      this.$http.put(url, param).then(res => {
        let data = res.data;
        if(data.status == 0) {
          this.$message.success("修改成功");
        }
        else {
          this.$message.error(data.msg);
        }
        // this.$loading().close();
      })
      .catch(err => {
        // this.$loading().close();
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    
    handleCurrentChange(val) {
      this.thisPage = val;
      this.getList(val);
    },

    handleSelectionChange(val) {
      // 表格多选
      this.multipleSelection = val;
    },
  },
  components: {
    HeaderSelect
  }
};
</script>