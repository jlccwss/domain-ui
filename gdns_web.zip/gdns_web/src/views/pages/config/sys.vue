<template>
  <div>
    <HeaderSelect></HeaderSelect>
    <div>
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{$route.meta.title}}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="card">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>管理接口IP</span>
        </div>
        <el-form>
          <el-row :gutter="20" style="text-align: center; padding-bottom: 20px;">
            <el-col :span="3">
              类型
            </el-col>
            <el-col :span="7">
              IP地址
            </el-col>
            <el-col :span="7">
              子网掩码
            </el-col>
            <el-col :span="7">
              网关
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="3">
              <el-form-item style="text-align:center">
                IPV4
              </el-form-item>
            </el-col>
            <el-col :span="7">
              <el-input v-model="formIP.v4ip" clearable autocomplete="off"></el-input>
            </el-col>
            <el-col :span="7">
              <el-input v-model="formIP.v4mask" clearable autocomplete="off"></el-input>
            </el-col>
            <el-col :span="7">
              <el-input v-model="formIP.v4gateway" clearable autocomplete="off"></el-input>
            </el-col>
          </el-row>
          <!-- <el-row :gutter="20">
            <el-col :span="3">
              <el-form-item style="text-align:center">
                IPV6
              </el-form-item>
            </el-col>
            <el-col :span="7">
              <el-input v-model="formIP.v6ip" clearable autocomplete="off"></el-input>
            </el-col>
            <el-col :span="7">
              <el-input v-model="formIP.v6mask" clearable autocomplete="off"></el-input>
            </el-col>
            <el-col :span="7">
              <el-input v-model="formIP.v6gateway" clearable autocomplete="off"></el-input>
            </el-col>
          </el-row> -->
          <el-row :gutter="20">
            <el-col :span="3">
              <el-form-item>
                <el-button type="primary" style="margin-left: 40px" @click="putIP">保存</el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </el-card>
    </div>
    <!-- <div class="card">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>SNMP</span>
        </div>
        <el-form>
          <el-row :gutter="20">
            <el-col :span="8">
              <el-form-item label="版本" :label-width="formLabelWidth">
                <el-input v-model="formSnmp.version" clearable autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="community" :label-width="formLabelWidth">
                <el-input v-model="formSnmp.community" clearable autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="类型" :label-width="formLabelWidth">
                <el-input v-model="formSnmp.type" clearable autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="trap使能" :label-width="formLabelWidth">
                <el-input v-model="formSnmp.trap" clearable autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="16">
              <el-form-item label="host" :label-width="formLabelWidth">
                <el-input v-model="formSnmp.host" clearable autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item>
            <el-button type="primary" style="margin-left: 40px" @click="putSnmp">保存</el-button>
          </el-form-item>
        </el-form>
      </el-card>
    </div> -->
    <div class="card">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>系统升级（注：升级成功后会重启服务，对流量无影响。）</span>
        </div>
        <el-steps :active="step" align-center>
          <el-step title="上传目前版本"></el-step>
          <el-step title="开始升级"></el-step>
          <el-step title="升级完成"></el-step>
        </el-steps>
        <el-row style="text-align:center; padding-top: 20px;">
          <el-col :span="24">
            <el-upload v-if="step == 1" :action="UploadUrl()" accept=".tar" :show-file-list="false" :before-upload="beforeUpload" :on-success="handleAvatarSuccess" :on-error="handleAvatarError">
              <el-button type="primary">选择文件</el-button>
            </el-upload>
            <el-button v-if="step == 2" type="primary" @click="upgrade(filepath)">开始升级</el-button>
            <div v-if="count != 0">重启服务倒计时：{{count}}s</div>
          </el-col>
        </el-row>
      </el-card>
    </div>
  </div>
</template>

<style lang="sass" scoped>
  .table
    display: block
    overflow: hidden
    padding: 20px
    background-color: #fff
    .table-tool
      padding-bottom: 20px

  .el-menu
    background-color: #1d2336 !important
    &.el-menu--horizontal
      border-bottom: none

  .el-button-group
    padding-bottom: 20px
    button
      width: 100px

  .cell button
    width: 58px

  .dialog-footer button
    width: 80px

  .el-pagination
    float: right
    padding: 20px

  .el-select
    width: 100%
  
  .el-menu-item
    min-width: 80px
    text-align: center
  
  /deep/ .el-range-editor
    width: 100%

  .tool-select
    float: left
    margin-right: 20px
    width: auto
  
  .el-checkbox
    color: #fff

  .el-radio
    color: #fff

  .w40
      width: 40px
  .noGroup
    color: #fff
  .el-col
    &.center
      text-align: center
  
  .info
    text-align: center

  .el-table__body
    tr
      padding: 0 !important
  
  .el-table--enable-row-hover .el-table__body tr>td
    background-color: #fff !important

  .expand_table
    background-color: #1d2336
    padding: 0 20px
    >div
      padding: 0
      &.header
        line-height: 40px
        color: #909399
        border-bottom: 1px solid #909399
      overflow: hidden
      padding: 0 40px 0 20px
      li
        padding: 0
        list-style: none
        float: left
        width: 100px
      &.list
        line-height: 40px
        &:hover
          color: #4c98d2
  .box
    overflow-y: scroll
    max-height: 400px
    &::-webkit-scrollbar
      width: 6px
      height: 6px
    &::-webkit-scrollbar-thumb
      width: 6px
      height: 6px
      background-color: rgb(76, 152, 210)
      background-clip: padding-box
      border-radius: 5px
  .myTable
    background-color: #DCDFE6
    color: #fff
    tr
      width: 100%
    th, td
      width: 10%
      text-align: center
      background-color: #1a2035;
      span
        display: block
        height: 20px
        line-height: 20px
        padding: 20px
  .hover
    display: block
    cursor: pointer
    color: #409EFF
    text-decoration: underline
    &:hover
      color: #fff
  /deep/ .el-step
    .el-step__title
      &.is-process
        color: #fff
</style>


<script>
import store from "@/store";
import utils from '@/lib/utils'
import config from "@/config";
import axios from 'axios'
import Qs from 'qs'
import HeaderSelect from "@/components/HeaderUser.vue";
import moment from 'moment';

export default {
  inject:['reload'],
  data() {
    return {
      timer: null,
      timerOut: null,
      count: 0,
      fullPath: this.$route.fullPath,
      height: 0,
      thisPage: 1,
      form: {
        timer: null,
        search: null
      },
      formIP: {
        v4ip: null,
        v4mask: null,
        v4gateway: null,
        v6ip: null,
        v6mask: null,
        v6gateway: null
      },
      formSnmp: {
        version: null,
        community: null,
        type: null,
        trap: null,
        host: null
      },
      step: 1,
      filepath: null,
      loading: false,
      formLabelWidth: '120px'
    };
  },
  mounted() {
    this.height = window.innerHeight;
    window.onresize = () => {
      this.height = window.innerHeight;
    };
    // this.$loading(config.loading);
    this.getIP();
    this.getSnmp();
  },
  beforeDestroy() {
    clearInterval(this.timer);
    clearInterval(this.timerOut);
  },
  methods: {
    getIP() {
      let url =  config.url + "apis/system/ip";
      let param = {};
      this.$http.get(url, param).then(res => {
        let data = res.data;
        this.formIP = {
          v4ip: data.v4ip,
          v4mask: data.v4mask,
          v4gateway: data.v4gateway,
          v6ip: data.v6ip,
          v6mask: data.v6mask,
          v6gateway: data.v6gateway
        }
      })
      .catch(err => {
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    putIP() {
      let _formIP = this.formIP;
      let url =  config.url + "apis/system/ip";
      let param = {
        v4ip: _formIP.v4ip,
        v4mask: _formIP.v4mask,
        v4gateway: _formIP.v4gateway,
        v6ip: _formIP.v6ip,
        v6mask: _formIP.v6mask,
        v6gateway: _formIP.v6gateway
      };
      this.$http.put(url, param).then(res => {
        let data = res.data;
        if(data.status == 0) {
          this.$message.success("保存成功");
        }
        else {
          this.$message.error(data.msg);
        }
      });
    },
    getSnmp() {
      let url =  config.url + "apis/system/snmp";
      let param = {};
      this.$http.get(url, param).then(res => {
        let data = res.data;
        this.formSnmp = {
          version: data.version,
          community: data.community,
          type: data.type,
          trap: data.trap,
          host: data.host
        }
      })
      .catch(err => {
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    putSnmp() {
      let _formSnmp = this.formSnmp;
      let url =  config.url + "apis/system/snmp";
      let param = {
        version: _formSnmp.version,
        community: _formSnmp.community,
        type: _formSnmp.type,
        trap: _formSnmp.trap,
        host: _formSnmp.host
      };
      this.$http.put(url, param).then(res => {
        let data = res.data;
        if(data.status == 0) {
          this.$message.success("保存成功");
        }
        else {
          this.$message.error(data.msg);
        }
      });
    },
    upgrade(filepath) {
      this.$loading(config.loading);
      // this.step = 2;
      let url =  config.url + "apis/system/upgrade";
      let param = {
        filepath: filepath
      };
      this.$http.post(url, param).then(res => {
        let data = res.data;
        this.$loading().close();
        if(data.status == 0) {
          this.step = 3;
          if(!this.timerOut){
            this.count = 10;
            this.timerOut = setInterval(()=>{
              this.count--;
              if(this.count == 0){
                // this.dialogTableVisible3 = false;
                clearInterval(this.timerOut);
                this.timerOut = null;
                store.state.token = "";
                sessionStorage.removeItem("userName");
                this.$router.push({ path: "/login" });
              }
            },1000)
          }
          this.$message.success("升级成功");
        }
        else {
          this.$message.error(data.msg);
        }
      });
    },
    UploadUrl() {
      return config.url + "apis/upload";
    },
    beforeUpload(file) {
    },
    handleAvatarSuccess(res, file) {
      if(res.status == 0) {
      // if(res.filepath) {
        this.step = 2;
        this.filepath = res.filepath;
      }
      else {
        this.$message.error(res.msg);
      }
    },
    handleAvatarError(res, file) {
      this.$message.error(JSON.parse(String(res).replace("Error:","")).error);
    },
  },
  components: {
    HeaderSelect
  }
};
</script>