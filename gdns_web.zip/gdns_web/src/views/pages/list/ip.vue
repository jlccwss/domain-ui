<template>
  <div>
    <HeaderSelect></HeaderSelect>
    <div>
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{$route.meta.title}}</el-breadcrumb-item>
        <el-breadcrumb-item v-if="$route.query.type == 'ipblack'">IP黑名单</el-breadcrumb-item>
        <el-breadcrumb-item v-else-if="$route.query.type == 'dnblack'">域名黑名单</el-breadcrumb-item>
        <el-breadcrumb-item v-else-if="$route.query.type == 'ipwhite'">IP白名单</el-breadcrumb-item>
        <el-breadcrumb-item v-else-if="$route.query.type == 'dnwhite'">域名白名单</el-breadcrumb-item>
        <el-breadcrumb-item v-else-if="$route.query.type == 'ippptc'">IP PPTC</el-breadcrumb-item>
        <el-breadcrumb-item v-else-if="$route.query.type == 'dnpptc'">域名PPTC</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="table">
      <el-form :model="form">
        <el-form-item>
          <el-row :gutter="20">
            <el-col :span="15">
              <el-button type="primary" @click="install">添加</el-button>
              <!-- <el-button type="primary">导入名单</el-button> -->
              <el-upload v-if="$route.query.type != 'ippptc' && $route.query.type != 'dnpptc'" class="avatar-uploader" style="display: inline-block; padding: 0 10px" :action="UploadUrl()" accept=".txt" :show-file-list="false" :before-upload="beforeAvatarUpload" :on-success="handleAvatarSuccess" :on-error="handleAvatarError">
                <el-button type="primary">导入名单</el-button>
              </el-upload>
              <el-button type="primary" @click="flush">清空</el-button>
              <el-button type="primary" @click="deleteDatch" :disabled="multipleSelection==0">删除</el-button>
            </el-col>
            <el-col :span="6" style="text-align: right;">
              <el-input type="text" :placeholder="'请输入' + pageName + '地址'" v-model="form.search" clearable autocomplete="off"></el-input>
            </el-col>
            <el-col :span="2">
              <el-button type="primary" @click="serarch">查询</el-button>
            </el-col>
          </el-row>
        </el-form-item>
      </el-form>
      <el-table v-loading="loading" element-loading-text="数据加载中" element-loading-spinner="el-icon-loading" element-loading-background="rgba(0, 0, 0, 0.8)" ref="multipleTable" :data="nodeData.tableData" style="width: 100%" :max-height="(height-230)" row-key="nodeId" stripe @selection-change="handleSelectionChange">
        <el-table-column fixed type="selection" header-align="center" align="center"></el-table-column>
        <el-table-column label="编号" prop="id" header-align="center" align="center" width="60"></el-table-column>
        <el-table-column :label="pageName + '地址'" prop="key" header-align="center" align="center"></el-table-column>
        <el-table-column v-if="$route.query.type == 'ippptc' || $route.query.type == 'dnpptc'" label="阀值(KQPS)" prop="value" header-align="center" align="center"></el-table-column>
        <el-table-column fixed="right" label="操作" header-align="center" width="150">
          <template slot-scope="scope">
            <el-button size="mini" @click="editRow(scope.$index, nodeData.tableData)">修改</el-button>
            <el-button size="mini" type="danger" @click="deleteRow(scope.row.key)">删除</el-button>
          </template>
        </el-table-column>
        <el-table-column label="创建时间" prop="strtime" header-align="center" align="center"></el-table-column>
      </el-table>
      <el-pagination v-if="nodeData.total>0" @current-change="handleCurrentChange" :current-page.sync="thisPage" :page-size="20" layout="total, prev, pager, next, jumper" :total="nodeData.total"></el-pagination>
    </div>
    <el-dialog :title="dialogTitle" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
      <el-form>
        <el-form-item :label="pageName" :label-width="formLabelWidth">
          <el-input v-model="elInput" clearable maxlength="256" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item v-if="$route.query.type == 'ippptc' || $route.query.type == 'dnpptc'" :label="'阀值'" :label-width="formLabelWidth">
          <el-input v-model="formList.pptc" clearable maxlength="28" v-only-number="{ min: 1, max: 100 }" autocomplete="off">
            <template slot="append">KQPS</template>
          </el-input>
          阀值范围1~100
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button v-if="$route.query.type == 'ippptc' || $route.query.type == 'dnpptc'" type="primary" @click="option">确 定</el-button>
        <el-button v-else type="primary" @click="option" :disabled="opt=='put' && formList.oldlist == elInput">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<style lang="sass" scoped>
  .table
    display: block
    overflow: hidden
    padding: 20px
    background-color: #fff
    .table-tool
      padding-bottom: 20px

  .el-menu
    background-color: #1d2336 !important
    &.el-menu--horizontal
      border-bottom: none

  .el-button-group
    padding-bottom: 20px
    button
      width: 100px

  .cell button
    width: 58px

  .dialog-footer button
    width: 80px

  .el-pagination
    float: right
    padding: 20px

  .el-select
    width: 100%
  
  .el-menu-item
    min-width: 80px
    text-align: center
  
  /deep/ .el-range-editor
    width: 100%

  .tool-select
    float: left
    margin-right: 20px
    width: auto
  
  .el-checkbox
    color: #67c23a
  .w40
      width: 40px
  .noGroup
    color: #fff
  .el-col
    &.center
      text-align: center
  
  .info
    text-align: center

  .el-table__body
    tr
      padding: 0 !important
  
  .el-table--enable-row-hover .el-table__body tr>td
    background-color: #fff !important

  .expand_table
    background-color: #1d2336
    padding: 0 20px
    >div
      padding: 0
      &.header
        line-height: 40px
        color: #909399
        border-bottom: 1px solid #909399
      overflow: hidden
      padding: 0 40px 0 20px
      li
        padding: 0
        list-style: none
        float: left
        width: 100px
      &.list
        line-height: 40px
        &:hover
          color: #4c98d2
  .box
    overflow-y: scroll
    max-height: 400px
    &::-webkit-scrollbar
      width: 6px
      height: 6px
    &::-webkit-scrollbar-thumb
      width: 6px
      height: 6px
      background-color: rgb(76, 152, 210)
      background-clip: padding-box
      border-radius: 5px
  .myTable
    background-color: #DCDFE6
    color: #fff
    tr
      width: 100%
    th, td
      width: 10%
      text-align: center
      background-color: #1a2035;
      span
        display: block
        height: 20px
        line-height: 20px
        padding: 20px
  .hover
    display: block
    cursor: pointer
    color: #409EFF
    text-decoration: underline
    &:hover
      color: #fff
</style>


<script>
import utils from '@/lib/utils'
import config from "@/config";
import axios from 'axios'
import Qs from 'qs'
import HeaderSelect from "@/components/HeaderUser.vue";
import moment from 'moment';

export default {
  inject:['reload'],
  data() {
    return {
      timer: null,
      type: null,
      fullPath: this.$route.fullPath,
      height: 0,
      pageName: this.$route.name == "list_dn"? "域名" :"IP",
      proGroupId: null,
      thisPage: 1,
      form: {
        timer: null,
        search: null
      },
      formList: {
        id: null,
        oldlist: null,
        newlist: null,
        pptc: 0
      },
      opt: "post",
      elInput: null,
      expands: [],
      nodeData: {
        tableData: [],
        total: 0,
        totalPages: 1
      },
      filepath: null,
      generateState: false,
      loading: false,
      multipleSelection: [],
      dialogTitle: "添加",
      dialogFormVisible: false,
      formLabelWidth: '70px'
    };
  },
  mounted() {
    this.height = window.innerHeight;
    window.onresize = () => {
      this.height = window.innerHeight;
    };
    // this.$loading(config.loading);
    // console.log(this.$route)
    this.getList(1);
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  watch: {
    '$route' (to, from) {
      this.pageName = this.$route.name == "list_dn"? "域名" :"IP";
      this.form.search = null;
      this.getList(1);
      // this.reload()
    }
  },
  methods: {
    getList(page, pagesize) {
      // this.$loading(config.loading);
      let url =  config.url + "apis/" + this.$route.query.type + "/list/page";
      let param = {
        "list": this.form.search || "",
        "currpage": page || 1,
        "pagesize": pagesize || 20
      }
      this.$http.post(url, param).then(res => {
        let data = res.data;
        // data.data.map((item, index)=>{
        //   data.data[index].time = moment(item.time).format("YYYY-MM-DD HH:mm:ss");
        // })
        let _nodeData = {
          tableData: data.data || [],
          total: data.total,
          totalPages: data.pagecount
        }
        this.nodeData = _nodeData;
        // this.$loading().close();
      })
      .catch(err => {
        // this.$loading().close();
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },
    install() {
      this.dialogTitle = "添加" + this.pageName;
      this.elInput = null;
      this.opt = "post";
      this.dialogFormVisible = true;
    },

    option(key) {
      let _list = this.elInput;
      if(this.opt == "post") {
        let url =  config.url + "apis/" + this.$route.query.type + "/list";
        if(!_list) {
          this.$message.error(this.pageName + "地址不能为空");
          return false;
        }
        let param = {
          "list": _list || "",
          "pptc": +this.formList.pptc || 0
        }
        this.$http.post(url, param).then(res => {
          let data = res.data;
          if(data.status == 0) {
            this.getList();
            this.$message.success("添加成功");
            this.dialogFormVisible = false;
          }
          else {
            this.$message.error(data.msg);
          }
        })
        .catch(err => {
          console.log(err);
          // this.$message.error("请求接口失败");
          this.$message.error(err.response.data.error);
        });
      }
      else if(this.opt == "put") {
        let url =  config.url + "apis/" + this.$route.query.type + "/list";
        let _formList = this.formList;
        _formList.newlist = this.elInput;
        _formList.pptc = +_formList.pptc
        if(!_formList.newlist) {
          this.$message.error(this.pageName + "地址不能为空");
          return false;
        }
        let param = _formList;
        this.$http.put(url, param).then(res => {
          let data = res.data;
          if(data.status == 0) {
            this.getList();
            this.$message.success("修改成功");
            this.dialogFormVisible = false;
          }
          else {
            this.$message.error(data.msg);
          }
        })
        .catch(err => {
          console.log(err);
          // this.$message.error("请求接口失败");
          this.$message.error(err.response.data.error);
        });
      }
      else if(this.opt == "delete") {
        let url =  config.url + "apis/" + this.$route.query.type + "/list/" + key;
        let param = {};
        this.$http.delete(url, param).then(res => {
          let data = res.data;
          if(data.status == 0) {
            this.getList();
            this.$message.success("删除成功");
            this.dialogFormVisible = false;
          }
          else {
            this.$message.error(data.msg);
          }
        })
        .catch(err => {
          console.log(err);
          // this.$message.error("请求接口失败");
          this.$message.error(err.response.data.error);
        });
      }
      else if(this.opt == "deleteDatch") {
        let _list = [];
        this.multipleSelection.map((item) => {
          _list.push(item.key);
        })
        let url =  config.url + "apis/" + this.$route.query.type + "/batch";
        let param = {
          list: _list
        };
        this.$http.delete(url, {data:param}).then(res => {
          let data = res.data;
          if(data.status == 0) {
            this.getList();
            this.$message.success("删除成功");
            this.dialogFormVisible = false;
          }
          else {
            this.$message.error(data.msg);
          }
        })
        .catch(err => {
          console.log(err);
          // this.$message.error("请求接口失败");
        });
      }
      else if(this.opt == "flush") {
        this.$loading(config.loading);
        let url =  config.url + "apis/" + this.$route.query.type + "/flush";
        let param = {};
        this.$http.delete(url, {data:param}).then(res => {
          let data = res.data;
          this.$loading().close();
          if(data.status == 0) {
            this.getList();
            this.$message.success("清空成功");
            this.dialogFormVisible = false;
          }
          else {
            this.$message.error(data.msg);
          }
        })
        .catch(err => {
          console.log(err);
          // this.$message.error("请求接口失败");
        });
      }
    },

    serarch() {
      this.thisPage = 1;
      this.getList(1);
    },

    editRow(index, rows) {
      this.dialogTitle = "修改" + this.pageName;
      this.elInput = rows[index].key;
      this.opt = "put";
      this.formList = {
        id: rows[index].id,
        oldlist: rows[index].key,
        newlist: null,
        pptc: +rows[index].value || 0
      }
      this.dialogFormVisible = true;
    },

    deleteRow(key) {
      this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.opt = "delete";
        this.option(key);
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });          
      });
    },

    deleteDatch() {
      this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消', 
        type: 'warning'
      }).then(() => {
        if(this.multipleSelection) {
          this.opt = "deleteDatch";
          this.option();
        }
        else {
          this.$message.error("请选择需要删除的记录");
        }
        // rows.splice(index, 1);
      }).catch((e) => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });          
      });
    },

    flush() {
      this.$confirm('此操作将永久清空该记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消', 
        type: 'warning'
      }).then(() => {
        if(this.multipleSelection) {
          this.opt = "flush";
          this.option();
        }
        else {
          this.$message.error("请选择需要删除的记录");
        }
        // rows.splice(index, 1);
      }).catch((e) => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });          
      });
    },
    
    handleCurrentChange(val) {
      this.thisPage = val;
      this.getList(val);
    },

    handleSelectionChange(val) {
      // 表格多选
      this.multipleSelection = val;
    },

    UploadUrl() {
      return config.url + "apis/upload";
      // return config.url + "apis/" + this.$route.query.type + "/import";
    },
    beforeAvatarUpload(file) {
      this.$loading(config.loading);
    },
    handleAvatarSuccess(res, file) {
      // console.log(res)
      if(res.status == 0) {
      // if(res.filepath) {
        let url =  config.url + "apis/" + this.$route.query.type + "/import";
        let param = {
          filepath: res.filepath
        };
        this.$http.post(url, param).then(res => {
          this.$loading().close()
          let data = res.data;
          if(data.success > 0) {
            this.getList(this.thisPage);
          }
          let filename = data.filepath? data.filepath.split('/'): "";
          this.filepath = data.filepath || null;
          if(filename.length > 1) {
            filename = filename[filename.length - 1];
          }
          let html = data.filepath? '成功：' + data.success + '；失败：' + data.fail + '；结果文件：<a href="javascript:;">' + filename + '</a>': '成功：' + data.success + '；失败：' + data.fail + '；'
          let _message = this.$message({
            showClose: true,
            dangerouslyUseHTMLString: true,
            message: html,
            type: 'success',
            duration: 0
          });
          _message.$el.querySelector('a').onclick = () => {
            // let filepath = _message.$el.querySelector('a').innerHTML;
            let url =  config.url + "apis/download";
            let param = {
              filepath: this.filepath
            }
            
            this.$http.post(url, param).then(res => {
              let data = res.data;
              let _fileName = _message.$el.querySelector('a').innerHTML.split('/');
              this.download(_fileName[_fileName.length - 1] || "download.txt", String(data));
            })
            .catch(err => {
              console.log(err);
              // this.$message.error("请求接口失败");
              this.$message.error(err.response.data.error);
            });
          };
        })
        .catch(err => {
          console.log(err);
          // this.$message.error("请求接口失败");
        });
      }
      else {
        this.$message.error(res.msg);
      }
    },
    handleAvatarError(res, file) {
      this.$message.error(JSON.parse(String(res).replace("Error:","")).error);
    },
    download(filename, text) {
      var element = document.createElement('a');
      element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
      element.setAttribute('download', filename);
    
      element.style.display = 'none';
      document.body.appendChild(element);
    
      element.click();
    
      document.body.removeChild(element);
    }
  },
  components: {
    HeaderSelect
  }
};
</script>