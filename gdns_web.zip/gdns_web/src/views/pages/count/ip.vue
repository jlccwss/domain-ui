<template>
  <div>
    <HeaderSelect></HeaderSelect>
    <div>
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{$route.meta.title}}</el-breadcrumb-item>
        <el-breadcrumb-item>{{$route.meta.subtitle}}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="table">
      <el-form :model="form">
        <el-form-item>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-date-picker v-model="form.timer"  type="datetimerange" align="left" start-placeholder="开始日期" end-placeholder="结束日期"  value-format="yyyy-MM-dd HH:mm:ss" :default-time="['00:00:00', '23:59:59']"></el-date-picker>
            </el-col>
            <el-col :span="6">
              <el-input type="text" :placeholder="'请输入' + pageName + '地址'" v-model="form.search" clearable autocomplete="off"></el-input>
            </el-col>
            <el-col :span="2">
              <el-button type="primary" @click="serarch">查询</el-button>
            </el-col>
          </el-row>
        </el-form-item>
      </el-form>
      <div class="table-tool">
        <el-button v-if="$route.name == 'count_ip'" type="primary" @click="batch('ippptc')" :disabled="multipleSelection==0">添加到PPTC名单</el-button>
        <el-button v-if="$route.name == 'count_ip'" type="primary" @click="batch('ipwhite')" :disabled="multipleSelection==0">添加到IP白名单</el-button>
        <el-button v-if="$route.name == 'count_ip'" type="primary" @click="batch('ipblack')" :disabled="multipleSelection==0">添加到IP黑名单</el-button>
        <el-button v-if="$route.name == 'count_dn'" type="primary" @click="batch('dnpptc')" :disabled="multipleSelection==0">添加到PPTC名单</el-button>
        <el-button v-if="$route.name == 'count_dn'" type="primary" @click="batch('dnwhite')" :disabled="multipleSelection==0">添加到域名白名单</el-button>
        <el-button v-if="$route.name == 'count_dn'" type="primary" @click="batch('dnblack')" :disabled="multipleSelection==0">添加到域名黑名单</el-button>
      </div>
      <el-table v-loading="loading" element-loading-text="数据加载中" element-loading-spinner="el-icon-loading" element-loading-background="rgba(0, 0, 0, 0.8)" ref="multipleTable" :data="nodeData.tableData" style="width: 100%" stripe @selection-change="handleSelectionChange" :key="$route.name">
        <el-table-column fixed type="selection" header-align="center" align="center"></el-table-column>
        <el-table-column fixed label="编号" prop="id" header-align="center" align="center" width="100"></el-table-column>
        <el-table-column :label="pageName + '地址'" prop="key" header-align="center" align="center" min-width="400">
          <template slot-scope="scope">
            <el-tooltip v-if="$route.name == 'count_dn' && scope.row.key.length>40"  effect="dark" :content="scope.row.key" placement="top">
              <span :class="scope.row.illegal == 1 || scope.row.incomplete == 1?'red':''">
                {{scope.row.key.length>40?scope.row.key.slice(0, 40) +"...":scope.row.key}}
            </span>
            </el-tooltip>
            <span v-else-if="$route.name == 'count_dn'" :class="scope.row.illegal == 1 || scope.row.incomplete == 1?'red':''">{{scope.row.key}}</span>
            <span v-else>{{scope.row.key}}</span>
          </template>
        </el-table-column>
        <el-table-column v-if="$route.name == 'count_ip'" label="归属地" prop="region" header-align="center" align="center"></el-table-column>
        <el-table-column label="访问量" prop="value" header-align="center" align="center"></el-table-column>
        <el-table-column label="批次" prop="batch" header-align="center" align="center"></el-table-column>
        <el-table-column label="开始时间" prop="strbegin" header-align="center" align="center" width="160"></el-table-column>
        <el-table-column label="结束时间" prop="strend" header-align="center" align="center" width="160"></el-table-column>
        <el-table-column label="QPS平均值" prop="qps" header-align="center" align="center"></el-table-column>
      </el-table>
      <el-pagination v-if="nodeData.total>0" @current-change="handleCurrentChange" :current-page.sync="thisPage" :page-size="20" layout="total, prev, pager, next, jumper" :total="nodeData.total"></el-pagination>
    </div>
  </div>
</template>

<style lang="sass" scoped>
  .table
    display: block
    overflow: hidden
    padding: 20px
    background-color: #fff
    .table-tool
      padding-bottom: 20px

  .el-menu
    background-color: #1d2336 !important
    &.el-menu--horizontal
      border-bottom: none

  .el-button-group
    padding-bottom: 20px
    button
      width: 100px

  .cell button
    width: 58px

  .dialog-footer button
    width: 80px

  .el-pagination
    float: right
    padding: 20px

  .el-select
    width: 100%
  
  /deep/ .el-range-editor
    width: 100%

  .tool-select
    float: left
    margin-right: 20px
    width: auto
  
  .el-checkbox
    color: #67c23a
  .w40
      width: 40px
  .noGroup
    color: #fff
  .el-col
    &.center
      text-align: center
  
  .info
    text-align: center

  .el-table__body
    tr
      padding: 0 !important
  
  .el-table--enable-row-hover .el-table__body tr>td
    background-color: #fff !important

  .expand_table
    background-color: #1d2336
    padding: 0 20px
    >div
      padding: 0
      &.header
        line-height: 40px
        color: #909399
        border-bottom: 1px solid #909399
      overflow: hidden
      padding: 0 40px 0 20px
      li
        padding: 0
        list-style: none
        float: left
        width: 100px
      &.list
        line-height: 40px
        &:hover
          color: #4c98d2
  .box
    overflow-y: scroll
    max-height: 400px
    &::-webkit-scrollbar
      width: 6px
      height: 6px
    &::-webkit-scrollbar-thumb
      width: 6px
      height: 6px
      background-color: rgb(76, 152, 210)
      background-clip: padding-box
      border-radius: 5px
  .myTable
    background-color: #DCDFE6
    color: #fff
    tr
      width: 100%
    th, td
      width: 10%
      text-align: center
      background-color: #1a2035;
      span
        display: block
        height: 20px
        line-height: 20px
        padding: 20px
  .hover
    display: block
    cursor: pointer
    color: #409EFF
    text-decoration: underline
    &:hover
      color: #fff
  .red
    color: #f56c6c
</style>


<script>
import utils from '@/lib/utils'
import config from "@/config";
import axios from 'axios'
import Qs from 'qs'
import HeaderSelect from "@/components/HeaderUser.vue";
import moment from 'moment';

export default {
  inject:['reload'],
  data() {
    return {
      timer: null,
      height: 0,
      pageName: this.$route.name == "count_dn"? "域名" :"IP",
      proGroupId: null,
      thisPage: 1,
      form: {
        timer: [],
        search: null
      },
      expands: [],
      nodeData: {
        tableData: [],
        total: 0,
        totalPages: 1
      },
      filepath: null,
      generateState: false,
      loading: false,
      multipleSelection: [],
      dialogTitle: "连接控制器",
      dialogTableVisible: false,
      formLabelWidth: '70px'
    };
  },
  mounted() {
    this.height = window.innerHeight;
    window.onresize = () => {
      this.height = window.innerHeight;
    };
    // this.$loading(config.loading);
    this.getList();
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  watch: {
    '$route' (to, from) {
      this.pageName = this.$route.name == "count_dn"? "域名" :"IP";
      this.form = {
        timer: [],
        search: null
      };
      this.getList(1);
      // this.reload()
    }
  },
  methods: {
    getList(page, pagesize) {
      this.$loading(config.loading);
      let url =  config.url + "apis/topn/";
      let _type = "ip";
      if(this.$route.name == "count_dn") {
        _type = "dn";
      }
      url += _type;
      let param = {
        "list": this.form.search || "",
        "begin": this.form.timer[0] || "0000-00-00 00:00:00",
        "end": this.form.timer[1] || "0000-00-00 00:00:00",
        "currpage": page || 1,
        "pagesize": pagesize || 20
      }
      this.$http.post(url, param).then(res => {
        let data = res.data;
        // data.data.map((item, index)=>{
        //   data.data[index].begin = moment(item.begin).format("YYYY-MM-DD HH:mm:ss");
        //   data.data[index].end = moment(item.end).format("YYYY-MM-DD HH:mm:ss");
        // })
        let _nodeData = {
          tableData: data.data,
          total: data.total,
          totalPages: data.pagecount
        }
        this.nodeData = _nodeData;
        this.$loading().close();
      })
      .catch(err => {
        this.$loading().close();
        console.log(err);
        // this.$message.error("请求接口失败");
      });
    },
    batch(opt) {
      let _list = [];
      this.multipleSelection.map((item) => {
        if(item.illegal != 1) {
          _list.push({
            "key": item.key,
            "value": item.value
          });
        }
      })
      
      let url =  config.url + "apis/" + opt + "/batch";
      let param = _list;
      
      this.$http.post(url, { data: param }).then(res => {
        let data = res.data;
        let filename = data.filepath? data.filepath.split('/'): "";
        this.filepath = data.filepath || null;
        if(filename.length > 1) {
          filename = filename[filename.length - 1];
        }
        let html = data.filepath? '成功：' + data.success + '；失败：' + data.fail + '；结果文件：<a href="javascript:;">' + filename + '</a>': '成功：' + data.success + '；失败：' + data.fail + '；'
        let _message;
        if(data.fail != 0) {
          _message = this.$message({
            showClose: true,
            dangerouslyUseHTMLString: true,
            message: html,
            type: 'success',
            duration: 0
          });
        }
        else {
          _message = this.$message({
            showClose: true,
            dangerouslyUseHTMLString: true,
            message: html,
            type: 'success'
          });
        }
        _message.$el.querySelector('a').onclick = () => {
          // let filepath = _message.$el.querySelector('a').innerHTML;
          let url =  config.url + "apis/download";
          let param = {
            filepath: this.filepath
          }
          
          this.$http.post(url, param).then(res => {
            let data = res.data;
            let _fileName = _message.$el.querySelector('a').innerHTML.split('/');
            this.download(_fileName[_fileName.length - 1] || "download.txt", String(data));
          })
          .catch(err => {
            console.log(err);
            // this.$message.error("请求接口失败");
            this.$message.error(err.response.data.error);
          });
        };
      })
      .catch(err => {
        console.log(err);
        // this.$message.error("请求接口失败");
        this.$message.error(err.response.data.error);
      });
    },

    serarch() {
      this.thisPage = 1;
      this.getList(1);
    },
    
    handleCurrentChange(val) {
      this.thisPage = val;
      this.getList(val);
    },

    handleSelectionChange(val) {
      // 表格多选
      this.multipleSelection = val;
    },

    download(filename, text) {
      var element = document.createElement('a');
      element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
      element.setAttribute('download', filename);
    
      element.style.display = 'none';
      document.body.appendChild(element);
    
      element.click();
    
      // document.body.removeChild(element);
      document.body.revokeObjectURL(element);
    }

  },
  components: {
    HeaderSelect
  }
};
</script>