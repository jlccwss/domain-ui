<template>
  <div>
    <HeaderUser></HeaderUser>
    <div>
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{$route.meta.title}}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="table">
      <el-form :model="form">
        <el-form-item>
          <el-button type="primary" size="mini" :loading="groupListState" icon="el-icon-edit" @click="editRow">添加</el-button>
        </el-form-item>
      </el-form>
      
      <el-table v-loading="loading" element-loading-text="数据加载中" element-loading-spinner="el-icon-loading" element-loading-background="rgba(0, 0, 0, 0.8)" ref="multipleTable" :data="sysUserData.tableData" style="width: 100%" :max-height="(height-270)" stripe>
        <el-table-column prop="id" label="编号" header-align="center" align="center" width="80"></el-table-column>
        <el-table-column prop="name" label="用户名" header-align="center" align="center"></el-table-column>
        <el-table-column prop="group" label="用户组" header-align="center" align="center"></el-table-column>
        <el-table-column label="创建时间" prop="strtime" header-align="center" align="center"></el-table-column>
        <el-table-column fixed="right" label="操作" header-align="center" width="150">
          <template slot-scope="scope">
            <el-button size="mini" @click="editRow(scope.$index, sysUserData.tableData)">修改</el-button>
            <el-button v-if="scope.row.name != 'admin'" size="mini" type="danger" @click="deleteRow(scope.$index, sysUserData.tableData)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog :title="dialogTitle" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
      <el-form :model="form">
        <el-form-item label="用户名" :label-width="formLabelWidth">
          <span v-if="form.userName == 'admin' || userName != 'admin'">{{form.userName}}</span>
          <el-input v-else v-model="form.userName" clearable maxlength="28" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="用户密码" :label-width="formLabelWidth">
          <el-input type="password" v-model="form.password" clearable auto-complete="new-password" minlength="6" maxlength="24"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" :label-width="formLabelWidth">
          <el-input type="password" v-model="form.password2" clearable auto-complete="new-password" minlength="6" maxlength="24"></el-input>
        </el-form-item>
        <el-form-item label="用户角色" :label-width="formLabelWidth">
          <span v-if="form.userName == 'admin'">{{form.sysRole == "admin"? "管理员" :"普通用户"}}</span>
          <el-select v-else v-model="form.sysRole" placeholder="请选择">
            <el-option v-for="item in sysRole" :key="item.value" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="editUser">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<style lang="sass" scoped>
.table
  display: block
  overflow: hidden
  padding: 20px
  background-color: #fff

.el-button-group
  padding-bottom: 20px
  button
    width: 100px

.cell button
  width: 58px

.dialog-footer button
  width: 80px

.el-pagination
  float: right
  padding: 20px

.el-select
  width: 100%
</style>

<script>
import store from "@/store";
import utils from '@/lib/utils'
import config from "@/config";
import HeaderUser from "@/components/HeaderUser.vue";

export default {
  data() {
    return {
      height: 0,
      userName: sessionStorage.getItem("userName"),
      sysRoleValue: "普通用户",
      sysRole: [{
        value: "admin",
        label: "管理员"
      },{
        value: "user",
        label: "普通用户"
      }],
      sysUserData: {
        tableData: [],
        total: 0,
        totalPages: 1
      },
      groupListState: false,
      optionsGroup: [],
      loading: false,
      dialogTitle: "添加用户",
      dialogFormVisible: false,
      form: {
        "userName":"",
        "password":"",
        "sysRole": "普通用户"
      },
      formLabelWidth: '70px'
    };
  },
  mounted() {
    console.log("user");
    this.height = window.innerHeight;

    // 获取用户列表信息
    this.getList(1, 20)

    window.onresize = () => {
      this.height = window.innerHeight;
    };
  },
  computed: {
    
  },
  methods: {
    getList() {
      this.$loading(config.loading);
      let url =  config.url + "apis/user";
      let param = {}
      this.$http.get(url, param).then(res => {
        let data = res.data;
        let sysUserData = {
          tableData: data.Data,
          total: data.Data.length || 0,
          totalPages: 1
        };
        this.sysUserData = sysUserData;
        this.$loading().close();
      })
      .catch(err => {
        console.log(err);
        this.$loading().close();
        this.$message.error(err.response.data.error);
        // this.$message.error("请求接口失败");
      });
    },
    postUser(param) {
      let url =  config.url + "apis/user";
      this.$http.post(url, param).then(res => {
        let data = res.data;
        if(data.status == 0) {
          this.$message.success("用户添加成功");
          this.dialogFormVisible = false;
          this.getList();
        }
        else {
          this.$message.error(data.msg);
        }
      })
      .catch(err => {
        console.log(err);
        this.$message.error(err.response.data.error);
        // this.$message.error("请求接口失败");
      });
    },
    putUser(param) {
      let url =  config.url + "apis/user";
      this.$http.put(url, param).then(res => {
        let data = res.data;
        if(data.status == 0) {
          this.$message.success("用户修改成功");
          this.dialogFormVisible = false;
          this.getList();
        }
        else {
          this.$message.error(data.msg);
        }
      })
      .catch(err => {
        console.log(err);
        // this.$message.error("请求接口失败");
      });
    },
    editUser() {
      let oldUserName = this.form.oldUserName;
      if(!this.form.userName)
      {
        this.$message.error("请输入用户名");
        return false;
      }
      if(!this.form.password)
      {
        this.$message.error("请输入用户密码");
        return false;
      }
      if(this.form.password.length<6)
      {
        this.$message.error("密码必须大于6位");
        return false;
      }
      if(this.form.password != this.form.password2)
      {
        this.$message.error("用户密码与确认密码不一致");
        return false;
      }
      if(this.form.sysRole == undefined)
      {
        this.$message.error("请选择用户角色");
        return false;
      }
      if(this.form.id){
        // console.log("修改")
        this.putUser({
          "id": this.form.id,
          "name": this.form.userName,
          "passwd": this.form.password,
          "group": this.form.sysRole
        })
      }
      else {
        // console.log("添加")
        this.postUser({
          "name": this.form.userName,
          "passwd": this.form.password,
          "group": this.form.sysRole
        })
      }
    },
    editRow(index, rows) {
      if(rows) {
        this.dialogTitle = "修改用户";
        this.form = {
          "id": rows[index].id,
          "userName": rows[index].name,
          "password": null,
          "sysRole": rows[index].group
        }
      }
      else
      {
        this.dialogTitle = "添加用户";
        this.form = {
          "userName": null,
          "password": null,
          "sysRole": "user"
        }
      }
      this.dialogFormVisible = true;
    },
    deleteUser(id) {
      let url =  config.url + "apis/user/" + id;
      let param = {};
      this.$http.delete(url, param).then(res => {
        let data = res.data;
        if(data.status == 0) {
          this.$message.success("删除用户成功");
          this.getList();
        }
        else {
          this.$message.error(data.msg);
        }
      })
      .catch(err => {
        console.log(err);
        this.$message.error(err.response.data.error);
        // this.$message.error("请求接口失败");
      });
    },
    deleteRow(index, rows) {
      this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.deleteUser(rows[index].id);
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });          
      });
    }
  },
  components: {
    HeaderUser
  }
};
</script>