<template>
  <el-container :style="'height:' + height + 'px'">
    <el-header>
      <div class="title">DNS防护系统-G3</div>
      <!-- <div class="tool">欢迎 {{ userName }}</div>
      <el-dropdown>
        <i class="el-icon-setting" style="margin-right: 15px; cursor: pointer;"><span> 设置</span></i>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>修改密码</el-dropdown-item>
          <el-dropdown-item @click.native="outLogin">退出登陆</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown> -->
    </el-header>
    <el-container>
      <el-aside :style="'height:' + (height-60) + 'px;'" width="200px" v-show="asideShow?'hidden':''">
        <div class="logo">
          <!-- <span>GDNS</span> -->
          <img src="../../assets/logo.svg" />
        </div>
        <el-menu :default-openeds="['count', 'list']" :default-active="$route.fullPath" router :style='"position: fixed; top:60px; width: 200px; overflow-y: auto; overflow-x: hidden; height: " + (height-60) +"px"'>
          <el-menu-item index="/admin/screen">
            <i class="el-icon-s-home"></i>
            <span slot="title">配置首页</span>
          </el-menu-item>
          <el-submenu index="count">
            <template slot="title">
              <i class="el-icon-s-platform"></i>
              <span>运行统计</span>
            </template>
            <el-menu-item index="/admin/count/ip">IP统计</el-menu-item>
            <el-menu-item index="/admin/count/dn">域名统计</el-menu-item>
          </el-submenu>
          <el-submenu index="list">
            <template slot="title">
              <i class="el-icon-s-order"></i>
              <span>名单管理</span>
            </template>
            <el-menu-item index="/admin/list/ip?type=ipblack">IP黑名单</el-menu-item>
            <el-menu-item index="/admin/list/dn?type=dnblack">域名黑名单</el-menu-item>
            <el-menu-item index="/admin/list/ip?type=ipwhite">IP白名单</el-menu-item>
            <el-menu-item index="/admin/list/dn?type=dnwhite">域名白名单</el-menu-item>
            <el-menu-item index="/admin/list/ip?type=ippptc">IP PPTC</el-menu-item>
            <el-menu-item index="/admin/list/dn?type=dnpptc">域名PPTC</el-menu-item>
            <el-menu-item index="/admin/wildcard">域名通配</el-menu-item>
          </el-submenu>
          <el-menu-item index="/admin/config">
            <i class="el-icon-lock"></i>
            <span slot="title">安全策略</span>
          </el-menu-item>
          <el-menu-item index="/admin/configSys">
            <i class="el-icon-s-tools"></i>
            <span slot="title">系统设置</span>
          </el-menu-item>
          <el-menu-item index="/admin/userlist">
            <i class="el-icon-user-solid"></i>
            <span slot="title">用户管理</span>
          </el-menu-item>
          <el-menu-item index="/admin/loglist">
            <i class="el-icon-document"></i>
            <span slot="title">操作日志</span>
          </el-menu-item>
          <el-menu-item index="/admin/alarmlist">
            <i class="el-icon-info"></i>
            <span slot="title">系统告警</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-container>
        <el-main>
          <router-view/>
        </el-main>
        <!-- <el-footer>Copyright © 2019 All Rights Reserved</el-footer> -->
      </el-container>
    </el-container>
  </el-container>
</template>

<style lang="sass">
.icon
  width: 1.5em
  height: 1.5em
  vertical-align: middle
  fill: currentColor
  overflow: hidden

.el-form-item__label
  color: #ffffff !important

.el-table
  th
    .gutter
      display: table-cell !important
  
.el-table
  colgroup.gutter
    display: table-cell !important
  
.table, .el-table, .el-table__expanded-cell
  background-color: #1f283e !important
  color: #ffffff !important

.el-table
  .el-table__body-wrapper::-webkit-scrollbar
    width: 6px
    height: 6px
  .el-table__body-wrapper::-webkit-scrollbar-thumb
    width: 6px
    height: 6px
    background-color: rgb(76, 152, 210)
    background-clip: padding-box
    border-radius: 5px
  .el-table__fixed-right-patch
    background-color: #1f283e !important
  .el-table--border th, .el-table__fixed-right-patch
    border-bottom: 1px solid #1f283e !important
  th
    background-color: #1f283e !important
    color: #ffffff !important
  tr
    background-color: #1d2336 !important
    color: #ffffff !important
.el-table td, .el-table th
  padding: 5px 0 !important
.table .el-table__expanded-cell[class*=cell]
  padding: 0 !important

.el-table--striped .el-table__body tr.el-table__row--striped
  td
    background-color: #24292f !important
  &.current-row td
    background-color: #0051b9 !important

.el-table__body tr
  &.current-row > td
    background-color: #0051b9 !important
  &.hover-row
    &.current-row > td
      background-color: #4c98d2 !important
    &.el-table__row--striped
      &.current-row > td, > td
        background-color: #4c98d2 !important
    > td
      background-color: #4c98d2 !important
.table
  .el-table--enable-row-hover .el-table__body tr:hover>td
    background-color: #4c98d2 !important
  .el-table__expanded-cell
    background-color: #1d2336 !important
  .el-table__expanded-cell[class*=cell]
    padding: 0

.el-table--enable-row-hover .el-table__body tr:hover>td
    background-color: #4c98d2 !important
.el-table__expanded-cell
  background-color: #1d2336 !important

.el-table__expand-icon
  color: #ffffff !important

.el-table
  td, th.is-leaf
    border: none !important
.el-table::before
  height: 0 !important;
.el-table__fixed-right::before, .el-table__fixed::before
  height: 0 !important;

.el-message-box
  border: none !important
  .el-message-box__content
    color: #ffffff !important
    p
      word-wrap:break-word !important
      max-height: 400px
      overflow-y: scroll
.el-dialog, .el-message-box
  background-color: #24292f !important
  color: #788193 !important
.el-dialog, .el-message-box
  .el-dialog__header,.el-message-box__header
    background-color: #282f35 !important
  .el-dialog__title,.el-message-box__title
    color: #4c98d2 !important
  .el-dialog__body
    color: #fff
  .el-dialog__footer
    .el-button
      background: #dcdfe6 !important
    .el-button--primary
      background-color: #409EFF !important
      border-color: #409EFF !important
    .is-disabled
      color: #606266 !important
      background-color: #dcdfe6 !important
      border-color: #dcdfe6 !important

input, textarea
  background-color: #282f35 !important
  color: #788193 !important

input::-webkit-outer-spin-button, input::-webkit-inner-spin-button
  -webkit-appearance: none
input[type="number"]
  -moz-appearance: textfield;

.el-input__inner, .el-textarea__inner
    border: 1px solid #606266 !important

.el-pager li
   background-color: #1f283e !important

.el-pagination
  color: #606266 !important
  .btn-next, .btn-prev
    color: #606266 !important
    background-color: #1f283e !important

body
  background-color: #1f283e

.el-header, .el-footer
  background-color: #1f283e
  line-height: 60px
  color: #ffffff

.el-cascader
  margin-right: 20px



.el-header .el-dropdown
  position: fixed
  z-index: 99
  top: 0
  right: 20px
  color: #ffffff !important
  i
    color: #409eff
    span
      color: #ffffff

.tool_back
  position: fixed
  z-index: 99
  top: 0
  right: 100px

.el-header
  position: fixed
  z-index: 998
  width: 100%
  /*box-shadow: 0 0 20px 0 #121727 !important*/
  .title
    float: left
    margin-left: 200px

.el-select
  margin-right: 10px

.el-footer
  text-align: center
  line-height: 60px

.el-aside
  padding-top: 140px
  background-color: #1f283e
  color: #b5c2cf

.logo
  position: fixed
  width: 200px
  top: 10px
  text-align: center
  z-index: 999
  color: #788193
  img
    height: 30px
  span
    display: block
    padding-top: 20px

.el-menu
  background-color: #1f283e !important
  border-right: none !important

.el-submenu__title
  color: #b5c2cf !important

.el-menu-item
  color: #b5c2cf !important
  &.is-active
    color: #409eff !important

.el-submenu__title:hover
  color: #ffffff !important
  background-color: #4c98d2 !important

.el-menu-item
  &:focus, &:hover
    color: #ffffff !important
    background-color: #4c98d2 !important

.el-submenu__title
  i
    color: #b5c2cf !important
  &:hover i
    color: #ffffff !important

.el-main
  min-height: 100%;
  background-color: #1a2035
  color: #333
  padding-top: 80px !important

.card
  margin-bottom: 20px
  .el-card
    background-color: #409eff
    border-color: #409eff
    color: #FFFFFF
    .el-card__header
      border-bottom: 1px solid #1f283e !important
    .el-card__body
      background-color: #1c2437

.el-popper[x-placement^=bottom] .popper__arrow
  border-bottom-color: #606266 !important
  &::after
    border-bottom-color: #1f283e !important
.el-select-dropdown__empty
  background-color: #1f283e !important
.el-select-dropdown
  border: 1px solid #606266 !important
.el-select-dropdown__list
  background-color: #1f283e !important
.el-select-dropdown__item
  color: #fff !important
.el-select-dropdown__item.hover, .el-select-dropdown__item:hover
  color: #fff !important
  background-color: #4c98d2 !important
.el-select-dropdown.is-multiple .el-select-dropdown__item.selected
  background-color: #4c98d2 !important
.el-dropdown-menu
  background-color: #1f283e !important
  border: 1px solid #606266 !important
  .el-dropdown-menu__item
    color: #fff !important
  .el-dropdown-menu__item:focus, .el-dropdown-menu__item:not(.is-disabled):hover
    background-color: #4c98d2 !important
.el-picker-panel
  color: #fff !important
  background-color: #1f283e !important
  border: 1px solid #606266 !important
  .el-date-picker__header-label
    color: #fff !important
  .el-year-table td .cell
    color: #fff !important
  .el-date-range-picker__time-header
    border-bottom: 1px solid #606266
  .el-date-range-picker__content.is-left
    border-right: 1px solid #606266;
  .el-date-table td.next-month, .el-date-table td.prev-month
    color: #fff !important
  .el-month-table td .cell
    color: #fff !important
  .el-date-table th
    color: #fff !important
    border-bottom: solid 1px #606266 !important
  .el-date-table td.in-range div, .el-date-table td.in-range div:hover, .el-date-table.is-week-mode .el-date-table__row.current div, .el-date-table.is-week-mode .el-date-table__row:hover div
    background-color: #4c98d2 !important
  .el-month-table td.in-range div, .el-month-table td.in-range div:hover
    background-color: #4c98d2 !important
  .el-picker-panel__footer
    border-top: 1px solid #606266;
    background-color: #1f283e !important

.el-cascader__dropdown
  border: 1px solid #606266 !important
.el-cascader-panel
  color: #fff !important
  background-color: #1f283e !important
  .el-cascader-menu
    color: #fff !important
    border-right: solid 1px #606266;
  .el-cascader-node:not(.is-disabled):focus, .el-cascader-node:not(.is-disabled):hover
    color: #fff !important
    background-color: #4c98d2 !important
.el-picker-panel .el-date-table td.next-month, .el-picker-panel .el-date-table td.prev-month
  color: #606266 !important
.el-input__inner
  color: #fff !important
  background-color: #1f283e !important
.el-date-editor .el-range-input
  color: #fff !important
  background-color: #1f283e !important
.el-date-range-picker__time-header>.el-icon-arrow-right
  color: #fff !important
.el-date-editor .el-range-separator
  color: #fff !important
.el-picker-panel__icon-btn
  color: #fff !important
.el-time-panel
  background-color: #1f283e !important
.el-time-spinner__item.active:not(.disabled)
  color: #fff !important
.el-time-panel__btn
  color: #fff !important
.el-breadcrumb
  padding: 2px 0 20px
  .el-breadcrumb__inner
    color: #fff
  .el-breadcrumb__inner.is-link
    color: #fff
  .el-breadcrumb__item:last-child .el-breadcrumb__inner
    color: #4c98d2
</style>

<script>
import store from "./../../store";
import config from "./../../config";

export default {
  data() {
    return {
      width: window.innerWidth,
      height: window.innerHeight,
      asideShow: true,
      defaultActive: this.$route.fullPath,
      sysRole: store.state.sysRole,
      userName: ""
    };
  },
  mounted() {
    this.height = window.innerHeight;
    window.onresize = () => {
      this.height = window.innerHeight;
    };

    this.userName = sessionStorage.getItem("userName");
    this.sysRole = sessionStorage.getItem("sysRole");

    // if(!sessionStorage.getItem("userName")){
    //   this.getCurrentLoginUser();
    // }

    if (window.innerWidth < 500) {
      this.asideShow = false;
    }

    window.onresize = () => {
      this.width = window.innerWidth;
      this.height = window.innerHeight;
      if (this.width <= 500) {
        this.asideShow = false;
      } else {
        this.asideShow = true;
      }
    };
  },
  methods: {
    getCurrentLoginUser() {
      let url = config.url + "SysUserController/getCurrentLoginUser.action";
      let param = {}
      this.$http.post(url, param).then(res => {
        let data = res.data;
        if(data.resultCode == 200){
          sessionStorage.setItem("userName", data.data.userName);
          sessionStorage.setItem("sysRole", data.data.sysRole);
          this.userName = data.data.userName;
          this.sysRole = data.data.sysRole;
        }
      })
    },
    outLogin() {
      store.state.token = "";
      store.state.optionsProject = [];
      store.state.optionsGroup = [];
      store.state.valueProject = "";
      store.state.valueGroup = "";
      store.state.nodeInfoOnlineNum = {};
      sessionStorage.removeItem("userName");
      this.$router.push({ path: "/login" });
    }
  },
  components: {
    
  }
};
</script>