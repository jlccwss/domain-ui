import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import axios from 'axios'
import VueAxios from 'vue-axios'
import config from "@/config"
import './plugins/element.js'
import ElementUI from 'element-ui'
import utils from '@/lib/utils'
import G2 from '@antv/g2'
import echarts from 'echarts'

import onlyNumber from '@/directive/el-input'; //添加此行=>自定义全局指令

// import './assets/iconfont.css';
import './assets/iconfont.js';

Vue.config.productionTip = false
Vue.prototype.$echarts = echarts

// 拦截请求
// axios.interceptors.request.use(
//   config => {
//     console.log(config);
//     // router.replace({path: '/login'})
//     return config
//   },
//   err => {
//     return Promise.reject(err)
//   }
// )

// 拦截响应
axios.interceptors.response.use(
  response => {
    // console.log('拦截响应',response)
    return response
  },
  err => {
    console.log(err);
    if (err.response.status != 200) {
      // window.location.href = "/login"
      switch (err.response.status) {
        case 404:
          ElementUI.Message({
            message: "404",
            type: 'error'
          });
          return false
        case 302:
          router.replace({path: '/login'})
          return false
        default:
          // ElementUI.Message({
          //   message: err.response.data.msg || err.response.data.error,
          //   type: 'error'
          // });
      }
    }
    return Promise.reject(err)
  }
)

Vue.use(VueAxios, axios, G2);

Vue.use(onlyNumber); //添加此行=>使用该全局指令

// router.beforeEach((to, from, next) => {
//   let userName = sessionStorage.getItem("userName");
//   if (to.meta.requireAuth) {  // 判断该路由是否需要登录权限
//     if (store.state.token || userName) {  // 通过vuex state获取当前的token是否存在
//       next();
//     }
//     else {
//       next({
//         path: '/login',
//         query: { redirect: to.fullPath }  // 将跳转的路由path作为参数，登录成功后跳转到该路由
//       })
//     }
//   }
//   else {
//     next();
//   }
// })

router.afterEach((transition)=>{
  // utils.setTitle(transition.meta.title)
})

Vue.filter('NumFormat', function(value) {
  if(!value) return ''
      value = value.toFixed(0)
      var intPart = Number(value).toFixed(0) // 获取整数部分
      var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,') // 将整数部分逢三一断
      var floatPart = '' // 预定义小数部分
      var value2Array = value.split('.')
      // =2表示数据有小数位
      if(value2Array.length === 2) {
        floatPart = value2Array[1].toString() // 拿到小数部分
        if(floatPart.length === 1) { // 补0,实际上用不着
          return intPartFormat + '.' + floatPart + '0'
        } else {
          return intPartFormat + '.' + floatPart
        }
      } else {
        return intPartFormat + floatPart
      }
})

Vue.filter('NumFormatCompany', function(value) {
  if(!value) return ''
  if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000) {
    return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "D"
  }
  else if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000 * 1000 * 1000 * 1000 * 1000) {
    return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "N"
  }
  else if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000 * 1000 * 1000 * 1000) {
    return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "B"
  }
  else if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000 * 1000 * 1000) {
    return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "Y"
  }
  else if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000 * 1000) {
    return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "Z"
  }
  else if(value > 1000 * 1000 * 1000 * 1000 * 100 * 1000) {
    return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "E"
  }
  else if(value > 1000 * 1000 * 1000 * 1000 * 1000) {
    return (parseInt(value / 1000 / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "P"
  }
  else if(value > 1000 * 1000 * 1000 * 1000) {
    return (parseInt(value / 1000 / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "T"
  }
  else if(value > 1000 * 1000 * 1000) {
    return (parseInt(value / 1000 / 1000 / 1000 * 100) / 100).toFixed(2) + "G"
  }
  else if(value > 1000 * 1000) {
    return (parseInt(value / 1000 / 1000 * 100) / 100).toFixed(2) + "M"
  }
  else if(value > 1000) {
    return (parseInt(value / 1000 * 100) / 100).toFixed(2) + "K"
  }
  else {
    return value
  }
      // value = value.toFixed(0)
      // var intPart = Number(value).toFixed(0) // 获取整数部分
      // var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,') // 将整数部分逢三一断
      // var floatPart = '' // 预定义小数部分
      // var value2Array = value.split('.')
      // // =2表示数据有小数位
      // if(value2Array.length === 2) {
      //   floatPart = value2Array[1].toString() // 拿到小数部分
      //   if(floatPart.length === 1) { // 补0,实际上用不着
      //     return intPartFormat + '.' + floatPart + '0'
      //   } else {
      //     return intPartFormat + '.' + floatPart
      //   }
      // } else {
      //   return intPartFormat + floatPart
      // }
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
