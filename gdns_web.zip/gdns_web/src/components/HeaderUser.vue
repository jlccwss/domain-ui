<template>
  <div class="HeaderSelect">
    <i class="el-icon-question" style="margin-right: 15px; cursor: pointer; color:#409eff;" @click="help"></i>
    <span>欢迎 {{ userName }}</span>&nbsp;&nbsp;
    <el-dropdown>
      <i class="el-icon-setting" style="margin-right: 15px; cursor: pointer;"><span> 设置</span></i>
      <el-dropdown-menu slot="dropdown">
        <!-- <el-dropdown-item>修改密码</el-dropdown-item> -->
        <el-dropdown-item @click.native="outLogin">退出登陆</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  </div>
</template>

<script>
import store from "@/store";
import config from "@/config";

export default {
  name: "HeaderSelect",
  props: {},
  data() {
    return {
      timer: null,
      userName: null,
      referrer: sessionStorage.getItem("referrer") || null
    };
  },
  mounted() {
    this.userName = sessionStorage.getItem("userName") || null;
  },
  beforeDestroy() {
  },
  methods: {
    outLogin() {
      store.state.token = "";
      sessionStorage.removeItem("userName");
      this.$router.push({ path: "/login" });
    },
    help() {
      window.open("/help/index.html");
    },
  }
};
</script>

<style lang="sass" scoped>
.HeaderSelect
  color: #ffffff
  position: fixed
  top: 0
  right: 0px
  line-height: 60px
  z-index: 9998
  .el-select
    width: 140px
.el-dropdown
  display: inline
  z-index: 9999
  color: #ffffff !important
  i
    color: #409eff
    span
      color: #ffffff
</style>
