// let url = "http://218.93.241.174:8888/";
// let url = "http://218.93.241.174:8088/";
let wsurl = "ws://218.93.241.174:8088/";
let url = "/";

// admin
// admin3200$%^

let loading = {
  lock: true,
  text: '数据加载中',
  spinner: 'el-icon-loading',
  background: 'rgba(0, 0, 0, 0.7)'
}

var obj = {
  url: url,
  wsurl: wsurl,
  token: null,
  loading: loading
}
export default obj;
