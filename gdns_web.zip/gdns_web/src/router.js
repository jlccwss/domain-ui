import Vue from 'vue'
import Router from 'vue-router'
import layout from './views/layout/layout.vue'
import page from './views/layout/page.vue'

Vue.use(Router)

export default new Router({
  // mode: 'history',
  routes: [
    {
      path: '/',
      name: 'home',
      meta: {
        title: "用户登陆"
      },
      component: () => import(/* webpackChunkName: "about" */ './views/pages/Login.vue')
      // component: Home
    },
    {
      path: '/login',
      name: 'login',
      meta: {
        title: "用户登陆"
      },
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/pages/Login.vue')
    },
    {
      path: '/admin/screen',
      name: 'screen',
      meta: {
        title: "大屏展示",
        requireAuth: true
      },
      component: () => import('./views/pages/Screen.vue')
    },
    {
      path: "/admin",
      meta: {
        title: "管理后台"
      },
      component: layout,
      children: [
        {
          path: "/admin",
          name: "admin",
          meta: {
            requireAuth: true, 
            title: "管理后台"
          },
          // component: () => import("./views/pages/Index.vue")
          redirect: () => {
            return "/admin/count/ip"
          }
        },
        {
          path: "/admin/dashboard",
          name: "dashboard",
          meta: {
            requireAuth: true, 
            title: "首页"
          },
          component: () => import("./views/pages/dashboard/index.vue")
        },
        {
          path: "/admin/count",
          name: "count",
          meta: {
            requireAuth: true, 
            title: "运行统计"
          },
          component: page,
          redirect: () => {
            return "/admin/count/ip"
          },
          children: [
            {
              path: "/admin/count/ip",
              name: "count_ip",
              meta: {
                requireAuth: true, 
                title: "运行统计",
                subtitle: "IP统计"
              },
              component: () => import("./views/pages/count/ip.vue")
            },
            {
              path: "/admin/count/dn",
              name: "count_dn",
              meta: {
                requireAuth: true, 
                title: "运行统计",
                subtitle: "域名统计"
              },
              component: () => import("./views/pages/count/ip.vue")
            }
          ]
        },
        {
          path: "/admin/wildcard",
          name: "wildcard",
          meta: {
            requireAuth: true,
            title: "域名通配"
          },
          component: () => import("./views/pages/wildcard/list.vue")
        },
        {
          path: "/admin/config",
          name: "config",
          meta: {
            requireAuth: true,
            title: "安全策略"
          },
          component: () => import("./views/pages/config/list.vue")
        },
        {
          path: "/admin/list/ip",
          name: "list_ip",
          meta: {
            requireAuth: true,
            title: "IP管理"
          },
          component: () => import("./views/pages/list/ip.vue")
        },
        {
          path: "/admin/list/dn",
          name: "list_dn",
          meta: {
            requireAuth: true,
            title: "域名管理"
          },
          component: () => import("./views/pages/list/ip.vue")
        },
        {
          path: "/admin/configSys",
          name: "config_sys",
          meta: {
            requireAuth: true,
            title: "系统设置"
          },
          component: () => import("./views/pages/config/sys.vue")
        },
        {
          path: "/admin/userlist",
          name: "userlist",
          meta: {
            requireAuth: true,
            title: "用户管理"
          },
          component: () => import("./views/pages/user/list.vue")
        },
        {
          path: "/admin/loglist",
          name: "loglist",
          meta: {
            requireAuth: true,
            title: "操作日志"
          },
          component: () => import("./views/pages/log/list.vue")
        },
        {
          path: "/admin/alarmlist",
          name: "alarmlist",
          meta: {
            requireAuth: true,
            title: "系统告警"
          },
          component: () => import("./views/pages/alarm/list.vue")
        }
      ]
    },
    {
      path: '*',
      name: '404',
      redirect: () => {
        return "/admin/"
      }
    },
  ]
})
