<template>
  <div id="app">
    <!-- <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </div>-->
    <router-view v-if="isRouterAlive" />
  </div>
</template>

<style lang="sass">
body
  margin: 0
  padding: 0

#app
  position: relative
  min-width: 800px
  font-family: 'Avenir', Helvetica, Arial, sans-serif
  /* -webkit-font-smoothing: antialiased;
   *-moz-osx-font-smoothing: grayscale;
   *text-align: center;
  color: #2c3e50
  /* margin-top: 60px;
::-webkit-scrollbar
  width: 6px
  height: 6px
::-webkit-scrollbar-thumb
  width: 6px
  height: 6px
  background-color: rgb(76, 152, 210)
  background-clip: padding-box
  border-radius: 5px
</style>

<script>
export default {
  name: "app",
  provide() {
    return {
      reload: this.reload
    };
  },
  data() {
    return {
      isRouterAlive: true
    };
  },
  methods: {
    reload() {
      this.isRouterAlive = false;
      this.$nextTick(() => {
        this.isRouterAlive = true;
      });
    }
  }
};
</script>
