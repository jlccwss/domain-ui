import Vue from 'vue'
import Vuex from 'vuex'
import config from "./config.js"

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    token: config.token,
    sysRole: 0,
    optionsProject: [],
    optionsGroup: [],
    valueProject: "",
    valueGroup: "",
    nodeInfoOnlineNum: {},
    systemPower: 0
  },
  mutations: {

  },
  actions: {

  }
})
