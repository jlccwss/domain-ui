module.exports = {
  publicPath: '',
  lintOnSave: false,
  devServer: {
    open: true
  }
}