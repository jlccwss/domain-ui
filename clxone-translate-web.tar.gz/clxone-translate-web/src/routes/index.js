import Login from "../pages/Login";
import Log from "../pages/Log";
import Layout from "../pages/Layout";
import Dashboard from "../pages/Dashboard";
import Ipv6ApplicationUpgrade from "../pages/Ipv6ApplicationUpgrade";
import AccessLog from "../pages/AccessLog";
import ForbidList from "../pages/ForbidList";
import AllowList from "../pages/AllowList";
import WafLog from "../pages/WafLog";

const menuConfig = [
  {
    path: "/business/dashboard",
    component: Dashboard,
    title: "运行监控",
    icon: "HomeOutlined",
  },
  {
    path: "/business/webgroups",
    component: Ipv6ApplicationUpgrade,
    title: "应用配置",
    icon: "ControlOutlined",
  },
  {
    path: "/business/acceccLog",
    component: AccessLog,
    title: "溯源日志",
    icon: "HistoryOutlined",
  },
  {
    path: "/business/safe",
    title: "安全控制",
    icon: "SafetyCertificateOutlined",
    routes: [
      {
        path: "/business/waflog",
        component: WafLog,
        title: "安全日志",
        parentMenu: "/business/safe",
      },
      {
        path: "/business/forbidList",
        component: ForbidList,
        title: "访问管理",
        parentMenu: "/business/safe",
      },
      // {
      //   path: "/business/allow",
      //   component: AllowList,
      //   title: "管理员白名单",
      //   icon: "MenuFoldOutlined",
      //   parentMenu: "/business/safe",
      // },
    ],
  },

  {
    path: "/business/log",
    component: Log,
    title: "操作日志",
    icon: "FileSearchOutlined",
    routes: [
      // {
      //   path: "/user/:id",
      //   component: Detail,
      // },
    ],
  },
];

const config = [
  {
    path: "/login",
    exact: true,
    component: Login,
  },
  {
    path: "/", // 放在下面，可嵌套路由
    component: Layout,
    routes: menuConfig,
  },
];

export default config;
export { menuConfig };
