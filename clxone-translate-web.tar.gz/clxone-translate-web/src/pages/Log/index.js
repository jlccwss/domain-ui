import React, { useState, useEffect } from "react";
import {
  Table,
  Button,
  Input,
  Space,
  Tag,
  Modal,
  Typography,
  DatePicker,
} from "antd";
import { get } from "../../utils/request";
import DownloadFile from "../../components/DownloadFile";

import dayjs from "dayjs";

const { Text } = Typography;
const { RangePicker } = DatePicker;

export default function Log({ route }) {
  const [dataSource, setDataSource] = useState([{}]);
  const [loading, setLoading] = useState(false);

  const [page_num, setPageNum] = useState(1);
  const [page_size, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);
  const [parameters, setParameters] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [count, setCount] = useState(0);
  const [links, setLinks] = useState({});

  useEffect(() => {
    setLoading(true);
    get("/apis/linkingthing.com/log/v1/auditlogs", {
      page_num,
      page_size,
      from,
      to,
      parameters,
    })
      .then(({ data, links, pagination }) => {
        setDataSource(data);
        setPageNum(pagination.pageNum);
        setPageSize(pagination.pageSize);
        setTotal(pagination.total);
        setLinks(links);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [count, page_num, page_size, from, to, parameters]);

  function handleInfo(record) {
    const { username, sourceIp, operation, succeed, parameters } = record;
    Modal.info({
      title: "操作日志详情",
      content: (
        <div>
          <p>
            用户 {username} ({sourceIp}) {operation}
            <Text type={succeed ? "success" : "error"}>
              {succeed ? "成功" : "失败"}
            </Text>
          </p>
          <pre className="code">
            {JSON.stringify(JSON.parse(parameters), null, 2)}
          </pre>
        </div>
      ),
      onOk() {},
    });
  }

  function handleSearch() {
    setCount(count + 1);
  }

  function handleChangeData(_, dateStr) {
    const [from, to] = dateStr;
    setFrom(from);
    setTo(to);
  }

  const columns = [
    {
      title: "操作时间",
      dataIndex: "creationTimestamp",
      render: (text) => {
        return <span>{dayjs(text).format("YYYY-MM-DD HH:mm:ss")}</span>;
      },
    },
    {
      title: "用户",
      dataIndex: "username",
    },
    {
      title: "用户IP",
      dataIndex: "sourceIp",
    },
    {
      title: "网站域名",
      dataIndex: "resourceId",
    },
    {
      title: "操作内容",
      dataIndex: "operation",
    },
    {
      title: "操作结果",
      dataIndex: "succeed",
      render: (text) => (
        <Tag color={text ? "success" : "error"}>{text ? "成功" : "失败"}</Tag>
      ),
    },
    {
      title: "错误信息",
      dataIndex: "errMessage",
      width: 300,
    },

    {
      title: "操作",
      key: "action",
      render: (text, record) => {
        return (
          <Space size="middle">
            <a onClick={() => handleInfo(record)}>查看详情</a>
          </Space>
        );
      },
    },
  ];

  const pagination = {
    current: page_num,
    pageSize: page_size,
    total: total,
    showSizeChanger: false,
    onChange: (page, pageSize) => {
      setPageNum(page);
      setPageSize(pageSize);
    },
  };
  return (
    <div>
      <div className="page-title">{route.title}</div>
      <div className="search-bar">
        <div className="right">
          <RangePicker onChange={handleChangeData} />
          <Input
            placeholder="请输入网站域名搜索"
            className="input-width"
            onChange={(e) => setParameters(e.target.value.trim())}
            allowClear
          />
          <Button type="primary" onClick={handleSearch}>
            查询
          </Button>
          <DownloadFile
            links={links}
            params={{
              from,
              to,
              parameters,
            }}
          />
        </div>
      </div>
      <Table
        dataSource={dataSource}
        columns={columns}
        loading={loading}
        pagination={pagination}
        rowKey={(record) => record.id}
      />
      ;
    </div>
  );
}
