import React from "react";
import {
  Chart,
  Interval,
  Tooltip,
  Line,
  Axis,
  Coordinate,
  Point,
  Legend,
  getTheme,
} from "bizcharts";

export default function TopLine({ data }) {
  const axisConfig = {
    label: {
      style: {
        textAlign: "center",
      }, // 设置坐标轴文本样式
    },
    line: {
      style: {
        stroke: "#ccc",
        lineDash: [3, 3],
      }, // 设置坐标轴线样式
    },
    grid: {
      line: {
        style: {
          stroke: "#ccc",
          lineDash: [3, 3],
        },
      }, // 设置坐标系栅格样式
    },
  };

  return (
    <Chart
      scale={{ count: { min: 0 } }}
      padding={[20, 10, 120, 40]}
      autoFit
      height={500}
      data={data}
    >
      <Line
        style={{
          lineWidth: 3,
        }}
        shape="smooth"
        position="date*count"
        color="website"
      />
      <Point position="date*count" color="website" />
      <Axis name="date" {...axisConfig} />
      <Axis name="count" {...axisConfig} label={{ offset: 10 }} />
      <Tooltip shared={true} showCrosshairs />

      <Legend
        // layout="horizontal"
        flipPage={false}
        marker={{
          symbol: "circle",
          fill: true,
        }}
        // position="right-top"
        offsetY={-40}
        width={500}
        min={500}
      />
    </Chart>
  );
}
