import React from "react";
import { Progress, Popover, List, Typography } from "antd";
import * as Icon from "../../assets";

export default function AppState({
  domainCount,
  normalDomains,
  abnormalNodeCount,
  IPv6AddressesCount,
  unavailableDomains,
  abnormalDomains
}) {
  const content = (
    <List
      header={<div>异常详情</div>}
      bordered
      dataSource={unavailableDomains}
      renderItem={({ cause, domain }) => (
        <List.Item>
          <Typography.Text mark>{domain}</Typography.Text> {cause}
        </List.Item>
      )}
    />
  );

  return (
    <div className="app-state">
      <div className="m-title">应用升级网站状态</div>

      <dl>
        <dt>{domainCount}</dt>
        <dd>网站总数量</dd>
        <dt>{normalDomains}</dt>
        <dd>正常数量</dd>
        <dt style={{ color: "#E62D2D" }}>{abnormalDomains}</dt>
        <dd>
          异常数量
          <Popover
            placement="right"
            // title={text}
            content={content}
            trigger="click"
          >
            <img
              src={Icon.info}
              alt="info"
              style={{
                width: "16px",
                "margin-bottom": "4px",
                "margin-left": "10px",
              }}
            />
          </Popover>
        </dd>
      </dl>
      <Progress
        className="process"
        type="circle"
        percent={((normalDomains / domainCount) * 100).toFixed(2)}
        strokeWidth={10}
        format={(percent) => `${percent}%`}
        strokeColor={{
          "0%": "#62D3F3",
          "100%": "#2965FF",
        }}
      />
    </div>
  );
}
