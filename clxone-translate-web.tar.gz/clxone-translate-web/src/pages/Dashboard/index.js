import React, { useEffect, useState, useMemo } from "react";
import { Progress, Button, message } from "antd";
import { Chart, LineAdvance } from "bizcharts";
import CountUp from "react-countup";
import AppState from "./AppState";
import TopLine from "./TopLine";
import FlowBar from "./FlowBar";
import { get } from "../../utils/request";
import dayjs from "dayjs";

export default function Dashboard() {
  const [totalIPv6VisitCount, setTotalIPv6VisitCount] = useState(0);
  const [normalDomains, setNormalDomains] = useState(0);
  const [abnormalNodeCount, setAbnormalNodeCount] = useState(0);
  const [abnormalDomains, setAbnormalDomains] = useState(0);
  const [domainCount, setDomainCount] = useState(0);
  const [IPv6AddressesCount, setIPv6AddressesCount] = useState(0);
  const [unavailableDomains, setUnavailableDomains] = useState([]);

  const [wafTotal, setWafTotal] = useState(0);

  const [wafTodayCount, setWafTodayCount] = useState(0);
  const [diffCount, setDiffCount] = useState(0);

  const [deviceList, setDeviceList] = useState([]);
  const [deviceInfo, setDeviceInfo] = useState({});

  const [topLineData, setTopLineData] = useState([]);

  useEffect(() => {
    get("/apis/linkingthing.com/business/v1/homepages/m001").then(
      ({
        totalIPv6VisitCount,
        normalDomains,
        abnormalNodeCount,
        domainCount,
        IPv6AddressesCount,
        unavailableDomains,
        abnormalDomains,
      }) => {
        setTotalIPv6VisitCount(totalIPv6VisitCount);
        setNormalDomains(normalDomains);
        setAbnormalNodeCount(abnormalNodeCount);
        setDomainCount(domainCount);
        setIPv6AddressesCount(IPv6AddressesCount);
        setUnavailableDomains(unavailableDomains);
        setAbnormalDomains(abnormalDomains);
      }
    );
  }, []);

  useEffect(() => {
    get(
      "/apis/linkingthing.com/log/v1/logstatistics/1?filtertype=wafstatic"
    ).then(({ todayCount, diffCount, total }) => {
      setWafTodayCount(todayCount);
      setDiffCount(diffCount);
      setWafTotal(total);
    });
  }, []);

  useEffect(() => {
    get(
      "/apis/linkingthing.com/log/v1/convertlogs?page_size=3&page_num=1"
    ).then((res) => {
      console.log(res);
    });
  }, []);

  useEffect(() => {
    get("/apis/linkingthing.com/business/v1/hosts")
      .then(({ data }) => {
        if (Array.isArray(data) && data.length) {
          setDeviceList(data);
          setDeviceInfo(data[0]);
        } else {
          setDeviceList([]);
          setDeviceInfo({});
        }
      })
      .catch((err) => {
        console.log(111, err);
        message.error(err.response.message);
      });
  }, []);

  useEffect(() => {
    get("/apis/linkingthing.com/business/v1/clusters/001/visitcounts?topn=3")
      .then(({ data }) => {
        const result = [];

        data.forEach((item) => {
          for (let i = 0; i < 7; i++) {
            item.Counts.forEach((data) => {
              result.push({
                date: data.Day,
                count: data.Counts,
                website: item.id,
              });
            });
          }
        });

        setTopLineData(result);
      })
      .catch((err) => err);
  }, []);

  const deviceInfoProcess = (data) => {
    switch (true) {
      case data > 0 && data < 50:
        return {
          "0%": "#7FE6EF",
          "100%": "#4AB974",
        };
      case data > 50 && data < 80:
        return {
          "0%": "#E5C865",
          "100%": "#FF8A00",
        };
      case data > 80:
        return {
          "0%": "#FFAB59",
          "100%": "#ED3535",
        };
      default:
        return {
          "0%": "#FFAB59",
          "100%": "#ED3535",
        };
    }
  };

  function changePercent(percent) {
    return Number(parseFloat(percent)).toFixed(2);
  }

  const FlowBarMemo = useMemo(() => <FlowBar deviceInfo={deviceInfo} />, [
    deviceInfo,
  ]);

  return (
    <div>
      <div className="monitor-top">
        <AppState
          normalDomains={normalDomains}
          abnormalNodeCount={abnormalNodeCount}
          domainCount={domainCount}
          IPv6AddressesCount={IPv6AddressesCount}
          unavailableDomains={unavailableDomains}
          abnormalDomains={abnormalDomains}
        />
        <div className="monitor-top-mid">
          <div className="intercept m-card">
            <div className="m-title ">拦截攻击</div>
            <CountUp
              end={wafTotal}
              className="m-strong"
              style={{ "margin-top": "30px", display: "block" }}
            />
            <div className="m-text">累计</div>
            <p className="m-text" style={{ "margin-top": "30px" }}>
              <span>今日：{wafTodayCount}次</span> 日浮动：
              <span style={{ color: "#F33333" }}>{diffCount}次</span>
            </p>
          </div>
          <div className="access-count m-card">
            <div className="m-title ">IPv6业务访问总数</div>
            <CountUp
              end={totalIPv6VisitCount}
              className="m-strong"
              style={{ "margin-top": "30px", display: "block" }}
            />
            <div className="m-text">IPv6业务访问总数</div>
          </div>
          <div className="translate-flow m-card">
            <div className="m-title ">翻译流量</div>
            {FlowBarMemo}
          </div>
        </div>
        <div className="access m-card">
          <div className="m-overflow" style={{ marginBottom: "25px" }}>
            <Button
              type="primary"
              className="right"
              href="/#/business/acceccLog"
            >
              查看全部
            </Button>

            <div className="m-title ">
              访问量
              <span>* 展示近七天内访问量前三的配置网站</span>
            </div>
          </div>

          <TopLine data={topLineData} />
        </div>
      </div>

      <div className="device-info m-card">
        <div className="m-title ">
          设备状态{" "}
          <span>
            数据获取时间：
            {dayjs(deviceInfo.timeStamp * 1000).format("YYYY-MM-DD HH:mm:ss")}
          </span>
        </div>
        <div className="device-list">
          <div className="device-item">
            <div className="device-item-top">
              <img alt="cpu" src="cpu.png" />
              <div>
                <strong>{deviceInfo.cpuUsage}</strong>
                <span> CPU使用率</span>
              </div>

              <Progress
                strokeWidth={16}
                trailColor="#CAE8DB"
                strokeColor={deviceInfoProcess(
                  changePercent(deviceInfo.cpuUsage)
                )}
                width="108"
                className="device-process"
                type="circle"
                percent={changePercent(deviceInfo.cpuUsage)}
              />
            </div>
            <div></div>
          </div>

          <div className="device-item">
            <div className="device-item-top">
              <img alt="memo" src="memo.png" />
              <div>
                <strong>{deviceInfo.memorykUsage}</strong>
                <span> 内存使用率</span>
              </div>

              <Progress
                strokeWidth={16}
                trailColor="#CAE8DB"
                strokeColor={deviceInfoProcess(
                  changePercent(deviceInfo.memorykUsage)
                )}
                width="108"
                className="device-process"
                type="circle"
                percent={changePercent(deviceInfo.memorykUsage)}
              />
            </div>
            <div>
              {/* <p className="device-tips">内存总量：16GB 已使用内存：9.46GB</p> */}
            </div>
          </div>

          <div className="device-item">
            <div className="device-item-top">
              <img alt="disk" src="disk.png" />
              <div>
                <strong>{deviceInfo.diskUsage}</strong>
                <span> 磁盘使用率</span>
              </div>

              <Progress
                strokeWidth={16}
                trailColor="#CAE8DB"
                strokeColor={deviceInfoProcess(
                  changePercent(deviceInfo.diskUsage)
                )}
                width="108"
                className="device-process"
                type="circle"
                percent={changePercent(deviceInfo.diskUsage)}
              />
            </div>
            <div>
              {/* <p className="device-tips">磁盘总量：750GB 已使用磁盘：679.6GB</p> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
