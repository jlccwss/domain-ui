import React, { useState, useEffect } from "react";
import { Table, Button, Input, Modal, Typography, DatePicker } from "antd";
import { get } from "../../utils/request";

import DownloadFile from "../../components/DownloadFile";

import dayjs from "dayjs";

const { Text } = Typography;
const { RangePicker } = DatePicker;

export default function Log({ route }) {
  const [dataSource, setDataSource] = useState([{}]);
  const [loading, setLoading] = useState(false);

  const [page_num, setPageNum] = useState(1);
  const [page_size, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);
  const [parameters, setParameters] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [count, setCount] = useState(0);
  const [links, setLinks] = useState({});

  const [clientip, setClientip] = useState("");
  const [clientPort, setClientPort] = useState("");
  const [url, setUrl] = useState("");
  const [destip, setDestIp] = useState("");
  const [destPort, setDestPort] = useState("");

  useEffect(() => {
    setLoading(true);
    get("/apis/linkingthing.com/log/v1/convertlogs", {
      page_num,
      page_size,
      from,
      to,
      parameters,
      clientip,
      clientPort,
      url,
      destip,
      destPort,
    })
      .then(({ data, links, pagination }) => {
        setDataSource(data);
        setPageNum(pagination.pageNum);
        // setPageSize(pagination.pageSize);
        setTotal(pagination.total);
        setLinks(links);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [
    count,
    page_num,
    page_size,
    from,
    to,
    parameters,
    clientip,
    clientPort,
    url,
    destip,
    destPort,
  ]);

  function handleInfo(record) {
    const { username, sourceIp, operation, succeed, parameters } = record;
    Modal.info({
      title: "操作日志详情",
      content: (
        <div>
          <p>
            用户 {username} ({sourceIp}) {operation}
            <Text type={succeed ? "success" : "error"}>
              {succeed ? "成功" : "失败"}
            </Text>
          </p>
          <pre className="code">
            {JSON.stringify(JSON.parse(parameters), null, 2)}
          </pre>
        </div>
      ),
      onOk() {},
    });
  }

  function handleSearch() {
    setCount(count + 1);
  }

  function handleChangeData(_, dateStr) {
    const [from, to] = dateStr;
    setFrom(from);
    setTo(to);
  }

  const columns = [
    {
      title: "操作时间",
      dataIndex: "time",
      render: (text) => {
        return <span>{dayjs(text).format("YYYY-MM-DD HH:mm:ss")}</span>;
      },
    },
    {
      title: "用户IP",
      dataIndex: "clientip",
    },
    {
      title: "用户端口",
      dataIndex: "clientPort",
    },
    {
      title: "目标IP",
      dataIndex: "destIP",
    },
    {
      title: "目标端口",
      dataIndex: "destPort",
    },
    // {
    //   title: "协议",
    //   dataIndex: "protocol",
    // },
    {
      title: "URL",
      dataIndex: "url",
    },
    {
      title: "状态码",
      dataIndex: "retcode",
    },
  ];

  const pagination = {
    current: page_num,
    pageSize: page_size,
    total: total,
    showSizeChanger: false,
    onChange: (page, pageSize) => {
      setPageNum(page);
      setPageSize(pageSize);
    },
  };
  return (
    <div>
      <div className="page-title">{route.title}</div>
      <div className="search-bar">
        <div className="right">
          <RangePicker onChange={handleChangeData} />
          <Input
            placeholder="请输入用户IP搜索"
            className="input-width"
            onChange={(e) => setClientip(e.target.value.trim())}
            allowClear
          />
          <Input
            placeholder="请输入用户端口搜索"
            className="input-width"
            onChange={(e) => setClientPort(e.target.value.trim())}
            allowClear
          />
          <Input
            placeholder="请输入URL搜索"
            className="input-width"
            onChange={(e) => setUrl(e.target.value.trim())}
            allowClear
          />
           <Input
            placeholder="请输入目标Ip"
            className="input-width"
            onChange={(e) => setDestIp(e.target.value.trim())}
            allowClear
          />
          <Input
            placeholder="请输入目标端口"
            className="input-width"
            onChange={(e) => setDestPort(e.target.value.trim())}
            allowClear
          />
          <Button type="primary" onClick={handleSearch}>
            查询
          </Button>
          <DownloadFile
            links={links}
            params={{
              from,
              to,
              clientip,
              clientPort,
              url,
              destip,
              destPort,
            }}
          />
        </div>
      </div>
      <Table
        dataSource={dataSource}
        columns={columns}
        loading={loading}
        pagination={pagination}
        rowKey={(record) => record.id}
      />
      ;
    </div>
  );
}
