import React from "react";
import { Button } from "antd";
import { post } from "../../utils/request";
import { downloadFile } from "../../utils/helper";
import { clearEmptyQuery } from "../../utils/request";
import qs from "qs";

export default function DownloadFile({ links, params }) {
  function handleDownload() {
    const query = qs.stringify(clearEmptyQuery(params));
    post(`${links.self}?action=exportcsv&${query}`, params).then(({ path }) => {
      downloadFile(path);
    });
  }

  return <Button onClick={handleDownload}>导出</Button>;
}
