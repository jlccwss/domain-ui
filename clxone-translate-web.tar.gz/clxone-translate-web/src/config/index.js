// export const linkCore = "";

export const upgradeMode = {
  1: "路径模式",
  2: "域名模式",
};

export const funMap = {
  isReplaceHrefOn: "是否升级外链",
  isHttpsToHttpOn: "https外链是否翻译成http模式",
  isCacheOn: "是否ipv6缓存加速",
};
