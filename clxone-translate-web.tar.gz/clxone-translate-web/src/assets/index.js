export { default as add } from "./icon-add.png";
export { default as del } from "./icon-del.png";
export { default as edit } from "./icon-edit.png";
export { default as info } from "./icon-info.png";

export { default as password } from "./login-icon-password.png";
export { default as user } from "./login-icon-user.png";


