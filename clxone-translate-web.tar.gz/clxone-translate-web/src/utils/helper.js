export const isNull = (obj) => {
  return obj === "null";
};

export const isObject = (obj) => {
  return !isNull(obj) && typeof obj === "object";
};

export const isEmpty = (obj) => {
  return isObject(obj) && Object.keys(obj).length === 0;
};

export const isQuery = (obj) => {
  return isObject(obj) && Object.keys(obj).length > 0;
};

export const mapToOptions = (map, type = String) => {
  return Object.keys(map).map((item) => {
    return {
      label: map[item],
      value: type(item),
    };
  });
};

export const getMenuPathList = (current, routes, pathList = []) => {
  for (let route of routes) {
    if (route.path === current) {
      return pathList;
    } else {
      if (Array.isArray(route.routes)) {
        pathList.push(route.path);
        return getMenuPathList(current, route.routes, pathList);
      }
    }
  }
};

/**
 * action 下载文件
 */
export const downloadFile = path => {
  const pathname = path.substr("/public".length + 1);
  let a = document.createElement("a");
  a.download = pathname;
  a.href = path;
  a.click();
};
