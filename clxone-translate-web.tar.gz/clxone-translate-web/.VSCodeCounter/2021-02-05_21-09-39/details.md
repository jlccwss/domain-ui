# Details

Date : 2021-02-05 21:09:39

Directory d:\work\clxone-cloud-translate

Total : 35 files,  13947 codes, 101 comments, 1926 blanks, all 15974 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [README.md](/README.md) | Markdown | 38 | 0 | 33 | 71 |
| [package.json](/package.json) | JSON | 53 | 0 | 1 | 54 |
| [public/index.html](/public/index.html) | HTML | 20 | 23 | 1 | 44 |
| [public/manifest.json](/public/manifest.json) | JSON | 25 | 0 | 1 | 26 |
| [src/App.css](/src/App.css) | CSS | 33 | 0 | 6 | 39 |
| [src/App.js](/src/App.js) | JavaScript | 23 | 0 | 3 | 26 |
| [src/App.test.js](/src/App.test.js) | JavaScript | 7 | 0 | 2 | 9 |
| [src/assets/index.js](/src/assets/index.js) | JavaScript | 6 | 0 | 3 | 9 |
| [src/config/index.js](/src/config/index.js) | JavaScript | 9 | 1 | 3 | 13 |
| [src/hooks/useSearch.js](/src/hooks/useSearch.js) | JavaScript | 0 | 3 | 2 | 5 |
| [src/index.css](/src/index.css) | CSS | 266 | 0 | 42 | 308 |
| [src/index.js](/src/index.js) | JavaScript | 21 | 3 | 4 | 28 |
| [src/logo.svg](/src/logo.svg) | XML | 1 | 0 | 0 | 1 |
| [src/pages/AccessLog/index.js](/src/pages/AccessLog/index.js) | JavaScript | 165 | 4 | 12 | 181 |
| [src/pages/AllowList/index.js](/src/pages/AllowList/index.js) | JavaScript | 172 | 25 | 15 | 212 |
| [src/pages/Dashboard/AppState.js](/src/pages/Dashboard/AppState.js) | JavaScript | 60 | 1 | 4 | 65 |
| [src/pages/Dashboard/FlowBar.js](/src/pages/Dashboard/FlowBar.js) | JavaScript | 103 | 9 | 8 | 120 |
| [src/pages/Dashboard/TopLine.js](/src/pages/Dashboard/TopLine.js) | JavaScript | 194 | 0 | 3 | 197 |
| [src/pages/Dashboard/index.js](/src/pages/Dashboard/index.js) | JavaScript | 225 | 0 | 20 | 245 |
| [src/pages/ForbidList/index.js](/src/pages/ForbidList/index.js) | JavaScript | 182 | 0 | 15 | 197 |
| [src/pages/Ipv6ApplicationUpgrade/index.js](/src/pages/Ipv6ApplicationUpgrade/index.js) | JavaScript | 263 | 14 | 28 | 305 |
| [src/pages/Layout/index.js](/src/pages/Layout/index.js) | JavaScript | 215 | 1 | 19 | 235 |
| [src/pages/Layout/style.css](/src/pages/Layout/style.css) | CSS | 3 | 0 | 0 | 3 |
| [src/pages/Log/index.js](/src/pages/Log/index.js) | JavaScript | 162 | 0 | 12 | 174 |
| [src/pages/Login/index.js](/src/pages/Login/index.js) | JavaScript | 83 | 1 | 10 | 94 |
| [src/pages/WafLog/index.js](/src/pages/WafLog/index.js) | JavaScript | 135 | 0 | 11 | 146 |
| [src/pages/Website/index.js](/src/pages/Website/index.js) | JavaScript | 240 | 0 | 15 | 255 |
| [src/pages/index.js](/src/pages/index.js) | JavaScript | 11 | 0 | 3 | 14 |
| [src/reportWebVitals.js](/src/reportWebVitals.js) | JavaScript | 12 | 0 | 2 | 14 |
| [src/routes/index.js](/src/routes/index.js) | JavaScript | 72 | 11 | 5 | 88 |
| [src/setupTests.js](/src/setupTests.js) | JavaScript | 1 | 4 | 1 | 6 |
| [src/utils/helper.js](/src/utils/helper.js) | JavaScript | 32 | 0 | 6 | 38 |
| [src/utils/request.js](/src/utils/request.js) | JavaScript | 98 | 1 | 22 | 121 |
| [tailwind.config.js](/tailwind.config.js) | JavaScript | 11 | 0 | 1 | 12 |
| [yarn-error.log](/yarn-error.log) | Log | 11,006 | 0 | 1,613 | 12,619 |

[summary](results.md)