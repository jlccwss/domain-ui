# Summary

Date : 2021-02-05 21:09:39

Directory d:\work\clxone-cloud-translate

Total : 35 files,  13947 codes, 101 comments, 1926 blanks, all 15974 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Log | 1 | 11,006 | 0 | 1,613 | 12,619 |
| JavaScript | 26 | 2,502 | 78 | 229 | 2,809 |
| CSS | 3 | 302 | 0 | 48 | 350 |
| JSON | 2 | 78 | 0 | 2 | 80 |
| Markdown | 1 | 38 | 0 | 33 | 71 |
| HTML | 1 | 20 | 23 | 1 | 44 |
| XML | 1 | 1 | 0 | 0 | 1 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 35 | 13,947 | 101 | 1,926 | 15,974 |
| public | 2 | 45 | 23 | 2 | 70 |
| src | 29 | 2,794 | 78 | 276 | 3,148 |
| src\assets | 1 | 6 | 0 | 3 | 9 |
| src\config | 1 | 9 | 1 | 3 | 13 |
| src\hooks | 1 | 0 | 3 | 2 | 5 |
| src\pages | 15 | 2,213 | 55 | 175 | 2,443 |
| src\pages\AccessLog | 1 | 165 | 4 | 12 | 181 |
| src\pages\AllowList | 1 | 172 | 25 | 15 | 212 |
| src\pages\Dashboard | 4 | 582 | 10 | 35 | 627 |
| src\pages\ForbidList | 1 | 182 | 0 | 15 | 197 |
| src\pages\Ipv6ApplicationUpgrade | 1 | 263 | 14 | 28 | 305 |
| src\pages\Layout | 2 | 218 | 1 | 19 | 238 |
| src\pages\Log | 1 | 162 | 0 | 12 | 174 |
| src\pages\Login | 1 | 83 | 1 | 10 | 94 |
| src\pages\WafLog | 1 | 135 | 0 | 11 | 146 |
| src\pages\Website | 1 | 240 | 0 | 15 | 255 |
| src\routes | 1 | 72 | 11 | 5 | 88 |
| src\utils | 2 | 130 | 1 | 28 | 159 |

[details](details.md)