<template>
    <div>
      <div class="breadcrumb">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>项目管理</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <el-row class="mt-xs">
        <el-col :span="6">
          <el-input clearable v-model="searchName" size="small" type="text" placeholder="项目名称&负责人姓名" />
        </el-col>
        <el-col class="ml-sm" :span="6">
          <el-select multiple clearable v-model="searchStatus" size="small" class="w-full" placeholder="项目状态">
            <el-option :key="proStatus.id" v-for="proStatus in proStatusList" :label="proStatus.name" :value="proStatus.id"></el-option>
          </el-select>
        </el-col>
        <el-col :span="6">
          <el-button @click="handlerSearch" type="primary" size="small">
            搜索
          </el-button>
          <el-button v-if="authority.includes('pro_add_btn')" @click="handlerAdd" type="primary" size="small">
            新建
          </el-button>
          <el-button v-if="authority.includes('pro_del_btn')" @click="handlerDelList" type="primary" size="small">
            删除
          </el-button>
        </el-col>
      </el-row>
     <el-table
      :data="list"
      class="mt-xs"
      v-loading="loading"
      max-height="700"
      header-cell-class-name="table-head"
      @selection-change="handleSelectionChange"
      style="width: 100%">
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <el-table-column
        label="项目名称">
        <template slot-scope="{ row }">
          <el-link @click="handlerToPro(row.id)" type="primary">{{row.name}}</el-link>
        </template>
      </el-table-column>
      <el-table-column
        prop="seq"
        label="项目编号">
      </el-table-column>
      <el-table-column
        prop="customerName"
        label="客户名称">
      </el-table-column>
      <el-table-column
        label="项目状态">
        <template slot-scope="{ row }">
          <span>{{proStatusMap[row.status]}}</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="ownerName"
        label="负责人">
      </el-table-column>
      <el-table-column
        label="项目金额">
        <template slot-scope="{ row }">
          {{row.budget}}万元
        </template>
      </el-table-column>
      <el-table-column
        width="160"
        label="开始时间">
        <template slot-scope="{ row }">
          {{row.beginTime | dateFormat('yyyy-mm-dd')}}
        </template>
      </el-table-column>
      <el-table-column
        width="160"
        label="结束时间">
        <template slot-scope="{ row }">
          {{row.endTime | dateFormat('yyyy-mm-dd')}}
        </template>
      </el-table-column>
      <el-table-column
        width="160"
        label="最后更新时间">
        <template slot-scope="{ row }">
          {{row.updateTime | dateFormat}}
        </template>
      </el-table-column>
      <el-table-column
        width="160"
        label="创建时间">
        <template slot-scope="{ row }">
          {{row.createTime | dateFormat}}
        </template>
      </el-table-column>
      <el-table-column width="160" label="操作">
        <template slot-scope="{ row }">
          <el-button @click="handlerEdit(row.id)" type="text" size="small">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-row class="pagination-con">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pagination.currpage"
        :page-size="pagination.pagesize"
        layout="total, prev, pager, next, jumper"
        :total="pagination.total">
      </el-pagination>
    </el-row>
    </div>
</template>

<script>
import $http from '@/http';
import { getUser } from '@/user';
import authority from './../home/authority';

export default {
  data() {
    return {
      authority: [],
      searchName: '',
      searchStatus: '',
      list: [],
      proStatusList: [],
      proStatusMap: {},
      multipleSelection: [],
      loading: false,
      dialogVisible: false,
      customerLinkVisable: false,
      pagination: {
        currpage: 1,
        pagesize: 10
      },
    };
  },
  mounted() {
    if (this.$route.params.pageNum) {
      this.pagination.currpage = this.$route.params.pageNum;
    }
    this.getProStatusList().then(() => this.getList());
    const user = getUser();
    this.authority = authority[user.role] || [];
    this.customerLinkVisable = user.role !== 'xiezuo';
  },
  methods: {
    handleCurrentChange(pageNum) {
      this.pagination.currpage = pageNum;
      this.getList();
    },
    handleSizeChange(pageSize) {
      this.pagination.pagesize = pageSize;
      this.getList();
    },
    handlerSearch() {
      this.pagination.currpage = 1;
      this.getList();
    },
    handlerToPro(id) {
      this.$router.push(`/home/programMange/view?id=${id}`);
    },
    handlerToCustomer(id) {
      this.$router.push(`/home/customers/view?id=${id}`);
    },
    handlerAdd() {
      this.$router.push('/home/programMange/add');
    },
    handlerEdit(id) {
      this.$router.push({
        name: 'programMangeDetail',
        params: {
          id,
          pageNum: this.pagination.currpage
        }
      });
    },
    getProStatusList() {
      return $http.get('/apis/status/statuss').then(res => {
        if (res.data.status === 0) {
          this.proStatusList = res.data.data;
          this.proStatusList.forEach(item => {
            this.proStatusMap[item.id] = item.name;
          });
        }
      });
    },
    getList() {
      this.loading = true;
      const { currpage, pagesize } = this.pagination;
      const url = `/apis/item/list?pageNum=${currpage}&pageSize=${pagesize}&searchName=${this.searchName}&searchStatus=${this.searchStatus}`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.list = res.data.data;
          this.pagination.total = res.data.total;
        }
        this.loading = false;
      }, () => {
        this.loading = false;
      });
    },
    handlerDelList() {
      if (this.multipleSelection.length) {
        this.$confirm('删除后不可恢复', '确认要删除这条信息吗？')
          .then(() => {
            let delList = this.multipleSelection.map(item => {
              const url = `/apis/item/item/${item.id}`;
              return $http.delete(url);
            });
            
            Promise.all(delList).then(() => {
              this.$notify.success({
                  message: '删除成功'
                });
                this.getList();
            }, () => {
              this.$notify.error({
                message: '删除失败'
              });
            });
          });
      } else {
        this.$notify.warning('请选择要删除的项目');
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
  }
};
</script>
<style scoped lang="scss">

</style>