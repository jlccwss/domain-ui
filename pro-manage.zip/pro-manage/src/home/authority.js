const authority = {
  'admin': ['users', 'customers', 'customersDetail', 'programMange', 'programMangeDetail', 'programMangeView', 'assign_btn', 'pro_add_btn', 'pro_del_btn'], //管理员
  'xiaoshou': ['customers', 'programMange', 'customersDetail', 'programMangeDetail', 'programMangeView', 'pro_add_btn', 'pro_del_btn'], //销售
  'xiezuo': ['programMange', 'programMangeDetail', 'programMangeView'] //非销售
};

export default authority;
