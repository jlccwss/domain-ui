import Vue from 'vue';

import dateFormat from './dateFilter';

Vue.filter('dateFormat', dateFormat);