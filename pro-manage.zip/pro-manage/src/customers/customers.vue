<template>
    <div>
      <div class="breadcrumb">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>客户管理</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <el-row class="mt-xs" :gutter="20">
        <el-col :span="4">
          <el-input clearable v-model="searchName" size="small" type="text" placeholder="客户名称&联系人&负责人" />
        </el-col>
        <el-col :span="4">
          <el-select clearable size="small" class="w-full" v-model="searchIndustry" placeholder="行业">
            <el-option :key="industry.id" :label="industry.name" :value="industry.id" v-for="industry in industryList"></el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-select clearable size="small" class="w-full" v-model="searchCome" placeholder="来源">
            <el-option :key="come.id" :label="come.name" :value="come.id" v-for="come in comeList"></el-option>
          </el-select>
        </el-col>
        <el-col :span="6">
          <el-button @click="handlerSearch" type="primary" size="small">
            搜索客户
          </el-button>
          <el-button @click="handlerAdd" type="primary" size="small">
            新建客户
          </el-button>
          <el-button @click="handlerDelList" type="primary" size="small">
            删除
          </el-button>
          <el-button v-if="authority.includes('assign_btn')" @click="handlerAssign" type="primary" size="small">
            分配
          </el-button>
        </el-col>
      </el-row>
     <el-table
      :data="list"
      class="mt-xs"
      v-loading="loading"
      max-height="700"
      header-cell-class-name="table-head"
      @selection-change="handleSelectionChange"
      style="width: 100%">
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <el-table-column
        label="客户名称">
        <template slot-scope="{ row }">
          <el-link @click="handlerToCustomer(row.id)" type="primary">{{row.name}}</el-link>
        </template>
      </el-table-column>
      <el-table-column
        label="客户级别">
        <template slot-scope="{ row }">
          {{levelMap[row.level]}}
        </template>
      </el-table-column>
      <el-table-column
        label="行业">
        <template slot-scope="{ row }">
          {{industryMap[row.industry]}}
        </template>
      </el-table-column>
      <el-table-column
        label="来源">
        <template slot-scope="{ row }">
          {{comeMap[row.come]}}
        </template>
      </el-table-column>
      <el-table-column
        prop="contactsName"
        label="联系人姓名">
      </el-table-column>
      <el-table-column
        prop="contactsMobile"
        label="联系人电话">
      </el-table-column>
      <el-table-column
        prop="contactsKey"
        label="关键决策人">
        <template slot-scope="{ row }">
          {{ row.contactsKey === '1' ? '否' : '是' }}
        </template>
      </el-table-column>
      <el-table-column
        prop="ownerName"
        label="负责人">
      </el-table-column>
      <el-table-column
        width="160"
        label="最后更新时间">
        <template slot-scope="{ row }">
          {{row.updateTime | dateFormat}}
        </template>
      </el-table-column>
      <el-table-column
        width="160"
        label="创建时间">
        <template slot-scope="{ row }">
          {{row.createTime | dateFormat}}
        </template>
      </el-table-column>
      <el-table-column width="160" label="操作">
        <template slot-scope="{ row }">
          <el-button @click="handlerEdit(row.id)" type="text" size="small">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-row class="pagination-con">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pagination.currpage"
        :page-size="pagination.pagesize"
        layout="total, prev, pager, next, jumper"
        :total="pagination.total">
      </el-pagination>
    </el-row>
    <assign-dialog v-if="assignDialog" :list="multipleSelection" @close="handleClose"></assign-dialog>
    </div>
</template>

<script>
import $http from '@/http';
import authority from './../home/authority';
import { getUser } from '@/user';
import assignDialog from './assignDialog.vue';

export default {
  components: {
    assignDialog
  },
  data() {
    return {
      searchName: '',
      searchIndustry: '',
      searchCome: '',
      authority: [],
      levelMap: {},
      comeMap: {},
      comeList: [],
      industryMap: {},
      industryList: [],
      list: [],
      multipleSelection: [],
      loading: false,
      dialogVisible: false,
      assignDialog: false,
      pagination: {
        currpage: 1,
        pagesize: 10
      },
    };
  },
  mounted() {
    if (this.$route.params.pageNum) {
      this.pagination.currpage = this.$route.params.pageNum;
    }
    Promise.all([
      this.getLevels(),
      this.getIndustrys(),
      this.getComes(),
      this.getCurRole(),
    ]).then(() => this.getList());
  },
  methods: {
    getCurRole() {
      this.user = getUser();
      this.authority = authority[this.user.role] || [];
    },
    getLevels() {
      const url = `/apis/level/levels`;
      return $http.get(url).then(res => {
        if (res.data.status === 0) {
          const list = res.data.data;
          list.forEach(item => {
            this.levelMap[item.id] = item.name;
          });
        }
      });
    },
    getIndustrys() {
      const url = `/apis/industry/industrys`;
      return $http.get(url).then(res => {
        if (res.data.status === 0) {
          const list = res.data.data;
          this.industryList = list;
          list.forEach(item => {
            this.industryMap[item.id] = item.name;
          });
        }
      });
    },
    getComes() {
      const url = `/apis/come/comes`;
      return $http.get(url).then(res => {
        if (res.data.status === 0) {
          const list = res.data.data;
          this.comeList = list;
          list.forEach(item => {
            this.comeMap[item.id] = item.name;
          });
        }
      });
    },
    handlerToCustomer(id) {
      this.$router.push(`/home/customers/view?id=${id}`);
    },
    handlerSearch() {
      this.pagination.currpage = 1;
      this.getList();
    },
    handleCurrentChange(pageNum) {
      this.pagination.currpage = pageNum;
      this.getList();
    },
    handleSizeChange(pageSize) {
      this.pagination.pagesize = pageSize;
      this.getList();
    },
    handlerAdd() {
      this.$router.push('/home/customers/add');
    },
    handlerEdit(id) {
      this.$router.push({
        name: 'customersDetail',
        params: {
          pageNum: this.pagination.currpage,
          id
        }
      });
    },
    getList() {
      this.loading = true;
      const { currpage, pagesize } = this.pagination;
      let url = `/apis/customer/list?pageNum=${currpage}&pageSize=${pagesize}`;
      if (this.searchName) {
        url += `&searchName=${this.searchName}`;
      }
      if (this.searchIndustry) {
        url += `&searchIndustry=${this.searchIndustry}`;
      }
      if (this.searchCome) {
        url += `&searchCome=${this.searchCome}`;
      }
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.list = res.data.data;
          this.pagination.total = res.data.total;
        }
        this.loading = false;
      }, () => {
        this.loading = false;
      });
    },
    handlerDelList() {
      if (this.multipleSelection.length) {
        this.$confirm('删除后不可恢复', '确认要删除这条信息吗？')
          .then(() => {
            let delList = this.multipleSelection.map(item => {
              const url = `/apis/customer/customer/${item.id}`;
              return $http.delete(url);
            });
            
            Promise.all(delList).then((resArr) => {
              let errObj = resArr.find(res => res.data.status);
              if (errObj) {
                this.$notify.error({
                  message: errObj.data.msg
                });
              } else {
                this.$notify.success({
                  message: '删除成功'
                });
              }
              
              this.getList();
            }, () => {
              this.$notify.error({
                message: '删除失败'
              });
            });
          });
      } else {
        this.$notify.warning('请选择要删除的客户');
      }
    },
    handlerDel(rowId) {
      this.$confirm('删除后不可恢复', '确认要删除这条信息吗？')
          .then(() => {
            const url = `/apis/customer/customer/${rowId}`;
            $http.delete(url).then(res => {
              if (res.data.status) {
                this.$notify.error({
                  message: res.data.msg
                });
              } else {
                this.$notify.success({
                  message: '删除成功'
                });
                this.getList();
              }
            }, () => {
              this.$notify.error({
                message: '删除失败'
              });
            });
          });
    },
    handlerAssign() {
      if (this.multipleSelection.length) {
        this.assignDialog = true;
      } else {
        this.$notify.warning('请选择要分配的客户');
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    handleClose(b) {
      if (b) {
        this.getList();
      }
      this.assignDialog = false;
    }
  }
};
</script>
<style scoped lang="scss">

</style>