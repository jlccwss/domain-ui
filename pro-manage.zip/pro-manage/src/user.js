var _user = {};

export function setUser(user) {
  _user = user;
}

export function getUser() {
  return _user;
}