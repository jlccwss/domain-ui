<template>
    <el-form ref="form" label-width="100px" :rules="rules" :model="data">
      <div class="title">客户详情</div>
      <el-row>
      <el-col :span="12">
      <el-form-item label="姓名" prop="name">
        <el-input :disabled="type ==='view'" v-model="data.name"></el-input>
        <div class="align-left">（公司或单位，工商注册登记名称）</div>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="客户级别" prop="level">
        <el-select :disabled="type ==='view'" class="w-full"  v-model="data.level">
          <el-option :key="level.id" :label="level.name" :value="level.id" v-for="level in levels"></el-option>
        </el-select>
      </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="12">
      <el-form-item label="行业" prop="industry">
        <el-select :disabled="type ==='view'" class="w-full"  v-model="data.industry">
          <el-option :key="industry.id" :label="industry.name" :value="industry.id" v-for="industry in industrys"></el-option>
        </el-select>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="来源" prop="come">
        <el-select :disabled="disabled" class="w-full"  v-model="data.come">
          <el-option :key="come.id" :label="come.name" :value="come.id" v-for="come in comes"></el-option>
        </el-select>
      </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="12">
      <el-form-item label="联系人姓名" prop="contactsName">
        <el-input :disabled="type ==='view'" v-model="data.contactsName"></el-input>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="联系人电话" prop="contactsMobile">
        <el-input :disabled="type ==='view'" v-model="data.contactsMobile"></el-input>
      </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="12">
      <el-form-item label="关键决策人" prop="contactsKey">
        <el-select :disabled="type ==='view'" class="w-full"  v-model="data.contactsKey">
          <el-option label="是" value="0"></el-option>
          <el-option label="否" value="1"></el-option>
        </el-select>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="省" prop="province">
        <el-select @change="changeProvice" :disabled="type ==='view'" class="w-full" v-model="data.province">
          <el-option :key="province.provinceid" :label="province.province" :value="province.provinceid" v-for="province in provinces"></el-option>
        </el-select>
      </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="12">
      <el-form-item label="市" prop="city">
        <el-select @change="changeCity" :disabled="type ==='view'" class="w-full" v-model="data.city">
          <el-option :key="city.cityid" :label="city.city" :value="city.cityid" v-for="city in citys"></el-option>
        </el-select>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="区" prop="area">
        <el-select :disabled="type ==='view'" class="w-full" v-model="data.area">
          <el-option :key="area.areaid" :label="area.area" :value="area.areaid" v-for="area in areas"></el-option>
        </el-select>
      </el-form-item>
      </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
        <el-form-item label="客户地址" prop="address">
          <el-input :disabled="type ==='view'" v-model="data.address"></el-input>
        </el-form-item>
        </el-col>
        <el-col :span="12">
        <el-form-item label="负责人" prop="owner">
          <el-select :disabled="type ==='view'" class="w-full" v-model="data.owner">
            <el-option :key="owner.id" :label="owner.name" :value="owner.id" v-for="owner in owners"></el-option>
          </el-select>
        </el-form-item>
        </el-col>
      </el-row>
      <el-form-item>
        <el-button v-if="type !== 'view'" type="primary" @click="handleSave()">{{btnText}}</el-button>
        <el-button @click="handleClose()">取消</el-button>
      </el-form-item>
    </el-form>
</template>

<script>
import $http from '@/http';
import { getUser } from '@/user';

export default {
  data() {
    return {
      data: {
        province: '',
        city: '',
        area: ''
      },
      levels: [],
      comes: [],
      industrys: [],
      owners: [],
      provinces: [],
      citys: [],
      areas: [],
      disabled: false,
      rules: {
        name: [
           { required: true, message: '请输入姓名', trigger: 'blur' },
        ],
        level: [
           { required: true, message: '请选择客户级别', trigger: 'blur' },
        ],
        industry: [
           { required: true, message: '请选择行业', trigger: 'blur' },
        ],
        come: [
           { required: true, message: '请选择来源', trigger: 'blur' },
        ],
        contactsName: [
           { required: true, message: '请输入联系人姓名', trigger: 'blur' },
        ],
        contactsMobile: [
           { required: true, message: '请输入联系人电话', trigger: 'blur' },
        ],
        contactsKey: [
           { required: true, message: '请选择关键决策人', trigger: 'blur' },
        ],
        address: [
           { required: true, message: '请输入客户地址', trigger: 'blur' },
        ],
        owner: [
           { required: true, message: '请选择负责人', trigger: 'blur' },
        ],
        province: [
           { required: true, message: '请选择省', trigger: 'blur' },
        ],
        city: [
           { required: true, message: '请选择城市', trigger: 'blur' },
        ],
      },
      type: 'add',
      btnText: '立即创建'
    };
  },
  mounted() {
    this.getLevels();
    this.getIndustrys();
    this.getComes();
    this.getOwners();
    this.getProvinces();
    const { id } = this.$route.params;
    if (id === 'add') {
      this.type = id;
    } else if (id === 'view') {
      const uid = this.$route.query.id;
      this.type = id;
      this.getDetail(uid);
      this.disabled = true;
    } else {
      this.type = 'edit';
      this.btnText = '更新';
      const user = getUser();
      if (user.role === 'xiaoshou') {
        this.disabled = true;
      }
      this.getDetail(id);
    }
  },
  methods: {
    changeProvice(provinceId) {
      this.citys = [];
      this.areas = [];
      this.data.city = '';
      this.data.area = '';
      this.getCitys(provinceId);
    },
    changeCity(cityId) {
      this.areas = [];
      this.data.area = '';
      this.getAreas(cityId);
    },
    getDetail(id) {
      const url = `/apis/customer/customer/${id}`;
      $http.get(url).then(res => {
        this.data = res.data;
        this.getCitys(this.data.province);
        this.getAreas(this.data.city);
      });
    },
    getProvinces() {
      const url = `/apis/provinces`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.provinces = res.data.data;
        }
      });
    },
    getCitys(provinceId) {
      const url = `/apis/provinces/${provinceId}`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.citys = res.data.data;
        }
      });
    },
    getAreas(cityId) {
      const url = `/apis/cities/${cityId}`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.areas = res.data.data;
        }
      });
    },
    getOwners() {
      const url = `/apis/account/owners`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.owners = res.data.data;
        }
      });
    },
    getLevels() {
      const url = `/apis/level/levels`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.levels = res.data.data;
        }
      });
    },
    getIndustrys() {
      const url = `/apis/industry/industrys`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.industrys = res.data.data;
        }
      });
    },
    getComes() {
      const url = `/apis/come/comes`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.comes = res.data.data;
        }
      });
    },
    handleSave() {
      this.$refs.form.validate(valid => {
          if (valid) {
            let url = '/apis/customer/customer';
            let func = $http.post;
            if (this.type === 'edit') {
              func = $http.put;
              url += '/' + this.data.id;
            }
            const { owner } = this.data;
            const ownerName = this.owners.find(item => item.id === owner).name;
            this.data.ownerName = ownerName;
            func(url, this.data).then(res => {
              if (res.data.status === 0) {
                this.$notify.success({
                  message: '保存成功'
                });
                setTimeout(() => {
                  this.handleClose();
                }, 500);
              } else {
                this.$notify.error({
                  message: res.data.msg
                });
              }
            });
          }
      });
    },
    handleClose() {
      if (this.$route.params.pageNum) {
        this.$router.push({
          name: 'customers',
          params: {
            pageNum: this.$route.params.pageNum
          }
        });
      } else {
        this.$router.push('/home/customers');
      }
    }
  }
};
</script>
<style scoped lang="scss">
.title {
  text-align: left;
  padding: 20px 10px;
}
</style>