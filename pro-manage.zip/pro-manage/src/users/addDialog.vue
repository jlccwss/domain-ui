<template>
  <el-dialog
    title="新增"
    :visible="true"
    width="60%"
    @close="handleClose">
    <el-form ref="form" label-width="120px" :rules="rules" :model="editRow">
      <el-form-item label="登录名" prop="username">
        <el-input v-model="editRow.username"></el-input>
      </el-form-item>
      <el-form-item v-if="type==='add'" label="密码" prop="passwd">
        <el-input v-model="editRow.passwd" show-password></el-input>
      </el-form-item>
      <el-form-item v-if="type==='add'" label="再次输入密码" prop="passwdRe">
        <el-input v-model="editRow.passwdRe" show-password></el-input>
      </el-form-item>
      <el-form-item label="角色" prop="role">
        <el-select class="w-full"  v-model="editRow.role">
          <el-option :key="role.id" :label="role.name" :value="role.id" v-for="role in roleList"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="部门" prop="department">
        <el-select class="w-full"  v-model="editRow.department">
          <el-option :key="depart.id" :label="depart.name" :value="depart.id" v-for="depart in departments"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="员工姓名" prop="name">
        <el-input v-model="editRow.name"></el-input>
      </el-form-item>
      <el-form-item label="电话" prop="mobile">
        <el-input v-model="editRow.mobile"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleClose(true)">{{btnText}}</el-button>
        <el-button @click="handleClose(false)">取消</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>

<script>
import $http from '@/http';

export default {
  props: ['data'],
  data() {
    return {
      btnText: '立即创建',
      editRow: {},
      departments: [],
      roleList: [],
      type: 'add',
      rules: {
        username: [
           { required: true, message: '请输入用户名', trigger: 'blur' },
        ],
        passwd: [
           { required: true, message: '请输入密码', trigger: 'blur' },
        ],
        passwdRe: [
           { required: true, message: '请输入确认密码', trigger: 'blur' },
        ],
        role: [
           { required: true, message: '请选择角色', trigger: 'blur' },
        ],
        department: [
           { required: true, message: '请选择部门', trigger: 'blur' },
        ],
        name: [
           { required: true, message: '请输入姓名', trigger: 'blur' },
        ],
        mobile: [
           { required: true, message: '请输入电话', trigger: 'blur' },
        ],
      }
    };
  },
  mounted() {
    this.getDepartmentList();
    this.getRoleList();
    this.editRow = { ...this.data };
    if (this.editRow.id) {
      this.btnText = '更新';
      this.type = 'edit';
    }
  },
  methods: {
    getRoleList() {
      const url = `/apis/account/roles`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.roleList = res.data.data;
        }
      });
    },
    getDepartmentList() {
      const url = `/apis/department/departments`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.departments = res.data.data;
        }
      });
    },
    handleClose(isSave) {
      if (isSave) {
        this.$refs.form.validate(valid => {
          if (valid) {
            let url = 'apis/account/user';
            let func = this.editRow.id ? $http.put : $http.post;
            if (this.editRow.id) {
              url += '/' + this.editRow.id;
            }
            func(url, this.editRow).then(res => {
              if (res.data.status === 0) {
                this.$notify.success({
                  message: '保存成功'
                });
                this.$emit('close', true);
              } else {
                this.$notify.error({
                  message: res.data.msg
                });
              }
            });
          }
        });
      } else {
        this.$emit('close');
      }
    }
  }
};
</script>
<style scoped lang="scss">

</style>