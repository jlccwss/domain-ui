<template>
    <div>
      <div class="breadcrumb">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>账号管理</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <el-row class="mt-xs">
        <el-col :span="6">
          <el-input clearable v-model="searchName" size="small" type="text" placeholder="姓名" />
        </el-col>
        <el-col :span="6">
          <el-button @click="handlerSearch" type="primary" size="small">
            搜索
          </el-button>
          <el-button @click="handlerAdd" type="primary" size="small">
            新增
          </el-button>
          <el-button @click="handlerDelList" type="primary" size="small">
            删除
          </el-button>
        </el-col>
      </el-row>
     <el-table
      :data="list"
      class="mt-xs"
      v-loading="loading"
      max-height="700"
      header-cell-class-name="table-head"
      @selection-change="handleSelectionChange"
      style="width: 100%">
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <el-table-column
        prop="name"
        label="姓名">
      </el-table-column>
      <el-table-column
        prop="mobile"
        label="电话">
      </el-table-column>
      <el-table-column
        label="部门">
        <template slot-scope="{ row }">
          <span>{{departmentMap[row.department]}}</span>
        </template>
      </el-table-column>
      <el-table-column
        width="160"
        label="最后更新时间">
        <template slot-scope="{ row }">
          {{row.updateTime | dateFormat}}
        </template>
      </el-table-column>
      <el-table-column
        width="160"
        label="创建时间">
        <template slot-scope="{ row }">
          {{row.createTime | dateFormat}}
        </template>
      </el-table-column>
      <el-table-column width="160" label="操作">
        <template slot-scope="{ row }">
          <el-button @click="handlerRestPwd(row)" type="text" size="small">重置密码</el-button>
          <el-button @click="handlerEdit(row)" type="text" size="small">编辑</el-button>
          <el-button @click="handlerDel(row.id)" type="text" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-row class="pagination-con">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pagination.currpage"
        :page-size="pagination.pagesize"
        layout="total, prev, pager, next, jumper"
        :total="pagination.total">
      </el-pagination>
    </el-row>
    <add-dialog v-if="dialogVisible" :data="editRow" @close="handleClose"></add-dialog>
    </div>
</template>

<script>
import $http from '@/http';
import addDialog from './addDialog.vue';

export default {
  components: {
    addDialog
  },
  data() {
    return {
      departmentMap: {},
      list: [],
      multipleSelection: [],
      loading: false,
      dialogVisible: false,
      pagination: {
        currpage: 1,
        pagesize: 10
      },
      searchName: ''
    };
  },
  mounted() {
    this.getDepartmentList().then(() => this.getList());
  },
  methods: {
    getDepartmentList() {
      const url = `/apis/department/departments`;
      return $http.get(url).then(res => {
        if (res.data.status === 0) {
          let list = res.data.data;
          list.forEach(item => {
            this.departmentMap[item.id] = item.name;
          });
        }
      });
    },
    handleCurrentChange(pageNum) {
      this.pagination.currpage = pageNum;
      this.getList();
    },
    handleSizeChange(pageSize) {
      this.pagination.pagesize = pageSize;
      this.getList();
    },
    handlerAdd() {
      this.editRow = {};
      this.dialogVisible = true;
    },
    handlerEdit(row) {
      this.editRow = row;
      this.dialogVisible = true;
    },
    handlerSearch() {
      this.pagination.currpage = 1;
      this.getList();
    },
    getList() {
      this.loading = true;
      const { currpage, pagesize } = this.pagination;
      const url = `/apis/account/users?pageNum=${currpage}&pageSize=${pagesize}&searchName=${this.searchName}`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.list = res.data.data;
          this.pagination.total = res.data.total;
        }
        this.loading = false;
      }, () => {
        this.loading = false;
      });
    },
    handlerRestPwd(row) {
      this.$confirm('重置密码', '确认要重置密码吗？')
          .then(() => {
            const url = `/apis/account/passwd`;
            const data = {
              id: row.uid,
              oldpasswd: row.passwd,
              newpasswd: 'abc123'
            };
            $http.put(url, data).then(res => {
              if (res.data.status) {
                this.$notify.error({
                  message: res.data.msg
                });
              } else {
                this.$notify.success({
                  message: '重置成功'
                });
                this.getList();
              }
            }, () => {
              this.$notify.error({
                message: '重置失败'
              });
            });
          });
    },
    handlerDelList() {
      if (this.multipleSelection.length) {
        this.$confirm('删除后不可恢复', '确认要删除这条信息吗？')
          .then(() => {
            let delList = this.multipleSelection.map(item => {
              const url = `/apis/account/user/${item.id}`;
              return $http.delete(url);
            });
            
            Promise.all(delList).then(() => {
              this.$notify.success({
                  message: '删除成功'
                });
                this.getList();
            }, () => {
              this.$notify.error({
                message: '删除失败'
              });
            });
          });
      } else {
        this.$notify.warning('请选择要删除的用户');
      }
    },
    handlerDel(rowId) {
      this.$confirm('删除后不可恢复', '确认要删除这条信息吗？')
          .then(() => {
            const url = `/apis/account/user/${rowId}`;
            $http.delete(url).then(res => {
              if (res.data.status) {
                this.$notify.error({
                  message: res.data.msg
                });
              } else {
                this.$notify.success({
                  message: '删除成功'
                });
                this.getList();
              }
            }, () => {
              this.$notify.error({
                message: '删除失败'
              });
            });
          });
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    handleClose(b) {
      if (b) {
        this.getList();
      }
      this.dialogVisible = false;
    }
  }
};
</script>
<style scoped lang="scss">

</style>