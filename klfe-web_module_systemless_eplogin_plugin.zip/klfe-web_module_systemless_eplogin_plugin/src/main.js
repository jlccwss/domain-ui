import { template } from './template.js';
import pkg from '../package.json';
import UserProfile from './components/UserProfile';
import style from './style.module.css';
import { rawWindow, lx } from '@kl/web-runtime';

export const name = pkg.name;
export const container = '#admin-layout_app-container';
export const slots = {
  'header_nav_slot': '#admin-layout_header-nav',
  'header_warehouse_slot': '#admin-layout_header-warehouse',
  'header_warehouse_mobile_slot': '#admin-layout_header-warehouse-mobile',
  'header_links_slot': '#admin-layout_header-links',
  'header_links_mobile_slot': '#admin-layout_header-links-mobile',
  'header_notify_slot': '#admin-layout_header-notify',
  'aside_nav_slot': '#admin-layout_aside-nav-container',
  // 兼容3.0.0中划线的slot，平稳过度后再删除
  'header-nav-slot': '#admin-layout_header-nav',
  'header-warehouse-slot': '#admin-layout_header-warehouse',
  'header-warehouse-mobile-slot': '#admin-layout_header-warehouse-mobile',
  'header-links-slot': '#admin-layout_header-links',
  'header-links-mobile-slot': '#admin-layout_header-links-mobile',
  'header-notify-slot': '#admin-layout_header-notify',
  'aside-nav-slot': '#admin-layout_aside-nav-container',
};

let layoutEl = null;

let unwatchPageTipsInfo = null;

let userProfile = null;

let isInIframe = false;

let mediaQuery = 'pc';
let pcMediaQueryList = null;
let padMediaQueryList = null;
let mobileMediaQueryList = null;
let navIsOpen = true;

let $globalApi = null;
let $globalOptions = null;

function render(target, api, options = {}) {
  target.style.height = "100%";
  target.style.width = "100%";

  $globalApi = api;
  $globalOptions = options;

  let div = document.createElement('div');
  div.innerHTML = template(options.position);
  layoutEl = div;
  target.appendChild(div);

  isInIframe = inIframe();

  try {
    setTheme();

    // 展示系统信息
    showAppInfo(div);

    // 展示环境标记
    showEnvBadge(div);

    // 展示返回旧版
    showHeaderSwitch(div, options.hideSwitch);

    // 展示用户信息
    showUserProfile(
      div,
      div.querySelector('#admin-layout_header-user-profile'),
      options.hideProfile
    );

    // 兼容移动端的事件监听
    bindEventListener(div);

    // 获取屏幕尺寸
    getMediaQuery();

    setHeaderState(div, true);
    setAsideNavState(div);
    if (typeof api.on === 'function') {
      //隐藏侧边栏事件
      api.on('hide-aside', () => {
        navIsOpen = false;
        setAsideNavState(div);
      });
      //显示侧边栏事件
      api.on('show-aside', () => {
        navIsOpen = true;
        setAsideNavState(div);
      });
      //隐藏header事件
      api.on('hide-header', () => {
        setHeaderState(div, false);
      });
      //显示header事件
      api.on('show-header', () => {
        setHeaderState(div, true);
      });
    }
    setHeaderZIndex(options.layoutZIndex);
    initGlobalNotification(options.globalNotification);
  } catch(e) {
    console.error(e);
  }
}

function setTheme() {
  const theme = $globalApi.getAppTheme() || {};
  theme['themeHeaderFontColor'] &&
    document.body.style.setProperty(
      '--themeHeaderFontColor',
      theme['themeHeaderFontColor']
    );
  theme['themeBackgroundColor'] &&
    document.body.style.setProperty(
      '--themeBackgroundColor',
      theme['themeBackgroundColor']
    );
  theme['themeAsideBackgroundColor'] &&
    document.body.style.setProperty(
      '--themeAsideBackgroundColor',
      theme['themeAsideBackgroundColor']
    );
  theme['themeHoverBackgroundColor'] &&
    document.body.style.setProperty(
      '--themeHoverBackgroundColor',
      theme['themeHoverBackgroundColor']
    );
  document.body.style.setProperty('-webkit-font-smoothing', 'auto');
}

// 获取屏幕尺寸
function getMediaQuery() {
  if (window) {
    pcMediaQueryList = window.matchMedia('(min-width: 1195px)');
    padMediaQueryList = window.matchMedia(
      '(min-width: 768px) and (max-width: 1194px)'
    );
    mobileMediaQueryList = window.matchMedia('(max-width: 767px)');

    padMediaQueryListener(padMediaQueryList);
    pcMediaQueryListener(pcMediaQueryList);
    mobileMediaQueryListener(mobileMediaQueryList);

    if (mediaQuery === 'mobile' || mediaQuery === 'pad') {
      navIsOpen = false;
      $globalApi.setAsideState && $globalApi.setAsideState(false);
    }

    padMediaQueryList.addListener(padMediaQueryListener);
    pcMediaQueryList.addListener(pcMediaQueryListener);
    mobileMediaQueryList.addListener(mobileMediaQueryListener);
  }
}

function pcMediaQueryListener(e) {
  const printMediaQueryList = window.matchMedia('print');
  if (!printMediaQueryList.matches && e.matches) {
    mediaQuery = 'pc';
    navIsOpen = true;
    const sideNavEl = layoutEl.querySelector(
      `.${style['admin-layout_aside-nav']}`
    );
    const sideNavWrapEl = layoutEl.querySelector(
      `.${style['admin-layout_aside-nav-wrap']}`
    );
    const contentEl = layoutEl.querySelector(
      `.${style['admin-layout_body-content']}`
    );
    const asideWhiteList = $globalOptions?.asideWhiteList || [];
    const inIframeAsideShow = !!asideWhiteList
      .map((str) => new RegExp(str))
      .find((reg) => reg.test(window.location.pathname));
    if ($globalOptions.hideNav || (isInIframe && (!asideWhiteList.length || !inIframeAsideShow))) {
      sideNavEl.style.display = 'none';
      sideNavEl.style.width = '0px';
      contentEl.style.left = '0px';
    } else {
      sideNavEl.style.display = 'block';
      sideNavEl.style.width = '200px';
      sideNavWrapEl.style.width = '200px';
      contentEl.style.left = '200px';
    }
  }
}

function padMediaQueryListener(e) {
  const printMediaQueryList = window.matchMedia('print');
  if (!printMediaQueryList.matches && e.matches) {
    mediaQuery = 'pad';
    navIsOpen = false;
    const sideNavEl = layoutEl.querySelector(
      `.${style['admin-layout_aside-nav']}`
    );
    const sideNavWrapEl = layoutEl.querySelector(
      `.${style['admin-layout_aside-nav-wrap']}`
    );
    const contentEl = layoutEl.querySelector(
      `.${style['admin-layout_body-content']}`
    );
    const asideWhiteList = $globalOptions?.asideWhiteList || [];
    const inIframeAsideShow = !!asideWhiteList
      .map((str) => new RegExp(str))
      .find((reg) => reg.test(window.location.pathname));
    if ($globalOptions.hideNav || (isInIframe && (!asideWhiteList.length || !inIframeAsideShow))) {
      sideNavEl.style.display = 'none';
      sideNavEl.style.width = '0px';
      contentEl.style.left = '0px';
    } else {
      sideNavEl.style.display = 'block';
      sideNavEl.style.width = '60px';
      sideNavWrapEl.style.width = '60px';
      contentEl.style.left = '60px';
      $globalApi.setAsideState && $globalApi.setAsideState(false);
    }
  }
}

function mobileMediaQueryListener(e) {
  const printMediaQueryList = window.matchMedia('print');
  if (!printMediaQueryList.matches && e.matches) {
    mediaQuery = 'mobile';
    navIsOpen = false;
    const sideNavEl = layoutEl.querySelector(
      `.${style['admin-layout_aside-nav']}`
    );
    const contentEl = layoutEl.querySelector(
      `.${style['admin-layout_body-content']}`
    );
    sideNavEl.style.display = 'none';
    contentEl.style.left = '0px';
    $globalApi.setAsideState && $globalApi.setAsideState(false);
  }
}

function inIframe() {
  return window.parent !== rawWindow;
}

// 系统信息
function showAppInfo(div) {
  let appName = document.createElement('span');
  appName.innerText = $globalApi.getAppInfo().appName;
  div
    .querySelector(`.${style['admin-layout_header-app-name']}`)
    .appendChild(appName);

  let userCenterTitle = document.createElement('span');
  userCenterTitle.innerHTML = `${$globalApi.getAppInfo().appName}-个人中心`;
  div
    .querySelector(`.${style['user-center_mobile-panel-header-title']}`)
    .appendChild(userCenterTitle);
}

// 环境标识
function showEnvBadge(layout) {
  let envMap = {
    development: '开发环境',
    test: '测试环境',
  };
  let RUNTIME_ENV = process.env.RUNTIME_ENV;
  let tips = '';
  if (envMap[RUNTIME_ENV]) {
    tips = envMap[RUNTIME_ENV];
  }
  if (tips && layout) {
    let badgeEl = layout.querySelector(`.${style['env-badge']}`);
    badgeEl.innerText = tips;
    badgeEl.style.display = 'inline';
  }
}

function showHeaderSwitch(layout, hideSwitch) {
  let headerSwitch = layout.querySelector('#admin-layout_header-switch');
  headerSwitch.addEventListener('click', switchHandler);
  if (hideSwitch) {
    headerSwitch.style.display = 'none';
  } else {
    headerSwitch.style.display = 'flex';
  }
}

function switchHandler() {
  const legacyLayoutHost = $globalOptions.legacyLayoutHost;
  document.cookie = 'newLayout=0; expires=1648199379736; path=/';
  if ($globalOptions.appIndexCid) {
    lx.moduleClick(
      "b_kuailv_changelayout_mc",
      {
        custom: {
          change_type: "OLD",
        },
      },
      {
        cid: $globalOptions.appIndexCid,
      }
    );
  }
  if (legacyLayoutHost) {
    const reg = /^http(s)?:\/\/(.*?)\//;
    const url = location.href;
    const newUrl = url.replace(reg, `${location.protocol}//${legacyLayoutHost}/`);
    window.open(newUrl, '_self');
  } else {
    location.reload();
  }
}

function showUserProfile(layout, target, hideProfile) {
  if (hideProfile) {
    return;
  } else {
    userProfile = new UserProfile(layout, target, $globalApi, $globalOptions);
  }
}

function bindEventListener(layout) {
  let userCenter = layout.querySelector('#user-center_mobile-img');
  userCenter.addEventListener('click', showUserCenterPanel);

  let closeUserCenter = layout.querySelector(
    `.${style['user-center_mobile-panel-operate']}`
  );
  closeUserCenter.addEventListener('click', hideUserCenterPanel);

  let headerNavTrigger = layout.querySelector(
    '#admin-layout_header-nav-trigger_mobile-img'
  );
  headerNavTrigger.addEventListener('click', showNavHandler);

  let closeNavTrigger = layout.querySelector(
    `.${style['admin-layout_header-nav-trigger_mobile-operate']}`
  );
  closeNavTrigger.addEventListener('click', hideNavHandler);

  $globalApi.onAsideStateChange((isOpen) => {
    navIsOpen = isOpen;
    setAsideNavState(layout);
  });
}

function showNavHandler() {
  let headerNavTrigger = layoutEl.querySelector(
    '#admin-layout_header-nav-trigger_mobile-img'
  );
  // 隐藏展开菜单图标
  headerNavTrigger.style.display = 'none';
  // 展示收起菜单图标
  let hideNavTrigger = layoutEl.querySelector(
    `.${style['admin-layout_header-nav-trigger_mobile-operate']}`
  );
  hideNavTrigger.style.display = 'block';
  // 与基座进行交互
  $globalApi.setAsideState && $globalApi.setAsideState(true);
  // 修改容器和侧边栏的定位
  const sideNavEl = layoutEl.querySelector(
    `.${style['admin-layout_aside-nav']}`
  );
  const sideNavWrapEl = layoutEl.querySelector(
    `.${style['admin-layout_aside-nav-wrap']}`
  );
  const contentEl = layoutEl.querySelector(
    `.${style['admin-layout_body-content']}`
  );
  if ($globalOptions.asideModel === 'panel') {
    sideNavEl.style.width = '132px';
    sideNavWrapEl.style.width = '132px';
    contentEl.style.left = '132px';
  } else {
    sideNavEl.style.width = '200px';
    sideNavWrapEl.style.width = '200px';
    contentEl.style.left = '200px';
  }
}

function hideNavHandler() {
  let headerNavTrigger = layoutEl.querySelector(
    '#admin-layout_header-nav-trigger_mobile-img'
  );
  headerNavTrigger.style.display = 'flex';
  let hideNavTrigger = layoutEl.querySelector(
    `.${style['admin-layout_header-nav-trigger_mobile-operate']}`
  );
  hideNavTrigger.style.display = 'none';
  // 与基座进行交互
  $globalApi.setAsideState && $globalApi.setAsideState(false);
  // 修改容器的定位
  const sideNavEl = layoutEl.querySelector(
    `.${style['admin-layout_aside-nav']}`
  );
  const sideNavWrapEl = layoutEl.querySelector(
    `.${style['admin-layout_aside-nav-wrap']}`
  );
  const contentEl = layoutEl.querySelector(
    `.${style['admin-layout_body-content']}`
  );
  sideNavEl.style.display = 'none';
  sideNavEl.style.width = '0px';
  sideNavWrapEl.style.width = '0px';
  contentEl.style.left = '0px';
}

function showUserCenterPanel() {
  let userCenterPanel = layoutEl.querySelector(
    `.${style['user-center_mobile-panel']}`
  );
  userCenterPanel.style.display = 'block';
}

function hideUserCenterPanel() {
  let userCenterPanel = layoutEl.querySelector(
    `.${style['user-center_mobile-panel']}`
  );
  userCenterPanel.style.display = 'none';
}

function initGlobalNotification(globalNotification) {
  // 内嵌iframe中或配置了隐藏时不需要展示
  const headerWhiteList = $globalOptions?.headerWhiteList || [];
  if ($globalOptions.hideHeader || (isInIframe && !headerWhiteList.length)) {
    let notificationEl = layoutEl.querySelector(
      `.${style['admin-layout_app-container_notification']}`
    );
    let containerEl = layoutEl.querySelector('#admin-layout_app-container');
    notificationEl.style.display = 'none';
    containerEl.classList.remove(
      style['admin-layout_app-container-with-notification']
    );
  } else {
    if (globalNotification) {
      setGlobalNotification(globalNotification);
    }
    unwatchPageTipsInfo = $globalApi.watchPageTipsInfo((pageTips) => {
      setGlobalNotification(pageTips);
    });
  }
}

function setGlobalNotification(notification) {
  let notificationEl = layoutEl.querySelector(
    `.${style['admin-layout_app-container_notification']}`
  );
  let containerEl = layoutEl.querySelector('#admin-layout_app-container');
  if (!notification) {
    notificationEl.style.display = 'none';
    containerEl.classList.remove(
      style['admin-layout_app-container-with-notification']
    );
  } else {
    notificationEl.innerHTML = '';
    notificationEl.style.display = 'block';
    let notificationContentEl = document.createElement('span');
    notificationContentEl.classList.add(style['animate']);
    notificationContentEl.innerText = notification;
    notificationEl.appendChild(notificationContentEl);
    containerEl.classList.add(
      style['admin-layout_app-container-with-notification']
    );
    if ($globalOptions.globalNotificationCloseable) {
      let closeNotificationContainer = document.createElement('span');
      closeNotificationContainer.id = 'notification-close-icon';
      closeNotificationContainer.style.position = 'absolute';
      closeNotificationContainer.style.right = '0';
      closeNotificationContainer.style.paddingRight = '10px';
      closeNotificationContainer.style.paddingLeft = '5px';
      closeNotificationContainer.style.background = '#fff9e0';
      let closeNotificationIcon = document.createElement('img');
      closeNotificationIcon.src=require('./assets/close-icon.svg');
      closeNotificationIcon.classList.add(style['notification-close-icon']);
      closeNotificationContainer.appendChild(closeNotificationIcon);
      notificationEl.appendChild(closeNotificationContainer);
      closeNotificationContainer.addEventListener('click', closeNotification);
    }
  }
}

function closeNotification() {
  let containerEl = layoutEl.querySelector('#admin-layout_app-container');
  containerEl.classList.remove(
    style['admin-layout_app-container-with-notification']
  );
  let notificationContentEl = layoutEl.querySelector(`.${style['admin-layout_app-container_notification']}`);
  notificationContentEl.style.display = 'none';
}

function setHeaderZIndex(layoutZIndex) {
  if (layoutZIndex) {
    const headerEl = layoutEl.querySelector(`.${style['admin-layout_header']}`);
    headerEl.style.zIndex = layoutZIndex;
  }
}

// 设置头部的显示和隐藏，并在隐藏时设置微应用容器的定位
function setHeaderState(layout, showHeader) {
  const headerWhiteList = $globalOptions?.headerWhiteList || [];
  const inIframeHeaderShow = !!headerWhiteList
    .map((str) => new RegExp(str))
    .find((reg) => reg.test(window.location.pathname));
  const headerEl = layout.querySelector(`.${style['admin-layout_header']}`);
  const contentEl = layout.querySelector(
    `.${style['admin-layout_body-content']}`
  );
  if (
    showHeader &&
    !$globalOptions.hideHeader &&
    (!isInIframe || (isInIframe && inIframeHeaderShow))
  ) {
    headerEl.style.display = 'flex';
  } else {
    headerEl.style.display = 'none';
    contentEl.style.top = 0;
    setGlobalNotification();
  }
}

// 设置侧边栏的显示和隐藏，并在隐藏时设置微应用容器的定位
function setAsideNavState(layout) {
  const showAside = navIsOpen;
  const sideNavEl = layout.querySelector(`.${style['admin-layout_aside-nav']}`);
  const sideNavWrapEl = layout.querySelector(
    `.${style['admin-layout_aside-nav-wrap']}`
  );
  const contentEl = layout.querySelector(
    `.${style['admin-layout_body-content']}`
  );
  const asideWhiteList = $globalOptions?.asideWhiteList || [];
  const inIframeAsideShow = !!asideWhiteList
    .map((str) => new RegExp(str))
    .find((reg) => reg.test(window.location.pathname));
  if ($globalOptions.hideNav || (isInIframe && (!asideWhiteList.length || !inIframeAsideShow))) {
    sideNavEl.style.display = 'none';
    contentEl.style.width = '100%';
    contentEl.style.left = '0px';
  } else {
    if (showAside && (!isInIframe || (isInIframe && inIframeAsideShow))) {
      sideNavEl.style.display = 'block';
      if (mediaQuery === 'pc' || mediaQuery === 'pad') {
        sideNavEl.style.width = '200px';
        sideNavWrapEl.style.width = '200px';
        contentEl.style.left = '200px';
      }
      if (mediaQuery === 'mobile') {
        if ($globalOptions.asideModel === 'panel') {
          sideNavEl.style.width = '132px';
          sideNavWrapEl.style.width = '132px';
          contentEl.style.left = '132px';
        } else {
          sideNavEl.style.width = '200px';
          sideNavWrapEl.style.width = '200px';
          contentEl.style.left = '200px';
        }
      }
    } else {
      if (mediaQuery === 'pad') {
        sideNavEl.style.width = '60px';
        sideNavWrapEl.style.width = '60px';
        contentEl.style.left = '60px';
      } else if (mediaQuery === 'mobile') {
        sideNavEl.style.display = 'none';
        sideNavEl.style.width = '0px';
        sideNavWrapEl.style.width = '0px';
        contentEl.style.left = '0px';
        // 处理移动端菜单展开收起的图标问题
        hideNavHandler();
      } else {
        sideNavEl.style.width = '0px';
        sideNavWrapEl.style.width = '0px';
        contentEl.style.left = '0px';
      }
    }
  }
}

export function mount(target, api, options) {
  render(target, api, options);
}

if (window._POWERED_BY_CLI_SERVICE_) {
  render(
    document.getElementById('app'),
    {
      getAppInfo: () => ({
        appName: '快驴合作商',
      }),
      getUserInfo: () => ({
        name: '张三',
      }),
      getExtraUserInfo: () => ({
        realName: '李四',
        // realId: 23333,
        realLogin: 'lisi01',
      }),
      watchPageTipsInfo: () => {},
      watchUserInfo: () => {},
      watchExtraUserInfo: () => {},
      logout: () => {
        location.href = '/rac/upm/logout';
      },
      onAsideStateChange: () => {},
      getAppTheme: () => ({
        themeHeaderFontColor: '#fff',
        themeBackgroundColor: '#186cf7',
        themeAsideBackgroundColor: '#fff',
        themeHoverBackgroundColor: '#eef6ff',
      }),
    },
    {
      hideNav: false,
      hideHeader: false,
      // hideProfile: true,
      // hideSwitch: true,
      globalNotification: '防疫通知：戴口罩，测体温，勤洗手，防疫消杀落到实处，保障生产安全，众志成城，战疫必胜！防疫通知：戴口罩，测体温，勤洗手，',
      asideModel: 'panel',
      legacyLayoutHost: 'lizhen45-fawbb-sl-kldata.bb.dev.sankuai.com',
      headerAppName: 'data',
      layoutZIndex: 131,
      globalNotificationCloseable: true
    }
  );
}

export async function unmount() {
  if (!layoutEl) {
    return;
  }

  let headerSwitch = layoutEl.querySelector('#admin-layout_header-switch');
  headerSwitch.removeEventListener('click', switchHandler);

  let userCenter = layoutEl.querySelector('#user-center_mobile-img');
  userCenter.removeEventListener('click', showUserCenterPanel);

  let closeUserCenter = layoutEl.querySelector(
    `.${style['user-center_mobile-panel-operate']}`
  );
  closeUserCenter.removeEventListener('click', hideUserCenterPanel);

  let closeNotificationIcon = layoutEl.querySelector('#notification-close-icon');
  if (closeNotificationIcon && closeNotificationIcon.removeListener) {
    closeNotificationIcon.removeListener('click', closeNotification);
  }

  unwatchPageTipsInfo && unwatchPageTipsInfo();

  pcMediaQueryList.removeListener(pcMediaQueryListener);
  padMediaQueryList.removeListener(padMediaQueryListener);
  mobileMediaQueryList.removeListener(mobileMediaQueryListener);

  userProfile.destroy();
  layoutEl.remove();
}
