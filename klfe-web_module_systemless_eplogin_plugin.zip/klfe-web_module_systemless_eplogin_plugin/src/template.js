import style from './style.module.css';
import logo from './assets/logo.png';
import back from './assets/back.svg';
import closeIcon from './assets/closed.svg';
import userCenter from './assets/user-center.svg';
import navTrigger from './assets/nav-trigger.svg';

export const template = (position) => `<div class="${style['admin-layout']} ${style[position + '-admin-layout']}">
  <div class="${style['hide-print']} ${style['admin-layout_header']}">
    <a href="/">
      <img src="${logo}" alt="快驴进货" class="${style['admin-layout_header-logo']}" />
    </a>
    <div class="${style['admin-layout_divider']}"></div>
    <a class="${style['admin-layout_header-app-name']}" href="/">
      <span class="${style['env-badge']}"></span>
    </a>
    <div class="${style['admin-layout_header-left']}">
      <!-- 切仓插槽 -->
      <div class="${style['admin-layout_header-warehouse']}" id="admin-layout_header-warehouse"></div>
      <!-- 横向导航插槽 -->
      <div class="${style['admin-layout_header-nav']}" id="admin-layout_header-nav"></div>
      <!-- 返回旧版 -->
      <div class="${style['admin-layout_header-switch']}" id="admin-layout_header-switch">
          <div class="${style['admin-layout_header-switch-container']}">
              <img class="${style['admin-layout_header-switch-img']}" src="${back}" alt="返回" />
              <span class="${style['admin-layout_header-switch-text']}">
                  返回旧版
              </span>
          </div>
      </div>
    </div>
    <div class="${style['admin-layout_header-right']}">
      <!-- 常驻功能插槽 -->
      <div class="${style['admin-layout_header-links']}" id="admin-layout_header-links"></div>
      <!-- 消息中心插槽 -->
      <div class="${style['admin-layout_header-notify']}" id="admin-layout_header-notify"></div>
      <!-- 头部用户信息 -->
      <div class="${style['admin-layout_header-user-profile']}" id="admin-layout_header-user-profile"></div>
    </div>
    <div class="${style['admin-layout_header_mobile']}">
       <img id="user-center_mobile-img" class="${style['user-center_mobile-img']} ${style['user-center_mobile-icon']}" src="${userCenter}" alt="个人中心" />
       <img id="admin-layout_header-nav-trigger_mobile-img" src="${navTrigger}" class="${style['user-center_mobile-icon']}" alt="展开菜单" />
       <img class="${style['admin-layout_header-nav-trigger_mobile-operate']} ${style['user-center_mobile-icon']}" src="${closeIcon}" alt="收起菜单" />
    </div>
  </div>
  <!-- 个人中心 -->
  <div class="${style['hide-print']}  ${style['user-center_mobile-panel']}">
    <div class="${style['user-center_mobile-panel_overlay']}"></div>
    <div class="${style['user-center_mobile-panel_content']}">
      <div>
        <div class="${style['user-center_mobile-panel-header']}">
          <div class="${style['user-center_mobile-panel-header-title']}"></div>
          <div class="${style['user-center_mobile-panel-operate']}"><img class="${style['user-center_mobile-panel-operate-icon']}" src="${closeIcon}" alt="关闭个人中心" /></div>
        </div>
        <div class="${style['user-profile-mobile']}">
            <div class="${style['user-profile-mobile-item']}">
                <span class="${style['user-profile-mobile-text']}"></span>
                <span class="${style['user-profile-mobile-extra-tag-text']}">模拟</span>
            </div>
            <div class="${style['user-profile-mobile-item']}">
                <div class="${style['user-profile-mobile_operate']}" id="mobile-logout"></div>
            </div>
        </div>
      </div>
      <div class="${style['user-center-slots']}">
          <!-- 切仓插槽 -->
          <div id="admin-layout_header-warehouse-mobile"></div>
          <!-- 头部右侧插槽 -->
          <div id="admin-layout_header-links-mobile"></div>
          <div
            class="${style['logan-report-mobile']}"
            id="logan-report-mobile"
          >
            <div class="${style['logan-report-mobile_title']}">问题反馈</div>
            <div class="${style['logan-report-mobile_text']}">
              <span>问题反馈</span>
              <span
                class="${style['logan-report-mobile_img']}"
              ></span>
            </div>
          </div>
      </div>
    </div>
  </div>
  
  <div class="${style['admin-layout_body']} ${style[position + '-admin-layout_body']}">
    <div class="${style['admin-layout_aside-nav']} ${style['hide-print']}">
      <div class="${style['admin-layout_aside-nav-wrap']}">
        <!-- 左侧菜单栏   -->
        <div id="admin-layout_aside-nav-container"></div>
      </div>
    </div>
    <div class="${style['admin-layout_body-content']} ${style[position + '-admin-layout_body-content']}">
      <!-- 全局通知 -->
      <div class="${style['admin-layout_app-container_notification']} ${style['hide-print']}"></div>
      <!-- 微应用容器  -->
      <div id="admin-layout_app-container" class="${style['admin-layout_app-container']}"></div>
    </div>
  </div>
</div>`
