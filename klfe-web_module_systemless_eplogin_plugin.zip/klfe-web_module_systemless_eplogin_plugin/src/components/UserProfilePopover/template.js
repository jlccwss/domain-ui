import style from './style.module.css';
export const template = `<div class="${style['user-profile-popover']}">
  <ul class="${style['user-profile-popover-real']}">
    <li class="${style['user-profile-logan-report']}" id="logan-report">问题反馈</li>
    <li class="${style['user-profile-logout']}" id="logout">退出登录</li>
  </ul>
  <div class="${style['user-profile-popover-extra']}">
    <div class="${style['user-profile-popover-extra_title']}"></div>
    <div class="${style['user-profile-popover-extra_content']}"></div>
    <div class="${style['user-profile-popover-extra_operate']}">
      <button type="button" class="${style['confirm-btn']}" id="extra-logout">
        切换自身账号
      </button>
    </div>
  </div>
</div>`