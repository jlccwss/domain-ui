import style from './style.module.css';
import userProfileStyle from '../UserProfile/style.module.css';
import { template } from './template.js';
import { Logan, hasLogan } from '@kl/web-runtime';

export default class UserProfilePopover {
  constructor(layout, target, api) {
    this.layout = layout;
    this.target = target;
    this.popover = null;
    this.api = api;
    this.mount();
  }
  mount() {
    let div = document.createElement('div');
    div.innerHTML = template;

    this.popover = div.querySelector(`.${style['user-profile-popover']}`);
    this.target.appendChild(this.popover);

    this.bindEventListener();

    if (hasLogan) { // 如果应用容器引入了Logan
      this.mountLogan();
    }

    if ('ontouchstart' in window) {
      this.eventOnMobile();
    } else {
      this.eventOnPc();
    }
  }
  // 给退出登录&切换自身账号绑定点击事件
  bindEventListener() {
    const extraUserInfo = this.api.getExtraUserInfo();
    // 判断是否是模拟登录
    if (extraUserInfo && extraUserInfo.realId) {
      this.popover.querySelector('#extra-logout').addEventListener('click', () => {
        this.logout();
      });
    }
    this.popover.querySelector('#logout').addEventListener('click', () => {
      this.logout();
    });
  }
  // 退出登录&切换自身账号
  logout() {
    if (this.api && typeof this.api.logout === 'function') {
      this.api.logout();
    } else {
      location.href = '/rac/upm/logout';
    }
  }
  mountLogan() {
    const isMobile = this.isMobileMedia();
    if (isMobile) {
      let mobileReportTrigger = this.layout.querySelector('#logan-report-mobile');
      mobileReportTrigger.style.display = 'block';
      Logan.config({
        reportTrigger: mobileReportTrigger
      });
    } else {
      let reportTrigger = this.popover.querySelector('#logan-report');
      reportTrigger.style.display = 'list-item';
      Logan.config({
        reportTrigger
      });
    }
  }
  eventOnMobile() {
    this.target.addEventListener('click', this.toggle.bind(this));
  }
  eventOnPc() {
    this.target.addEventListener('mouseenter', this.show.bind(this));
    this.target.addEventListener('mouseleave', this.mouseLeave.bind(this));
    this.popover.addEventListener('mouseenter', this.mouseEnterTooltip.bind(this));
    this.popover.addEventListener('mouseleave', this.mouseLeaveTooltip.bind(this));
  }
  mouseEnterTooltip() {
    this.mouseInTooltip = true;
    if (this.leaveTimer) {
      clearTimeout(this.leaveTimer);
    }
  }
  mouseLeaveTooltip() {
    this.mouseInTooltip = false;
  }
  mouseLeave() {
    if (this.leaveTimer) {
      clearTimeout(this.leaveTimer);
    }
    this.leaveTimer = setTimeout(() => {
      if (!this.mouseInTooltip) {
        this.hide();
      }
    }, 100);
  }

  toggle() {
    if (this.isShow) {
      this.hide();
    } else {
      this.show();
    }
  }
  show() {
    if (this.popover) {
      this.popover.style.display = 'block';
      let arrowEl = this.target.querySelector(`.${userProfileStyle['user-profile-arrow']}`);
      arrowEl.style.transform = "rotate(180deg)";
    }
    this.isShow = true;
  }
  hide() {
    if (this.popover) {
      this.popover.style.display = 'none';
      let arrowEl = this.target.querySelector(`.${userProfileStyle['user-profile-arrow']}`);
      arrowEl.style.transform = "none";
    }
    this.isShow = false;
  }
  // 外部调用，更新模拟登录时的信息
  setUserName(userInfo = {}, extraUserInfo = {}) {
    if (extraUserInfo && extraUserInfo.realId) {
      let popover = this.popover.querySelector(`.${style['user-profile-popover-real']}`);
      popover.style.display = 'none';
      let extraPopover = this.popover.querySelector(`.${style['user-profile-popover-extra']}`);
      let title = extraPopover.querySelector(`.${style['user-profile-popover-extra_title']}`);
      title.innerText = userInfo.name;
      let content = extraPopover.querySelector(`.${style['user-profile-popover-extra_content']}`);
      content.innerText = `您正在使用${extraUserInfo.realName}(${extraUserInfo.realLogin})模拟登录`;
    } else {
      let popover = this.popover.querySelector(`.${style['user-profile-popover-real']}`);
      popover.style.display = 'block';
      let extraPopover = this.popover.querySelector(`.${style['user-profile-popover-extra']}`);
      extraPopover.style.display = 'none';
    }
  }

  // 获取屏幕尺寸
  isMobileMedia() {
    if (window && window.matchMedia('(max-width: 767px)').matches) {
      return true;
    }
    return false;
  }
}
