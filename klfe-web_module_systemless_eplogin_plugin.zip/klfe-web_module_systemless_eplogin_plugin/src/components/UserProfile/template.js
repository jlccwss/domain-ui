import style from './style.module.css';
export const template = `<div class="${style['user-profile-wrap']}">
  <div class="${style['user-profile-divider']}"></div>
  <div class="${style['user-profile-extra-tag']}">模拟</div>
  <div class="${style['user-profile']}">
    <span class="${style['user-profile-text']}"></span>
    <span class="${style['user-profile-arrow']}"></span>
  </div>
</div>`;
