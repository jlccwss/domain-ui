import style from './style.module.css';
import layoutStyle from '../../style.module.css';
import UserProfilePopover from '../UserProfilePopover';
import { template } from './template.js';

let unwatchUserInfo = null;
let unwatchExtraUserInfo = null;

export default class UserProfile {
  constructor(layout, target, api, options) {
    this.layout = layout;
    this.target = target;
    this.api = api;
    this.options = options;
    this.mount();
  }
  mount() {
    let div = document.createElement('div');
    div.innerHTML = template;
    this.target.appendChild(div);

    try {
      const userInfo = this.api.getUserInfo();
      const extraUserInfo = this.api.getExtraUserInfo();
      this.setUserName(userInfo);
      this.setExtraTag(div, extraUserInfo);
      this.setMobileUserProfile(userInfo, extraUserInfo);
      
      const popperTarget = this.target.querySelector(`.${style['user-profile']}`);
      let popper = new UserProfilePopover(this.layout, popperTarget, this.api);
      popper.setUserName(this.api.getUserInfo(), this.api.getExtraUserInfo());

      unwatchUserInfo = this.api.watchUserInfo((userInfoData) => {
        this.setUserName(userInfoData);
        this.setExtraTag(div);
        this.setMobileUserProfile(userInfoData);
        popper.setUserName(userInfoData, this.api.getExtraUserInfo());
      });
      unwatchExtraUserInfo = this.api.watchExtraUserInfo((extraUserInfoData) => {
        this.setExtraTag(div, extraUserInfoData);
        popper.setUserName(this.api.getUserInfo(), extraUserInfoData);
      });
    } catch(e) {
      console.error(e);
    }
  }
  // 更新当前用户信息
  setUserName(userInfo= {}) {
    let text = this.target.querySelector(`.${style['user-profile-text']}`);
    let displayStr = userInfo?.name;
    text.innerText = displayStr || '你好';
  }
  // 更新模拟登录标识
  setExtraTag(div, extraUserInfo) {
    let extraTag = div.querySelector(`.${style['user-profile-extra-tag']}`);
    if (extraUserInfo && extraUserInfo.realId) {
      extraTag.style.display = 'block';
    } else {
      extraTag.style.display = 'none';
    }
  }
  // 更新移动端的展示信息
  setMobileUserProfile(userInfo = {}, extraUserInfo = {}) {
    let mobileUserProfile = this.layout.querySelector(`.${layoutStyle['user-profile-mobile']}`);
    let text = mobileUserProfile.querySelector(`.${layoutStyle['user-profile-mobile-text']}`);
    let extraTag = this.layout.querySelector(`.${layoutStyle['user-profile-mobile-extra-tag-text']}`);
    let displayStr = userInfo?.name;
    text.innerText = displayStr || '你好';
    const logoutEl = mobileUserProfile.querySelector('#mobile-logout');
    if (extraUserInfo && extraUserInfo.realId) {
      extraTag.style.display = 'inline-block';
      logoutEl.innerText = '切换自身登录';
    } else {
      extraTag.style.display = 'none';
      logoutEl.innerText = '退出登录';
    }
    logoutEl.addEventListener('click', this.logoutCallback);
  }
  logoutCallback() {
    if (this.api && typeof this.api.logout === 'function') {
      this.api.logout();
    } else {
      location.href = '/rac/upm/logout';
    }
  }
  destroy() {
    const mobileUserProfile = this.layout.querySelector(`.${layoutStyle['user-profile-mobile']}`);
    const logoutEl = mobileUserProfile.querySelector('#mobile-logout');
    logoutEl.removeEventListener('click', this.logoutCallback);
    unwatchUserInfo();
    unwatchExtraUserInfo();
  }
}
