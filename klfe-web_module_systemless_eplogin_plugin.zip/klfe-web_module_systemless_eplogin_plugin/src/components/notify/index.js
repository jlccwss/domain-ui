import template from './template.html';
import styleContent from './style.scss';
import { name as packageName } from '../../../package.json';

const styleId = `${packageName}-style`;
export function notify(options = {}) {
  let {
    duration,
    content,
    title
  } = options;
  let div = document.createElement('div');
  div.innerHTML = template;
  let notifyEl = div.querySelector('.login-notify');
  if (title) {
    notifyEl.querySelector('.login-notify-title').innerText = title;
  }
  if (content) {
    notifyEl.querySelector('.login-notify-content-inner').innerText = content;
  }
  let closeIcon = notifyEl.querySelector('.login-notify-close');
  closeIcon.addEventListener('click', closeNotify);
  document.body.appendChild(notifyEl);
  appendStyle();
  if (duration) {
    notifyEl.timer = setTimeout(() => {
      notifyEl && notifyEl.remove();
      removeStyle();
      closeIcon.removeEventListener('click', closeNotify);
    }, duration);
  }
}

function appendStyle() {
  let styleEl = document.getElementById(styleId);
  if (styleEl) {
    return;
  }
  styleEl = document.createElement('style');
  styleEl.innerHTML = styleContent;
  styleEl.id = styleId;
  document.body.appendChild(styleEl);
}

function removeStyle() {
  let styleEl = document.getElementById(styleId);
  styleEl && styleEl.remove();
}

function closeNotify(evt) {
  let target = evt.target;
  let notifyEl = target.closest('.login-notify');
  if (notifyEl) {
    notifyEl.remove();
    target.removeEventListener('click', closeNotify);
    if (notifyEl.timer) {
      clearTimeout(notifyEl.timer);
    }
    removeStyle();
  }
}

