/**
 * build: 主要目的是修改项目构建系统(例如 glup，webpack，rollup 的配置等)的提交
 * ci: 主要目的是修改项目继续集成流程(例如 Travis，Jenkins，GitLab CI，Circle等)的提交
 * docs: 文档更新
 * feat: 新增功能
 * fix: bug 修复
 * style: 不影响程序逻辑的代码修改(修改空白字符，补全缺失的分号等)
 * refactor: 重构代码(既没有新增功能，也没有修复 bug)
 * perf: 性能优化
 * test: 新增测试用例或是更新现有测试
 * revert: 回滚某个更早之前的提交
 * chore: 不属于以上类型的其他类型(日常事务)
 * util: 新增项目工具
 * merge: 分支合并
 */
/**
 * 提交格式（注意冒号后面有空格）
 * <type>(<scope>): <subject>
 * eg: feat(commitlintrc): 修改commitlintrc规则
 */
 module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'type-enum': [
      2,
      'always',
      [
        'build', // 主要目的是修改项目构建系统(例如 glup，webpack，rollup 的配置等)的提交
        'ci', // 主要目的是修改项目继续集成流程(例如 Travis，Jenkins，GitLab CI，Circle等)的提交
        'docs', // 文档更新
        'feat', // 新增功能
        'fix', // bug 修复
        'style', // 不影响程序逻辑的代码修改(修改空白字符，补全缺失的分号等)
        'refactor', // 重构代码(既没有新增功能，也没有修复 bug)
        'perf', // 性能优化
        'test', // 新增测试用例或是更新现有测试
        'revert', // 回滚某个更早之前的提交
        'chore', // 不属于以上类型的其他类型(日常事务)
        'util', // 新增项目工具
        'merge', //分支合并
      ],
    ],
    'header-max-length': [2, 'always', 72], // 简述限制72字符长度
    'scope-empty': [2, 'never'], // scope不为空
    'scope-case': [2, 'always', 'lower-case'], // scope小写
    'subject-case': [2, 'never'],
    'subject-empty': [2, 'never'], // subject不为空
    'subject-full-stop': [2, 'never', '.'], // subject结尾不加'.'
    'type-case': [2, 'always', 'lower-case'], // type小写
    'type-empty': [2, 'never'], // type不为空
  },
};