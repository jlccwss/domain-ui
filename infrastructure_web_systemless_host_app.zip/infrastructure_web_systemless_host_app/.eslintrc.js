module.exports = {
  root: true,
  extends: ["@kl/recommended"]
}
