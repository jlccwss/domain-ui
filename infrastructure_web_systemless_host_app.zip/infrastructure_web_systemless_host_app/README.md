# systemless-host-app 

无系统框架基座应用

## CLI 用法
命令行使用文档为维护方便，请参考学城链接：[https://km.sankuai.com/page/860284871](https://km.sankuai.com/page/860284871#id-%E6%9C%AC%E5%9C%B0%E5%BC%80%E5%8F%91%E8%B0%83%E8%AF%95)