import { AppConfig, MicroApp } from '@/types';
import { createElement } from './dom';
import isEqual from 'lodash.isequal';
import cloneDeep from 'lodash.clonedeep';
import container from '../appContainer';
import { SESSION_STORAGE_KEY } from '@/constants';
import { request } from './request';
import { md5 } from './md5';

interface CheckerOptions {
  configFetcher: () => Promise<AppConfig | null>;
  initialAppConfig: AppConfig | null;
  appContainer: typeof container;
}
const POPUP_NOTICE_ID = 'host-app-update-checker-notice';

export async function startUpdateChecker(options: CheckerOptions) {
  const { initialAppConfig, appContainer } = options;
  const lastAppConfig = cloneDeep(initialAppConfig);
  let entryUpdate = false;
  let timer: number;

  /**
   * 微应用是否有更新
   * @param appConfig 应用配置
   */
  async function microAppHasUpdated(appConfig: AppConfig): Promise<boolean> {
    const cloneConfig = cloneDeep(appConfig);
    // 如果应用配置有差异，触发更新
    if (lastAppConfig && !isEqual(lastAppConfig, cloneConfig)) {
      return true;
    }
    const lastApp = appContainer.lastApp;
    if (!lastApp) {
      return false;
    }
    // 拼接所有微应用，包括404和主页
    const apps: MicroApp[] = appContainer.getAllApps();

    const currentApp = apps.find((app) => app.name === lastApp?.name);
    if (!currentApp) {
      return true;
    }
    // 如果应用配置不一样，则认为微应用已更新
    if (!isEqual(lastApp.entry, currentApp.entry)) {
      return true;
    }
    // TODO: 如果是iframe内嵌，无法判断更新?
    if (currentApp.iframe) {
      return false;
    }
    const storageEdition = sessionStorage.getItem(SESSION_STORAGE_KEY);

    const { data } = await request({
      url: lastApp.entry,
    });
    if (!storageEdition) {
      sessionStorage.setItem(SESSION_STORAGE_KEY, md5(data));
      return false;
    }
    const newMd5 = md5(data);
    const hasUpdate = storageEdition !== newMd5;
    if (hasUpdate) {
      sessionStorage.setItem(SESSION_STORAGE_KEY, newMd5);
      entryUpdate = true;
    }
    return hasUpdate;
  }

  // 切换APP的时候，清空sessionStorage
  appContainer.onAppChange(() => {
    sessionStorage.removeItem(SESSION_STORAGE_KEY);
    // 如果是微应用的入口文件更新，切换微应用之后就会自动更新，则隐藏提示，重新启动轮训
    // 否则表示配置文件有更新，切换微应用也不能更新应用，则保持不动
    if (entryUpdate) {
      hidePopupNotice();
      clearTimeout(timer);
      check();
    }
  });

  check();
  async function check() {
    let updated = false;
    const config = await options.configFetcher();
    if (config) {
      updated = await microAppHasUpdated(config);
      if (updated) {
        showPopupNotice();
        clearTimeout(timer);
        return;
      }
    }
    timer = setTimeout(check, 5 * 60 * 1000);
  }
}

function hidePopupNotice() {
  const noticeElement = document.getElementById(POPUP_NOTICE_ID);
  noticeElement?.remove();
}
function showPopupNotice() {
  const noticeElement = createElement(
    'div',
    {
      id: POPUP_NOTICE_ID,
      class: 'host-app-update-checker-notice',
      onclick: 'window.location.reload(true)',
    },
    [
      createElement('img', {
        class: 'host-app-update-checker-notice__icon',
        src:
          'http://p0.meituan.net/scarlett/60e9404debdacd709f42dfa9b9562791893.png',
        width: '16',
        height: '16',
      }),
      createElement(
        'span',
        {
          class: 'host-app-update-checker-notice__content',
        },
        ['检测到新版本，点我刷新页面']
      ),
    ]
  );
  if (!document.getElementById(POPUP_NOTICE_ID) && noticeElement) {
    document.body.appendChild(noticeElement);
  }
}
