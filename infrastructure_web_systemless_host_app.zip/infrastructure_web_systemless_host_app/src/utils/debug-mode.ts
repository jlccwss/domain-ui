// localStorage中设置debugMode为1，启动调试模式，加载单独的配置文件，用于线上验证

const key = 'host_app_debug_mode';

export function isDebugMode() {
  return localStorage.getItem(key) === '1';
}

export function closeDebugMode() {
  return localStorage.removeItem(key);
}
