import { createElement } from './dom';

const imgMap: any = {
  404: 'http://p0.meituan.net/scarlett/1de451c55ee0a9cb8622dcb468ec8e4c100765.png',
  common:
    'http://p0.meituan.net/scarlett/166edd32995340f9c35eb1d6f674203418969.png'
};

export function getErrorElement (code: number | string, message?: string) {
  return createElement(
    'div',
    {
      class: 'host-app__error-page'
    },
    [
      createElement('img', {
        width: '540',
        src: imgMap[code === 404 ? 404 : 'common'],
        alt: '系统异常'
      }),
      createElement(
        'div',
        {
          class: 'host-app__error-page-text-title'
        },
        code
      ),
      createElement(
        'div',
        {
          class: 'host-app__error-page-text-desc'
        },
        message || '系统异常，请检查配置是否正常'
      )
    ]
  );
}
