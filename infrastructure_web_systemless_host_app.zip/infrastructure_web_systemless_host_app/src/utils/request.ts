
interface Headers {
  [key: string]: string;
}

export interface RequestOptions {
  method?: string;
  baseUrl?: string;
  url: string;
  data?: any;
  withCredentials?: boolean;
  headers?: Headers;
}

interface Response {
  data: any;
  xhr: XMLHttpRequest;
}

export function request (
  _options: RequestOptions
): Promise<Response> {
  const methods = ['get', 'post', 'put', 'delete'];
  const options: RequestOptions = _options || {};
  options.baseUrl = options.baseUrl || '';
  options.method =
    options.method && methods.indexOf(options.method) !== -1
      ? options.method
      : 'get';
  if (options.url) {
    return xhrConnection(
      options.method,
      options.baseUrl + options.url,
      maybeData(options.data),
      options
    );
  } else {
    throw new Error('url is required');
  }
}
function maybeData (data: any) {
  return data || null;
}

function xhrConnection (
  type: string,
  url: string,
  data: any,
  options: RequestOptions
): Promise<Response> {
  const xhr = new XMLHttpRequest();
  const featuredUrl = getUrlWithData(url, data, type);
  xhr.open(type, featuredUrl, true);
  xhr.withCredentials = options.hasOwnProperty('withCredentials');
  setHeaders(xhr, options.headers);

  const promise = new Promise<Response>((resolve, reject) => {
    function handleReady () {
      if (xhr.readyState === xhr.DONE) {
        xhr.removeEventListener('readystatechange', handleReady, false);
        let result;
        try {
          result = JSON.parse(xhr.responseText);
        } catch (e) {
          result = xhr.responseText;
        }
        const response = {
          data: result,
          xhr
        };
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(response);
        } else {
          reject(response);
        }
      }
    }
    xhr.addEventListener('readystatechange', handleReady, false);
    xhr.send(isObject(data) ? JSON.stringify(data) : data);
  });
  return promise;
}

function getUrlWithData (url: string, data: any, type: string) {
  if (type.toLowerCase() !== 'get' || !data) {
    return url;
  }
  const dataAsQueryString = objectToQueryString(data);
  const queryStringSeparator = url.indexOf('?') > -1 ? '&' : '?';
  return url + queryStringSeparator + dataAsQueryString;
}

function setHeaders (xhr: XMLHttpRequest, headers: any) {
  headers = headers || {};
  Object.keys(headers).forEach(function (name) {
    headers[name] && xhr.setRequestHeader(name, headers[name]);
  });
}

function parseResponse (xhr: XMLHttpRequest): [any, XMLHttpRequest] {
  let result;
  try {
    result = JSON.parse(xhr.responseText);
  } catch (e) {
    result = xhr.responseText;
  }
  return [result, xhr];
}

function objectToQueryString (data: any): string {
  return isObject(data) ? getQueryString(data) : data;
}

function isObject (data: any) {
  return Object.prototype.toString.call(data) === '[object Object]';
}

function getQueryString (obj: any, prefix?: string): string {
  return Object.keys(obj)
    .map(function (key) {
      if (obj.hasOwnProperty(key) && undefined !== obj[key]) {
        const val = obj[key];
        key = prefix ? prefix + '[' + key + ']' : key;
        return val !== null && typeof val === 'object'
          ? getQueryString(val, key)
          : encode(key) + '=' + encode(val);
      }
    })
    .filter(Boolean)
    .join('&');
}

function encode (value: string) {
  return encodeURIComponent(value);
}
