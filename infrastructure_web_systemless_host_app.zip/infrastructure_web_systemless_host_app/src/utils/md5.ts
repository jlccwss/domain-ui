import jsMd5 from 'js-md5';

export function md5 (str: string): string {
  return jsMd5(str);
}
