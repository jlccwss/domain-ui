interface Attrs {
  [key: string]: string | boolean | number;
}
type ElChild = string | HTMLElement | number;
/**
 * 生成DOM节点
 * @param tagName DOM标签名称
 * @param attrs  属性键值对
 * @param children 内容
 */
export function createElement (
  tagName: string,
  attrs?: Attrs,
  children?: ElChild[] | ElChild
): HTMLElement {
  const el: HTMLElement = document.createElement(tagName);
  attrs = attrs || {};
  for (const key in attrs) {
    el.setAttribute(key, attrs[key].toString());
  }
  if (children) {
    const childrenArr: ElChild[] = [];
    childrenArr
      .concat(children)
      .filter(Boolean)
      .forEach((child: ElChild) => {
        if (child instanceof HTMLElement) {
          el.appendChild(child);
        } else if (typeof child === 'string') {
          el.appendChild(document.createTextNode(child));
        } else {
          el.appendChild(document.createTextNode(child.toString()));
        }
      });
  }
  return el;
}
