import { errorLog } from '@/utils/log';

const catchPromiseError = (promiseInstance: Promise<any>) => promiseInstance.catch(error => {
  errorLog('串行加载子应用异常', error);
});

export function createSerialQueue () {
  let serialId: symbol | null = null;
  let serialQueue: any[] = [];
  let serialDestroyed = false;

  const pushSerialQueue = async function (asyncFunction: Function) {
    if (serialDestroyed) {
      return;
    }

    serialId = Symbol();
    const currentSerialId = serialId;
    const currentSerialQueue = [...serialQueue];
    const generatorPromise = generatorFunction(currentSerialQueue, () => {
      return currentSerialId === serialId;
    });

    serialQueue.push({
      id: currentSerialId,
      task: generatorPromise
    });

    return generatorPromise;
    async function generatorFunction (previousQueue: any[], isLastSerial: boolean | (() => boolean)) {
      await Promise.all(previousQueue.map(item => catchPromiseError(item.task)));
      try {
        return await asyncFunction({ isLastSerial });
      } catch (error) {
        throw error;
      } finally {
        serialQueue = serialQueue.filter(item => item.id !== currentSerialId);
      }
    }
  };

  const destroySerialQueue = async function () {
    const currentSerialQueue = [...serialQueue];

    serialId = null;
    serialQueue = [];
    serialDestroyed = true;

    return Promise.all(currentSerialQueue.map(item => catchPromiseError(item.task)));
  };

  return {
    push: pushSerialQueue,
    destroy: destroySerialQueue
  };
}
