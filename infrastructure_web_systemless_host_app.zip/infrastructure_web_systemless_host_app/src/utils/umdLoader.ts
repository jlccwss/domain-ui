import Sandbox from './sandbox';
import { getGlobalProp, noteGlobalProps } from './global';
import { fetchAssetsContent } from './assets';

/**
 * load umd bundle
 *
 */
export function loadUmdModule (url: string) {
  return fetchAssetsContent(url).then((scriptText) => {
    const sandbox = new Sandbox({
      multiMode: true
    });
    const globalwindow: any = getGlobalWindow(sandbox);
    let libraryExport: string | undefined = '';
    noteGlobalProps(globalwindow);
    try {
      sandbox.execScriptInSandbox(scriptText, url);
      libraryExport = getGlobalProp(globalwindow);
      if (libraryExport) {
        const moduleInfo: any = globalwindow[libraryExport];
        if (globalwindow[libraryExport]) {
          delete globalwindow[libraryExport];
        }
        return moduleInfo;
      }
    } catch (err) {
      console.error(err);
      throw err;
    }
    return {};
  });
}

/**
 * Get globalwindow
 *
 * @export
 * @param {Sandbox} [sandbox]
 * @returns
 */
export function getGlobalWindow (sandbox: Sandbox) {
  if (sandbox.getSandbox) {
    sandbox.createProxySandbox();
    return sandbox.getSandbox();
  }
  return window;
}
