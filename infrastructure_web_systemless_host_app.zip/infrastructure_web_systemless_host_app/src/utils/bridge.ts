import { GLOBAL_VALUES_BRIDGE } from '../constants';
import Logan from '@dp/logan-web';

export function initBridge () {
  window[GLOBAL_VALUES_BRIDGE] = {
    Logan,
    rawWindow: window
  };
}

/**
 * 在桥上增加键值对
 * @param {string} key
 * @param {any} value
 */
export function appendBridgeMap (key: string, value: any) {
  window[GLOBAL_VALUES_BRIDGE] = window[GLOBAL_VALUES_BRIDGE] || {};
  window[GLOBAL_VALUES_BRIDGE][key] = value;
}

/**
 * 获取桥接方法
 * @param key 属性值
 * @returns
 */
export function getBridgeValue (key: string) {
  return window[GLOBAL_VALUES_BRIDGE][key];
}
