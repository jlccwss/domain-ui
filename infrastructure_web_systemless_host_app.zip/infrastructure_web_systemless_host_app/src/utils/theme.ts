import { Theme } from '@/types';
import { randomString } from './randomString';

const id = 'systemless-theme-' + randomString(5);

export function appendThemeStyle (theme?: Theme): void {
  if (!theme) {
    return;
  }
  const style = document.createElement('style');
  style.id = id;
  let content = '';
  for (const key in theme) {
    if (theme[key]) {
      content += `--${key}: ${theme[key]};`;
    }
  }
  style.innerHTML = `
      :root {
       ${content}
      }
    `;
  document.head.appendChild(style);
}
export function removeThemeStyle () {
  const styleEl = document.getElementById(id);
  if (styleEl) {
    styleEl.remove();
  }
}
