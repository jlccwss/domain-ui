/**
 * 生成路径匹配方法，fork自single-spa
 * @param {*} path 路径
 */
export function pathToActiveWhen(path: string) {
  const regex = toDynamicPathValidatorRegex(path);

  return (location: Location) => {
    const route = location.href
      .replace(location.origin, '')
      .replace(location.search, '')
      .split('?')[0];
    return regex.test(route);
  };
}

export function toDynamicPathValidatorRegex(path: string) {
  let lastIndex = 0;
  let inDynamic = false;
  let regexStr = '^';

  if (path[0] !== '/') {
    path = '/' + path;
  }

  for (let charIndex = 0; charIndex < path.length; charIndex++) {
    const char = path[charIndex];
    const startOfDynamic = !inDynamic && char === ':';
    const endOfDynamic = inDynamic && char === '/';
    if (startOfDynamic || endOfDynamic) {
      appendToRegex(charIndex);
    }
  }

  appendToRegex(path.length);
  return new RegExp(regexStr, 'i');

  function appendToRegex(index: number) {
    const anyCharMaybeTrailingSlashRegex = '[^/]+/?';
    const commonStringSubPath = escapeStrRegex(path.slice(lastIndex, index));

    regexStr += inDynamic
      ? anyCharMaybeTrailingSlashRegex
      : commonStringSubPath;

    if (index === path.length && !inDynamic) {
      regexStr =
        // use charAt instead as we could not use es6 method endsWith
        regexStr.charAt(regexStr.length - 1) === '/'
          ? `${regexStr}.*$`
          : `${regexStr}([/#].*)?$`;
    }

    inDynamic = !inDynamic;
    lastIndex = index;
  }

  function escapeStrRegex(str: string) {
    // borrowed from https://github.com/sindresorhus/escape-string-regexp/blob/master/index.js
    return str.replace(/[|\\{}()[\]^$+*?.]/g, '\\$&');
  }
}

// 判断是否是首页
export function isHomePage() {
  return location.pathname === '/';
}

/**
 * 为url拼接防缓存时间戳
 * @param {string}} url
 */
export function addTimeStamp(url: string) {
  const timestamp = 'timestamp=' + Date.now();
  if (url.indexOf('?') === -1) {
    if (url.indexOf('#') !== -1) {
      return url.replace('#', '?' + timestamp + '#');
    }
    return url + '?' + timestamp;
  }
  if (url.indexOf('#') !== -1) {
    return url.replace('#', '&' + timestamp + '#');
  }
  return url + '&' + timestamp;
}

/**
 * 获取去除泳道标识之后的域名
 * @returns {string} 域名
 */
export function pureHostName() {
  const hostname = location.hostname;
  const reg = /^(\S+)-([a-z]+)-sl-(.+)/;
  return hostname.replace(reg, (m, $1, $2, $3) => $3);
}
