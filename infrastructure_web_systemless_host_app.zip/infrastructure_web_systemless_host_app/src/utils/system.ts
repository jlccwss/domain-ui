import { EnvType } from '@/types';
import { isDebugMode } from './debug-mode';

export interface SystemInfo {
  swimlane: string;
  env: EnvType;
  debugMode: boolean;
}

export function getSwimlane(): string {
  const { hostname } = location;
  const reg = /^(\S+)-([a-z]+)-sl-.+/;
  const match = hostname.match(reg);
  return match ? match[1] + '-' + match[2] : '';
}

export function getEnv(): EnvType {
  return process.env.RUNTIME_ENV || 'development';
}
export function getSystemInfo(): SystemInfo {
  const swimlane = getSwimlane();
  return {
    swimlane,
    env: getEnv(),
    debugMode: isDebugMode(),
  };
}
