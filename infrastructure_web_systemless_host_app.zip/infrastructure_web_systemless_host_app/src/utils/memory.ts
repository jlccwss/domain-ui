/**
 * 轮训获取内存占用情况，上报到logan和raptor自定义指标
 * - totalJSHeapSize: 可使用的内存
 * - usedJSHeapSize: JS 对象（包括V8引擎内部对象）占用的内存数
 */
import { infoLog } from './log';

const byte2MB = (bt: number) => Number((bt / 1024 / 1024).toFixed(2));

let account = '';

export function setReportMemoryUserAccount(_account: string) {
  account = _account;
}

/**
 * 判断路径中是否有单号等内容，如果有的话，聚合路径
 * 如 /app/order/orderDetail/KL202110140876234，聚合为 /app/order/orderDetail/${num}
 * 判断是否有单号的方式，路径中是否有超过6位的连续数字
 * @returns string
 */
function combinePath(): string {
  const numberInPath = (path: string) => /\d{6,}/.test(path);
  return location.pathname
    .split('/')
    .map((substr) => (numberInPath(substr) ? '${num}' : substr))
    .join('/');
}

/**
 * 定时轮训，获取当前页面内存占用情况
 * @param raptor raptor对象
 */
export function checkMemory(raptor: Raptor) {
  const timeout = 5; // 默认5分钟
  if (performance && performance.memory) {
    loop();
  }

  function loop() {
    setTimeout(() => {
      const memory = performance.memory;
      if (!memory) {
        return;
      }
      const data = {
        jsHeapSizeLimit: byte2MB(memory.jsHeapSizeLimit),
        totalJSHeapSize: byte2MB(memory.totalJSHeapSize),
        usedJSHeapSize: byte2MB(memory.usedJSHeapSize),
      };
      infoLog('内存占用情况:' + JSON.stringify(data));
      // 上报raptor自定义指标
      raptor.addMetric(
        'totalJSHeapSize',
        {
          account: account,
          path: combinePath(),
        },
        data.totalJSHeapSize
      );
      raptor.addMetric(
        'usedJSHeapSize',
        {
          account: account,
          path: combinePath(),
        },
        data.usedJSHeapSize
      );
      loop();
    }, timeout * 60 * 1000);
  }
}
