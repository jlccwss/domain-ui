/**
 * 应用级别配置，缓存到storage中
 */
const CONFIG_STORAGE_KEY = '_app_config_';
const COLLECTED_URL_KEY_PREFIX = 'collected_url_key_prefix';
const RECENTLY_VIEWED_URL_KEY_PREFIX = 'recently_viewed_url_key_prefix';
const LOOP_STORAGE_USER = 'loop_storage_user';

export interface CollectedUrl {
  url: string;
  title: string;
  options?: {
    [key: string]: any;
  };
  modifyTime: number;
}
export interface RecentlyViewedUrl {
  url: string;
  title: string;
  options?: {
    [key: string]: any;
  };
  modifyTime: number;
}

export function getAppStorageConfig (appkey: string) {
  const config = getAllConfig();
  return config[appkey];
}
export function setAppStorageConfig (appkey: string, appConfig: any) {
  const config = getAllConfig();
  config[appkey] = appConfig;
  localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(config));
}

function getAllConfig () {
  const storage = localStorage.getItem(CONFIG_STORAGE_KEY);
  if (storage) {
    try {
      return JSON.parse(storage);
    } catch (e) {}
  }
  return {};
}

/**
 * 获取应用中用户存储的所有收藏链接
 * @param appkey 应用ID
 * @param userId 用户ID
 * @returns
 */
export function getUserCollectedUrls (
  appkey: string,
  userId: string
): CollectedUrl[] {
  const storageKey = `${COLLECTED_URL_KEY_PREFIX}_${appkey}_${userId}`;
  const value = window.localStorage.getItem(storageKey);
  if (value) {
    try {
      return JSON.parse(value);
    } catch (e) {}
  }
  return [];
}

/**
 * 设置用户在当前应用中的手收藏链接，如果已收藏，则取消。
 * @param appkey 应用ID
 * @param userId 用户ID
 * @returns
 */
export function setUserCollectUrl (
  appkey: string,
  userId: string,
  content: CollectedUrl[]
) {
  const storageKey = `${COLLECTED_URL_KEY_PREFIX}_${appkey}_${userId}`;
  window.localStorage.setItem(storageKey, JSON.stringify(content));
}

/**
 * 获取用户最近访问链接
 * @param appkey 应用ID
 * @param userId 用户ID
 * @returns
 */
export function getUserRecentlyViewedUrls (
  appkey: string,
  userId: string
): RecentlyViewedUrl[] {
  const storageKey = `${RECENTLY_VIEWED_URL_KEY_PREFIX}_${appkey}_${userId}`;
  const value = window.localStorage.getItem(storageKey);
  if (value) {
    try {
      return JSON.parse(value);
    } catch (e) {}
  }
  return [];
}

/**
 * 设置用户在当前应用中的手收藏链接，如果已收藏，则取消。
 * @param appkey 应用ID
 * @param userId 用户ID
 * @returns
 */
export function setUserRecentlyViewedUrl (
  appkey: string,
  userId: string,
  content: CollectedUrl[]
) {
  const storageKey = `${RECENTLY_VIEWED_URL_KEY_PREFIX}_${appkey}_${userId}`;
  window.localStorage.setItem(storageKey, JSON.stringify(content));
}

/**
 * 设置站点间无限循环缓存用户名，正常访问时调用
 * @param userName 用户名
 */
export function setLoopUser (userName: string) {
  window.localStorage.setItem(LOOP_STORAGE_USER, userName);
}

/**
 * 获取站点间无限循环缓存用户名，上报时调用
 * @returns 用户名
 */
export function getLoopUser () {
  return window.localStorage.getItem(LOOP_STORAGE_USER);
}
/**
 * 清除站点间无限循环缓存用户名，登出时调用
 */
export function clearLoopUser () {
  window.localStorage.removeItem(LOOP_STORAGE_USER);
}
