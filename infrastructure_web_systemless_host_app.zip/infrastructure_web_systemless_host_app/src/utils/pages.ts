import { AppConfig } from '@/types';
import { getEnv } from './system';

const env = getEnv();

function getDefaultHomePage() {
  return {
    development:
      '//test01-awp.hfe.test.meituan.com/klfe/web_common_page_homepage/index.html',
    test:
      '//test02-awp.hfe.test.meituan.com/klfe/web_common_page_homepage/index.html',
    staging:
      '//awp.hfe.st.meituan.com/klfe/web_common_page_homepage/index.html',
    production: '//awp.meituan.com/klfe/web_common_page_homepage/index.html',
  }[env];
}

export function getHomePage(appConfig: AppConfig) {
  const page =
    appConfig?.commonPages?.home || appConfig.home || getDefaultHomePage();
  if (typeof page === 'string') {
    return {
      name: 'home-page',
      entry: page,
      url: '',
    };
  }
  return Object.assign({}, page);
}
function getDefaultNotfoundPage() {
  return {
    development:
      '//test01-awp.hfe.test.meituan.com/klfe/web_admin_page_notfound/index.html',
    test:
      '//test02-awp.hfe.test.meituan.com/klfe/web_admin_page_notfound/index.html',
    staging: '//awp.hfe.st.meituan.com/klfe/web_admin_page_notfound/index.html',
    production: '//awp.meituan.com/klfe/web_admin_page_notfound/index.html',
  }[env];
}
export function getNotfoundPage(appConfig: AppConfig) {
  const page =
    appConfig?.commonPages?.notfound ||
    appConfig[404] ||
    getDefaultNotfoundPage();
  if (typeof page === 'string') {
    return {
      name: 'notfound-page',
      entry: page,
      url: '',
    };
  }
  return Object.assign({}, page);
}

function getDefaultUnauthorizedPage() {
  return {
    development:
      '//test01-awp.hfe.test.meituan.com/klfe/web_admin_page_unauthorized/index.html',
    test:
      '//test02-awp.hfe.test.meituan.com/klfe/web_admin_page_unauthorized/index.html',
    staging:
      '//awp.hfe.st.meituan.com/klfe/web_admin_page_unauthorized/index.html',
    production: '//awp.meituan.com/klfe/web_admin_page_unauthorized/index.html',
  }[env];
}
export function getUnauthorizedPage(appConfig: AppConfig) {
  const page =
    appConfig?.commonPages?.unauthorized || getDefaultUnauthorizedPage();
  if (typeof page === 'string') {
    return {
      name: 'unauthorized-page',
      entry: page,
      url: '',
    };
  }
  return Object.assign({}, page);
}
function getDefaultErrorPage() {
  return {
    development:
      '//test01-awp.hfe.test.meituan.com/klfe/web_common_page_error/index.html',
    test:
      '//test02-awp.hfe.test.meituan.com/klfe/web_common_page_error/index.html',
    staging: '//awp.hfe.st.meituan.com/klfe/web_common_page_error/index.html',
    production: '//awp.meituan.com/klfe/web_common_page_error/index.html',
  }[env];
}

export function getErrorPage(appConfig: AppConfig) {
  const page = appConfig?.commonPages?.error || getDefaultErrorPage();
  if (typeof page === 'string') {
    return {
      name: 'error-page',
      entry: page,
      url: '',
    };
  }
  return Object.assign({}, page);
}
