import { PreventLoop, LoopType } from '../index';
export interface TimeResult {
    time: number,
    res: boolean
}
export function timePendingPromise (time: number) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(null);
    }, time);
  });
}
export function checkTimeResult (name: string, config: {
    groupActionDuration: number,
    groupCount: number,
    checkLimit: number,
    type: LoopType,
}, arr: TimeResult[]) {
  let res = false;
  const instance = new PreventLoop({
    domainKey: Math.random().toString(),
    domainConfig: {
      groupActionDuration: config.groupActionDuration,
      groupCount: config.groupCount,
      checkLimit: config.checkLimit,
      type: config.type,
      callback () {
        res = true;
      }
    }
  });

  test(name, async () => {
    expect.assertions(1);
    return expect(
      Promise.all(
        arr.map(
          item => {
            return (async () => {
              await timePendingPromise(item.time);
              instance.logPoint();
              console.log(item.time, Date.now(), JSON.stringify((instance as any).logEngine.storeProxy.readRecord()));
              return res.toString();
            })();
          }
        )
      )
        .then(item => item.join(','))
    ).resolves.toEqual(arr.map(item => item.res).join(','));
  });
}
