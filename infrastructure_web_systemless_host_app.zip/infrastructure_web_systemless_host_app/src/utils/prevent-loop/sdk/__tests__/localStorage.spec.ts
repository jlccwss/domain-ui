import { checkTimeResult } from './common';
import { LoopType } from '..';

describe('prevent-loop-sdk-localStorage', () => {
  checkTimeResult('scene1', {
    groupActionDuration: 2,
    checkLimit: 2,
    groupCount: 3,
    type: LoopType.WebBetween
  }, [{
    time: 1000,
    res: false
  }, {
    time: 1500,
    res: false
  }, {
    time: 1800,
    res: false
  }, {
    time: 3100,
    res: false
  }, {
    time: 3200,
    res: false
  }, {
    time: 5200,
    res: false
  }, {
    time: 5710,
    res: true
  }]);
});
