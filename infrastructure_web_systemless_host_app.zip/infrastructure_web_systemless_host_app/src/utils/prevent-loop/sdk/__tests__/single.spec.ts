import { checkTimeResult } from './common';
import { LoopType } from '..';

describe('prevent-loop-sdk-singlegroup', () => {
  checkTimeResult('scene1', {
    groupActionDuration: 2,
    checkLimit: 3,
    groupCount: 1,
    type: LoopType.WebIn
  }, [{
    time: 1000,
    res: false
  }, {
    time: 1500,
    res: false
  }, {
    time: 5000,
    res: false
  }]);
});
