export interface IStorageBaseConfig {
  domainKey: string
}
export abstract class IStorageBase<T = any> {
  private readonly _config: IStorageBaseConfig
  get domainKey (): string {
    return this._config?.domainKey;
  }

  constructor (config: IStorageBaseConfig) {
    this._config = config;
  }

  abstract writeRecord(src: T): boolean
  abstract readRecord(): T
}
