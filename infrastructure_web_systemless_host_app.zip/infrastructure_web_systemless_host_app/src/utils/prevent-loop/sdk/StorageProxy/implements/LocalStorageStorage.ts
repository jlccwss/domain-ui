import { IStorageBase } from '../IStorageBase';

export class LocalStorageStorage<T> extends IStorageBase<T> {
  readRecord (): T {
    try {
      return JSON.parse(localStorage.getItem(this.domainKey)!) as T;
    } catch (error) {
      console.warn(error.message);
      return null as unknown as T;
    }
  }

  writeRecord (src: T): boolean {
    try {
      localStorage.setItem(this.domainKey, JSON.stringify(src));
      return true;
    } catch (error) {
      console.warn(error.message);
      return false;
    }
  }
}
