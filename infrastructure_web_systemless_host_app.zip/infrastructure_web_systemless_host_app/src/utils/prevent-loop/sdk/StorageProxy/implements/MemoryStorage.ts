import { IStorageBase } from '../IStorageBase';

// 本地内存存储，暂时放在这里，方便调试的话可以挂载到全局
const STORE_OBJ: Map<string, any> = (window as any).__STORE_OBJ = new Map<string, any>();
export class MemoryStorage<T> extends IStorageBase<T> {
  readRecord (): T {
    return STORE_OBJ.get(this.domainKey);
  }

  writeRecord (src: T): boolean {
    STORE_OBJ.set(this.domainKey, src);
    return true;
  }
}
