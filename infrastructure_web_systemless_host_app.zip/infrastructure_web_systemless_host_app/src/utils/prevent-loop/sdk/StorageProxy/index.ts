import { IStorageBase } from './IStorageBase';
import { MemoryStorage } from './implements/MemoryStorage';
import { LocalStorageStorage } from './implements/LocalStorageStorage';

export enum StorageProxyEnum {
    Memory='Memory',
    LocalStorage='LocalStorage'
}

export interface IStorageProxyConfig {
    domainKey:string
    proxyType:StorageProxyEnum
}

/**
 * 存储代理入口
 */
export class StorageProxy<T> {
    private _config:IStorageProxyConfig
    private _storager: IStorageBase<T>
    public get storager ():IStorageBase<T> {
      if (!this._storager) {
        throw new Error('_storager尚未初始化');
      }
      return this._storager;
    }

    constructor (config:IStorageProxyConfig) {
      this._config = config;
      /**
         * 初始化存储实例
         */
      this._storager = this.getProxy(this._config);
    }

    /**
     * 根据类型创建不同的代理实现
     * @param config
     */
    private getProxy (config:IStorageProxyConfig):IStorageBase<T> {
      let proxy:IStorageBase<T>;
      switch (config.proxyType) {
        case StorageProxyEnum.Memory:
          proxy = new MemoryStorage<T>({
            domainKey: config.domainKey
          });
          break;
        case StorageProxyEnum.LocalStorage:
          proxy = new LocalStorageStorage<T>({
            domainKey: config.domainKey
          });
          break;
        default:
          proxy = new MemoryStorage<T>({
            domainKey: config.domainKey
          });
          break;
      }
      return proxy;
    }

    /**
     * 领域读
     */
    public readRecord (): T {
      return this.storager.readRecord();
    }

    /**
     * 领域写
     * @param src
     */
    public writeRecord (src: T): boolean {
      return this.storager.writeRecord(src);
    }
}
