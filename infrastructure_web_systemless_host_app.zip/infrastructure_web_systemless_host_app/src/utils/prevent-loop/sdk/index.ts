import { LogEngine, ILogEngineParams } from './LogEngine';
import { StorageProxyEnum } from './StorageProxy';

export enum LoopType {
    WebBetween = 'WebBetween',
    WebIn = 'WebIn'
}

/**
 * 域配置
 */
export interface DomainConfig {
    /**
     * 聚合动作记录间隔，秒（L）
     */
    groupActionDuration: number
    /**
     * 结果判定时检查的聚合动作记录个数（M）
     */
    groupCount: number
    /**
     * 结果判定时检查的聚合动作记录安全触发次数限制（N）
     */
    checkLimit: number,
    /**
     * 用户配置回调，将在判定无限循环命中时触发
     */
    callback: () => void,
    type: LoopType
}

export interface IPreventLoopParams {
    domainKey: string
    domainConfig: DomainConfig
}

const proxyTypeMap = {
  [LoopType.WebIn]: StorageProxyEnum.Memory,
  [LoopType.WebBetween]: StorageProxyEnum.LocalStorage
};
/**
 * 防无限循环SDK
 */
export class PreventLoop {
  /**
       * 标准化Params
       * @param params 入参
       */
  private static resolveLogEngineParams (params: IPreventLoopParams): ILogEngineParams {
    const { domainKey, domainConfig: { groupActionDuration, groupCount, checkLimit, callback, type } } = params;
    return {
      domainKey, groupActionDuration, groupCount, checkLimit, callback, proxyType: proxyTypeMap[type]
    };
  }

    private readonly _params: IPreventLoopParams
    private readonly _resolvedLogEngineParams: ILogEngineParams
    private readonly logEngine: LogEngine

    constructor (params: IPreventLoopParams) {
      this._params = params;
      this._resolvedLogEngineParams = PreventLoop.resolveLogEngineParams(params);
      this.logEngine = new LogEngine(this._resolvedLogEngineParams);
    }

    /**
     * 打点
     */
    public logPoint ():boolean {
      return this.logEngine.logPoint();
    }
}
