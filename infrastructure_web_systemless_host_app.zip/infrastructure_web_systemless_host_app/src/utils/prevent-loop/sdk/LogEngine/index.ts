import { StorageProxy, StorageProxyEnum } from '../StorageProxy';

export interface ILogEngineParams {
  /**
   * 域模型唯一标识
   */
  domainKey: string,
  /**
   * 聚合动作记录间隔，秒（L）
   */
  groupActionDuration: number
  /**
   * 结果判定时检查的聚合动作记录个数（M）
   */
  groupCount: number
  /**
   * 结果判定时检查的聚合动作记录安全触发次数限制（N）
   */
  checkLimit: number
  /**
   * 用户配置回调，将在判定无限循环命中时触发
   */
  callback: () => void,

  /**
   * 存储代理类型
   */
  proxyType: StorageProxyEnum
}

export interface GroupActionModel {
  /**
   * 时间键，以毫秒的方式来记录时间点
   */
  timeKey: number,
  /**
   * 触发次数
   */
  count: number
}

/**
 * GroupActionModel[]的数据状态枚举
 */
enum DataState {
  /**
   * 全部数据过期
   */
  AllOutdated = 'AllOutDated',
  /**
   * 最新一次GroupActionModel过期
   */
  LatestOutdated = 'LatestOutdated',
  /**
   * 正确
   */
  Correct = 'Correct',

  /**
   * 错误（或不完整）
   */
  Wrong = 'Wrong'
}

export class LogEngine {
  private _params: ILogEngineParams
  private storeProxy: StorageProxy<GroupActionModel[]>

  private get domainKey (): string {
    return this._params?.domainKey;
  }

  private get groupActionDuration (): number {
    return this._params?.groupActionDuration;
  }

  private get groupCount (): number {
    return this._params?.groupCount;
  }

  private get checkLimit (): number {
    return this._params?.checkLimit;
  }

  private get callback () {
    return this._params?.callback;
  }

  // #region 计算型常量
  private singleCache?: number
  private doubleCache?: number

  private get SINGLE_DURATION () {
    if (!this.singleCache) {
      this.singleCache = 1000 * this.groupActionDuration;
    }
    return this.singleCache;
  }

  private get DOUBLE_DURATION () {
    if (!this.doubleCache) {
      this.doubleCache = 1000 * this.groupActionDuration * 2;
    }
    return this.doubleCache;
  }
  // #endregion

  constructor (params: ILogEngineParams) {
    // TODO 参数校验
    this._params = params;
    this.storeProxy = new StorageProxy<GroupActionModel[]>({
      proxyType: params.proxyType,
      domainKey: params.domainKey
    });
  }

  /**
   * 打点并返回本次打点后的触发状态
   */
  logPoint (): boolean {
    const queue = this.getNormalizedGroupActionsQueue();
    queue[queue.length - 1].count += 1;
    this.storeProxy.writeRecord(queue);
    const res = this.analysisQueue(queue);
    if (res) {
      this.callback();
      this.getNormalizedGroupActionsQueue(true);
    }
    return res;
  }

  /**
   * 获取当前聚合动作记录数组的状态
   * @param data
   * @param curDate
   */
  private getDataState (data: GroupActionModel[], curDate: Date): DataState {
    let datastate: DataState = DataState.Correct;
    try {
      if (Array.isArray(data) && data.length === this.groupCount) {
        const latest = data[data.length - 1];
        const diffTime = curDate.getTime() - latest.timeKey;
        if (diffTime < this.SINGLE_DURATION) {
          datastate = DataState.Correct;
        } else if (diffTime > this.DOUBLE_DURATION) {
          datastate = DataState.AllOutdated;
        } else {
          datastate = DataState.LatestOutdated;
        }
      } else {
        datastate = DataState.Wrong;
      }
    } catch (error) {
      console.error('getDataState error', error);
      datastate = DataState.Wrong;
    }

    return datastate;
  }

  /**
   * 分场景整理
   * @param enforceReset {boolean} 是否强制重置
   */
  private getNormalizedGroupActionsQueue (enforceReset = false): GroupActionModel[] {
    let queue = this.storeProxy.readRecord();
    const newDate = new Date();

    // 如果强制重置则视数据状态为全部过期
    const state = enforceReset ? DataState.AllOutdated : this.getDataState(queue, newDate);
    switch (state) {
      case DataState.Correct:
        // nothing todo
        break;
      case DataState.AllOutdated:
        queue = this.getNewQueue(newDate);
        this.storeProxy.writeRecord(queue);
        break;
      case DataState.LatestOutdated:
        queue.push({
          timeKey: queue[queue.length - 1].timeKey + this.SINGLE_DURATION,
          count: 0
        });
        queue.shift();
        break;
      case DataState.Wrong:
        queue = this.getNewQueue(newDate);
        this.storeProxy.writeRecord(queue);
        break;
      default:
        break;
    }
    return queue;
  }

  private getNewQueue (date: Date): GroupActionModel[] {
    const queue = new Array(this.groupCount - 1).fill(null).map(() => ({
      timeKey: 0,
      count: 0
    }));
    queue.push({
      timeKey: date.getTime(),
      count: 0
    });
    return queue;
  }

  private analysisQueue (queue: GroupActionModel[]): boolean {
    return (Array.isArray(queue) && queue.length === this.groupCount && queue.every(item => item.count >= this.checkLimit));
  }
}
