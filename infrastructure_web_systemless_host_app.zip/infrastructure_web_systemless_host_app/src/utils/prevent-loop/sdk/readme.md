# 循环检测sdk
本sdk提供的能力是，能够检测业务代码的无线循环场景，引导业务代码进行适当的处理。避免业务代码无限循环场景触发时带来的不良体验。

## 使用示例
```ts
// 先创建实例
const instance = new PreventLoop({
    domainKey: 'myEventDomainKey',
    domainConfig: {
      groupActionDuration: 60,
      groupCount: 1,
      checkLimit: 20,
      type: LoopType.WebIn,
      callback () {
        alert('trigger WebIn');
      }
    }
});
// 在能够取到的位置，调用打点即可
instance.logPoint()
``` 


## 参数声明

```ts
/**
 * 构造函数参数说明 
 */
export interface IPreventLoopParams {
    domainKey: string
    domainConfig: DomainConfig
}

export enum LoopType {
    WebBetween = 'WebBetween',
    WebIn = 'WebIn'
}
/**
 * 域配置
 */
export interface DomainConfig {
    /**
     * 聚合动作记录间隔，秒（L）
     */
    groupActionDuration: number
    /**
     * 结果判定时检查的聚合动作记录个数（M）
     */
    groupCount: number
    /**
     * 结果判定时检查的聚合动作记录安全触发次数限制（N）
     */
    checkLimit: number,
    /**
     * 用户配置回调，将在判定无限循环命中时触发
     */
    callback: () => void,
    type: LoopType
}

```