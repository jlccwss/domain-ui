import { PreventLoop, LoopType } from './sdk';

export class PagePreventLoopPlugin {
  /**
   * 连续1个60秒内，都触发了20次
   */
  static routerInstance: PreventLoop = new PreventLoop({
    domainKey: 'systemless-router-prevent-loop',
    domainConfig: {
      groupActionDuration: 60,
      groupCount: 1,
      checkLimit: 20,
      type: LoopType.WebIn,
      callback () {
        console.error('trigger WebIn');
      }
    }
  });

  /**
   * 连续1个60秒内，都触发了15次
  */
  static reloadInstance: PreventLoop = new PreventLoop({
    domainKey: 'systemless-reload-prevent-loop',
    domainConfig: {
      groupActionDuration: 60,
      groupCount: 1,
      checkLimit: 15,
      type: LoopType.WebBetween,
      callback () {
        console.error('trigger WebBetween');
      }
    }
  });

  static logRouterChange ():boolean {
    return PagePreventLoopPlugin.routerInstance.logPoint();
  }

  static logReloadChange ():boolean {
    return PagePreventLoopPlugin.reloadInstance.logPoint();
  }
}
