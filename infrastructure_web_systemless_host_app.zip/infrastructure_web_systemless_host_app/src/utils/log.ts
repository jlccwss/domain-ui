import Logan from '@dp/logan-web';
import { EnvType } from '@/types';

export function initLogan ({ env }: { env: EnvType }) {
  Logan.config({
    devMode: !(env === 'production' || env === 'staging')
  });
}

function log (argvs: any[]) {
  // 只有debug才在控制台输出日志
  if (process.env.DEBUG) {
    const args = [];
    for (let i = 0; i < argvs.length; i++) {
      args[i] = argvs[i];
    }
    const type: string = args[0];
    const message = `[${type}]${args[1]}`;
    const params: any[] = ([] as any).concat(message, args.slice(2));
    if (type === 'info') {
      console.info.apply(window, params);
    } else if (type === 'error') {
      console.error.apply(window, params);
    }
  }
}

export function infoLog (...argvs: any[]) {
  const args: any[] = [];
  for (let i = 0; i < argvs.length; i++) {
    args[i] = argvs[i];
  }
  log((['info'] as any[]).concat(args));
  Logan.info(...args);
}
export function errorLog (...argvs: any[]) {
  const args: any[] = [];
  for (let i = 0; i < argvs.length; i++) {
    args[i] = argvs[i];
  }
  log((['error'] as any[]).concat(args));
  Logan.error(...args);
}
