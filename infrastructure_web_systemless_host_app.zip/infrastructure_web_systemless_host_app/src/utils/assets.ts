import { PREFIX } from '../constants';
import { randomString } from './randomString';
import { addTimeStamp } from './url';

const assetsCache: {
  [key: string]: string;
} = {};

function noop () {
  return undefined;
}
/**
 * 获取脚本内容
 * @param {*}} url 脚本地址
 */
export async function fetchAssetsContent (
  url: string,
  errorCallback = noop
): Promise<string> {
  if (assetsCache[url]) {
    return assetsCache[url];
  }
  const reqUrl = url; // addTimeStamp(url);
  const response = await fetch(reqUrl);
  if (response.status >= 400) {
    errorCallback();
    throw new Error(`${url} load failed with status ${response.status}`);
  }
  const content = await response.text();
  assetsCache[url] = content;
  return content;
}

export async function loadAndAppendCss (asset: string) {
  const styleElement = document.createElement('style');
  const id = `${PREFIX}-css-${randomString(5)}`;
  styleElement.id = id;
  styleElement.innerHTML = await fetchAssetsContent(asset);
  return styleElement;
}
