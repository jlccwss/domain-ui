import { AppConfig, MicroApp } from '@/types';

interface ValidError {
  name: string;
  content: {
    [key: string]: any;
  };
}

/**
 * 检查应用配置是否正确，检查项如下：
 * - 是否配置了空路径的微应用
 * - 是否存在同名微应用
 * @param appConfig 应用配置
 */
export function validAppConfig(appConfig: AppConfig): ValidError[] {
  const errors: ValidError[] = [];
  const { apps = [] } = appConfig;
  // 检查是否配置了空路径或者/路径的微应用
  const emptyOrHomeApp: MicroApp[] = [];
  // 检查是否有同名的微应用，或者未设置name
  let duplicateAppList: MicroApp[] = [];
  let duplicateNameMap: {
    [key: string]: MicroApp[];
  } = {};
  // 检查是否有未设置name的微应用
  const noName: MicroApp[] = [];
  apps.forEach((app) => {
    if (!app.name) {
      noName.push(app);
    }
    if (
      !app.url ||
      app.url === '/' ||
      (Array.isArray(app.url) && app.url.indexOf('/') !== -1)
    ) {
      emptyOrHomeApp.push(app);
    }
    if (!duplicateNameMap[app.name]) {
      duplicateNameMap[app.name] = [];
    }
    duplicateNameMap[app.name].push(app);
  });
  duplicateAppList = Object.keys(duplicateNameMap).reduce(
    (prev: MicroApp[], name: string) => {
      if (duplicateNameMap[name].length > 1) {
        prev = prev.concat(duplicateNameMap[name]);
      }
      return prev;
    },
    []
  );
  duplicateNameMap = {}; // 重置对象
  if (emptyOrHomeApp.length) {
    errors.push({
      name: '微应用配置路径不合法',
      content: {
        appkey: appConfig.appkey,
        version: appConfig.version,
        message: formatMessage(emptyOrHomeApp),
      },
    });
  }
  if (noName.length) {
    errors.push({
      name: '微应用配置未设置唯一name',
      content: {
        appkey: appConfig.appkey,
        version: appConfig.version,
        message: formatMessage(noName),
      },
    });
  }
  if (duplicateAppList.length) {
    errors.push({
      name: '微应用配置中name不唯一',
      content: {
        appkey: appConfig.appkey,
        version: appConfig.version,
        message: formatMessage(duplicateAppList),
      },
    });
  }
  return errors;
}

/**
 * 格式化上报信息
 * @param apps 异常微应用列表
 * @returns
 */
function formatMessage(apps: MicroApp[]) {
  const nameUrls = apps.map(({ name, url }) => ({
    name,
    url,
  }));
  let message = '';
  try {
    message = JSON.stringify(nameUrls);
  } catch {
    message = apps.map(({ name }) => name).join(',');
  }
  // 长度不超过1024，避免影响raptor使用
  return message.length > 1024 ? message.slice(0, 1021) + '...' : message;
}
