import { AFTER_INIT, BEFORE_APP_CHANGE, AFTER_APP_CHANGE } from './constants';
import { appendThemeStyle, removeThemeStyle } from './utils/theme';
import { loadUmdModule } from './utils/umdLoader';
import { isHomePage, pathToActiveWhen } from './utils/url';
import { errorLog, infoLog } from './utils/log';
import { appendBridgeMap } from './utils/bridge';
import microContainer from './lib/microContainer';
import LayoutManager from './lib/LayoutManager';
import PluginManager from './lib/PluginManager';
import OpenApi from './lib/OpenApi';
import raptor from './lib/raptor';
import { createSerialQueue } from './utils/serialQueue';
import { AppConfig, MicroApp, PluginGroup } from '@/types';
import {
  getErrorPage,
  getNotfoundPage,
  getUnauthorizedPage,
  getHomePage,
} from './utils/pages';

/**
 * 业务自定义扩展API
 */
interface ExtraApi extends OpenApi {
  // 替换启动阶段默认加载函数
  handleInitialAppLoader?: (...args: any[]) => any;
  // 替换路由变化节点微应用加载函数
  handleStateChangeLoader?: (...args: any[]) => any;
}

export interface OnPopStateEvent {
  /**
   * 返回跳转是否应成功
   */
  (): boolean;
}

class AppContainer {
  lastApp: MicroApp | null = null;
  waitLoadMicroApps = createSerialQueue();
  currentMicroAppInstance: any = null;
  historyListener = null;
  layoutManager!: LayoutManager;
  pluginManager!: PluginManager;
  appConfig!: AppConfig;
  _api: ExtraApi | null = null;
  _appChangeListener: (() => void) | null = null;
  private _onPopStateQueue: OnPopStateEvent[] = [];

  async start(appConfig: AppConfig) {
    this.appConfig = appConfig;
    let ApiConstructor = OpenApi;
    if (appConfig.extraApi) {
      const res = await loadUmdModule(appConfig.extraApi);
      const factory = res.__esModule ? res.default : res;
      ApiConstructor = factory(OpenApi);
    }
    const api = new ApiConstructor(appConfig);
    this._api = api;
    appendBridgeMap('api', api);

    // 初始化路由监听
    this.initHistory();
    // 初始化主题配置
    this.initTheme();

    // 初始化布局和插件管理器
    this.layoutManager = new LayoutManager({
      defaultLayout: appConfig.layout,
      api,
    });
    this.pluginManager = new PluginManager({
      api,
    });
    // 执行初始化结束阶段插件
    try {
      await this.pluginManager.exec(appConfig.plugins || [], AFTER_INIT);
    } catch (e) {
      errorLog(`${AFTER_INIT} 插件执行失败`, e);
      // TODO: 插件终止机制重新设计处理
      // raptor.addJsError(e, {
      //   step: AFTER_INIT
      // });
    }
    // 启动微应用
    microContainer.startApp();
    // 加载当前href对应的微应用
    if (
      this._api?.handleInitialAppLoader &&
      typeof this._api.handleInitialAppLoader === 'function'
    ) {
      this._api?.handleInitialAppLoader();
    } else {
      this.loadMicroApp(this.getMatchedApp());
    }
    this.logPv();
  }

  getMatchedApp(): MicroApp | undefined {
    const apps = this.appConfig.apps || [];
    return apps.find((app) => {
      const activeWhen = pathToActiveWhen(app.url);
      return activeWhen(location);
    });
  }

  // 获取所有的微应用，包括特殊微应用
  getAllApps(): MicroApp[] {
    let result: MicroApp[] = [];
    result = result.concat(this.appConfig.apps);

    return result.concat(
      this.appConfig.apps,
      getHomePage(this.appConfig),
      getNotfoundPage(this.appConfig),
      getErrorPage(this.appConfig),
      getUnauthorizedPage(this.appConfig)
    );
  }

  async destroy() {
    await this.unmountMicroApps();
    await this.waitLoadMicroApps.destroy();
    window.removeEventListener('popstate', this.handlePopstate);
    removeThemeStyle();
    this.layoutManager.destroy();
  }

  initHistory() {
    this.handlePopstate = this.handlePopstate.bind(this);
    window.addEventListener('popstate', this.handlePopstate);
  }

  /**
   * 绑定popState触发后的事件
   * @param func
   */
  public onPopState(func: OnPopStateEvent) {
    if (!this._onPopStateQueue.includes(func)) {
      this._onPopStateQueue.push(func);
    }
  }

  logPv() {
    if (this.appConfig.sdk?.owl?.autoPv) {
      raptor.setPageKey(); // 每次URL切换时，自动上报PV
    }
  }

  handlePopstate(event: PopStateEvent) {
    try {
      for (const func of this._onPopStateQueue) {
        if (!func()) {
          return;
        }
      }
    } catch (error) {
      raptor.addJsError(error);
    }
    this.logPv();

    if (
      this._api?.handleStateChangeLoader &&
      typeof this._api?.handleStateChangeLoader === 'function'
    ) {
      this._api?.handleStateChangeLoader(event);
      return;
    }
    const app = this.getMatchedApp();
    if (this.lastApp !== app) {
      infoLog(
        `路由发生变化，当前路径${window.location.pathname}；切换微应用：`,
        app
      );
      this.loadMicroApp(app);
    }
  }

  initTheme() {
    const theme = this.appConfig.theme;
    appendThemeStyle(theme);
  }

  async loadMicroApp(app: MicroApp | undefined) {
    if (!app && isHomePage()) {
      // 展示首页
      app = getHomePage(this.appConfig);
    }
    if (!app) {
      app = getNotfoundPage(this.appConfig);
    }
    await this.waitLoadMicroApps.push(async () => {
      return await this.sequentiaLoadMicroApp(app as MicroApp);
    });
  }

  async sequentiaLoadMicroApp(app: MicroApp) {
    let container = '';
    let targetLayout = null;
    // 如果微应用级别有插件配置，则执行微应用级别插件，否则执行应有级别插件。
    const plugins: PluginGroup[] = app.plugins || this.appConfig.plugins || [];
    // 执行切换前置插件
    let result = false;
    try {
      // TODO: 根据插件返回结果判断是否继续执行切换
      await this.pluginManager.exec(plugins, BEFORE_APP_CHANGE);
      result = true;
    } catch (e) {
      errorLog(`${BEFORE_APP_CHANGE} 插件执行失败`, e);
      // TODO: 插件终止机制重新设计处理
      // raptor.addJsError(e, {
      //   step: BEFORE_APP_CHANGE
      // });
    }
    if (result) {
      await this.unmountCurrentMicroApp();
      targetLayout = app.layout;
      container = await this.layoutManager.renderLayout(targetLayout);
      // eslint-disable-next-line no-useless-catch
      try {
        // await 后 getStatus()为 LOADING_SOURCE_CODE
        this.currentMicroAppInstance = await microContainer.loadMicroApp({
          container: container,
          ...app,
        });
        await this.currentMicroAppInstance.mountPromise;
      } catch (e) {
        // doSomething
        throw e;
      }
      // 缓存加载容器，以便执行reload方法
      this.currentMicroAppInstance.container = container;
      this.lastApp = app;
      /**
       * 注释原因:
       * 1.驼峰|海纳现有历史记录逻辑仅展示 aside 中的连接 本期在 aside 中执行进行openApi调用
       * 2.最近浏览记录在 url app为多对多时,存在重复计数问题可通过 setRecentlyViewedUrl 前进行处理
       */
      // this._api?.setRecentlyViewedUrl(location.href, document.title);
      if (this._appChangeListener) {
        this._appChangeListener();
      }
      try {
        await this.pluginManager.exec(plugins, AFTER_APP_CHANGE);
      } catch (e) {
        errorLog(`${AFTER_APP_CHANGE} 插件执行失败`, e);
        // TODO: 插件终止机制重新设计处理
        // raptor.addJsError(e, {
        //   step: AFTER_APP_CHANGE
        // });
      }
    }
  }

  onAppChange(appChangeListener: () => void) {
    this._appChangeListener = appChangeListener;
  }

  /**
   *
   * 1. currentMicroAppInstance 在这如下状态时需要等待加载完成再卸载,否则无法销毁无法销毁
   *    "LOADING_SOURCE_CODE" | "NOT_BOOTSTRAPPED" | "BOOTSTRAPPING" | "NOT_MOUNTED" | "MOUNTING"
   * 2. unmountMicroApps 是需要将waitLoadMicroApps整队列加载执行完成后卸载并
   */
  async unmountMicroApps() {
    await this.waitLoadMicroApps.push(async () => {
      return await this.unmountCurrentMicroApp();
    });
  }

  async unmountCurrentMicroApp() {
    if (this.currentMicroAppInstance?.getStatus() === 'MOUNTED') {
      await this.currentMicroAppInstance.unmount();
      this.currentMicroAppInstance = null;
    }
  }
}
const appContainer = new AppContainer();

export default appContainer;
