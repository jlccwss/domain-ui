import { loadUmdModule } from '../utils/umdLoader';
import raptor from './raptor';
import { infoLog, errorLog } from '@/utils/log';
import OpenApi from './OpenApi';
import { PluginGroup, PluginOptions, AppPlugin, PluginStep } from '@/types';

interface PluginConstructor {
  // eslint-disable-next-line @typescript-eslint/no-misused-new
  new (options?: PluginOptions): PluginConstructor;
  execute: (api: OpenApi) => Promise<any>;
}

interface PluginUmdModule extends PluginConstructor {
  __esModule: boolean;
  default: PluginConstructor;
}

export default class PluginManager {
  _api: OpenApi;
  constructor({ api }: { api: OpenApi }) {
    this._api = api;
  }

  exec(plugins: PluginGroup[], step?: PluginStep) {
    const stepPlugins: PluginGroup | undefined = plugins.find(
      (item) => item.step === step
    );
    if (!stepPlugins) {
      return Promise.resolve();
    }
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const _this = this;
    const pluginList = stepPlugins.list;
    return new Promise((resolve, reject) => {
      function walk(list: Array<PluginUmdModule | null>, i: number) {
        if (i >= pluginList.length) {
          resolve(true);
        } else {
          const module = list[i];
          if (!module) {
            infoLog('空插件，跳过', pluginList[i]);
            walk(list, ++i);
            return;
          }
          let Plugin = null;
          if (module.__esModule) {
            Plugin = module.default;
          } else {
            Plugin = module;
          }
          const instance = new Plugin(pluginList[i].options);
          instance
            .execute(_this._api)
            .then((result) => {
              if (result) {
                infoLog('插件执行成功：', pluginList[i], result);
                walk(list, ++i);
              } else {
                errorLog('插件返回结果有误，插件队列停止执行', pluginList[i]);
                if (
                  Object.prototype.toString.call(result) === '[object Error]'
                ) {
                  reject(result);
                } else {
                  reject(new Error(result));
                }
              }
            })
            .catch((err) => {
              // eslint-disable-next-line no-console
              console.error(err);
              errorLog('插件执行异常', err);
              raptor.addJsError(err, {
                type: '插件执行异常',
              });
              walk(list, ++i);
            });
        }
      }
      this.loadPlugins(pluginList).then((list) => {
        walk(list, 0);
      });
    });
  }

  async loadPlugins(
    scripts: AppPlugin[]
  ): Promise<Array<PluginUmdModule | null>> {
    const result: Array<PluginUmdModule | null> = [];
    const promises = scripts.map(({ script }) => loadUmdModule(script));
    let count = 0;
    return new Promise((resolve) => {
      for (let i = 0; i < promises.length; i++) {
        promises[i]
          .then(
            ((idx) => async (module: PluginUmdModule) => {
              infoLog('插件加载成功：', scripts[idx], module);
              result[idx] = module;
              count++;
              if (count === promises.length) {
                resolve(result);
              }
            })(i)
          )
          .catch(
            ((idx) => () => {
              result[idx] = null;
              count++;
              errorLog('插件加载失败：', scripts[idx]);
              raptor.addResourceError(
                `插件加载失败（${JSON.stringify(scripts[idx])}）`
              );
              if (count === promises.length) {
                resolve(result);
              }
            })(i)
          );
      }
    });
  }
}
