import { LAYOUT_CONTAINER_ID, DEFAULT_ROOT_ID } from '../constants';
import { loadUmdModule } from '../utils/umdLoader';
import { loadAndAppendCss } from '../utils/assets';
import raptor from './raptor';
import { md5 } from '../utils/md5';
import { errorLog, infoLog } from '@/utils/log';
import * as demotionLayout from './demotionLayout';
import { Layout, LayoutOptions, Slot, SlotOptions } from '@/types';

interface LayoutUmdModule {
  mount: (
    target: HTMLElement,
    api: any,
    options?: LayoutOptions
  ) => Promise<any>;
  unmount: () => Promise<any>;
  container: string;
  slots?: {
    [key: string]: string;
  };
}

interface StyleModule {
  mount: () => Promise<any>;
  unmount: () => Promise<any>;
}
interface SlotUmdModule {
  mount: (target: HTMLElement, api: any, options?: SlotOptions) => Promise<any>;
  unmount: () => Promise<any>;
}
interface SlotModule {
  module: SlotUmdModule;
  options?: SlotOptions;
  style?: StyleModule;
}
interface SlotModules {
  [key: string]: SlotModule;
}

interface LayoutModule {
  module: LayoutUmdModule;
  script: string;
  options?: LayoutOptions; // 注入参数
  style?: StyleModule;
  slots?: SlotModules;
}

function ensureLayoutContainerEl(): HTMLElement {
  let layoutContainer = document.getElementById(LAYOUT_CONTAINER_ID);
  if (!layoutContainer) {
    layoutContainer = document.createElement('div');
    layoutContainer.id = LAYOUT_CONTAINER_ID;
    const root = document.querySelector(`#${DEFAULT_ROOT_ID}`);
    root?.appendChild(layoutContainer);
  }
  return layoutContainer;
}

export default class LayoutManager {
  _api = null;
  _lastLayout = '';
  _cacheModules: {
    [key: string]: LayoutModule;
  } = {};

  _defaultLayout: Layout;
  constructor({ defaultLayout, api }: { defaultLayout: Layout; api: any }) {
    if (!defaultLayout) {
      throw new Error('[Layout] default layout is required!');
    }
    this._api = api;
    this._defaultLayout = defaultLayout;
  }

  async renderLayout(layout: Layout | undefined) {
    const targetLayout: Layout = layout || this._defaultLayout;
    let layoutModule: LayoutModule | null = null;
    const md5Key = md5(JSON.stringify(targetLayout));
    if (this._lastLayout !== md5Key) {
      if (this._lastLayout) {
        const lastLayoutModule = this._cacheModules[this._lastLayout];
        this.unmountLayout(lastLayoutModule);
      }
      layoutModule = await this.loadLayout(targetLayout, md5Key);
      await this.mountLayout(layoutModule);
      this._lastLayout = md5Key;
    } else {
      layoutModule = this._cacheModules[this._lastLayout];
    }
    return layoutModule.module.container;
  }

  destroy() {
    if (this._lastLayout) {
      const lastLayoutModule = this._cacheModules[this._lastLayout];
      this.unmountLayout(lastLayoutModule);
    }
  }

  async loadLayout(layout: Layout, md5Key: string): Promise<LayoutModule> {
    if (this._cacheModules[md5Key]) {
      infoLog('从缓存中加载布局', this._cacheModules[md5Key]);
      return this._cacheModules[md5Key];
    }
    const module = await this.loadLayoutModule(layout);
    this._cacheModules[md5Key] = module;
    return module;
  }

  async loadLayoutModule(options: Layout): Promise<LayoutModule> {
    const { script, style, slots } = options;
    let layout = null;
    let styleModule;
    try {
      layout = await loadUmdModule(script);
      styleModule = await this.getStyleModule(style);
    } catch (err) {
      errorLog('布局加载失败，使用默认布局', script);
      layout = demotionLayout;
      styleModule = undefined;
    }
    let slotModules: SlotModules | undefined;
    if (layout === demotionLayout) {
      slotModules = {};
    } else {
      slotModules = await this.loadSlotModules(slots);
    }
    return {
      module: layout,
      script,
      options: options.options, // 注入参数
      style: styleModule,
      slots: slotModules,
    };
  }

  async loadSlotModules(slots: Slot[] = []): Promise<SlotModules | undefined> {
    if (!slots.length) {
      return;
    }
    const promises = slots.map((item) => loadUmdModule(item.script));
    const modules: SlotModules = {};
    let count = 0;
    // eslint-disable-next-line
    const _this = this;
    let index = 0;
    return new Promise((resolve) => {
      for (let i = 0; i < promises.length; i++) {
        promises[i]
          .then(
            ((idx) => {
              return async function(module: SlotUmdModule) {
                index = idx;
                modules[slots[idx].target] = {
                  module: module,
                  options: slots[idx].options,
                  style: await _this.getStyleModule(slots[idx].style),
                };
                count++;
                if (count === promises.length) {
                  resolve(modules);
                }
              };
            })(i)
          )
          .catch((err) => {
            // eslint-disable-next-line no-console
            console.error(err);
            errorLog('插槽加载失败', err, slots[index]);
            raptor.addResourceError(`插槽加载失败：${slots[index]?.script}`, {
              ...slots[index],
            });
            count++;
            if (count === promises.length) {
              resolve(modules);
            }
          });
      }
    });
  }

  async mountLayout(layoutModule: LayoutModule) {
    const layoutContainer = ensureLayoutContainerEl();
    try {
      if (layoutModule.style) {
        await layoutModule.style.mount(); // 先挂载样式
      }
      await layoutModule.module.mount(
        layoutContainer,
        this._api,
        layoutModule.options
      );
      infoLog('布局挂载成功', layoutModule);
    } catch (err) {
      errorLog('布局挂载失败', err, layoutModule);
      raptor.addJsError(`布局挂载失败:${layoutModule.script}`);
    }
    for (const target in layoutModule.slots) {
      if (layoutModule.module.slots && layoutModule.module.slots[target]) {
        const ele: HTMLElement | null = document.querySelector(
          layoutModule.module.slots[target]
        );
        if (ele) {
          const slot = layoutModule.slots[target];
          try {
            if (slot.style) {
              await slot.style.mount();
            }
            await slot.module.mount(ele, this._api, slot.options);
            infoLog('插槽挂载成功', layoutModule, target, slot);
          } catch (err) {
            errorLog('插槽挂载失败', layoutModule, target, slot);
            raptor.addJsError(
              `插槽挂载失败:${layoutModule.script}，目标节点：${target}`
            );
          }
        }
      }
    }
  }

  unmountLayout(layoutModule: LayoutModule) {
    layoutModule.module.unmount();
    if (layoutModule.style) {
      layoutModule.style.unmount();
    }
    for (const target in layoutModule.slots) {
      const slot = layoutModule.slots[target];
      slot.module.unmount();
      if (slot.style) {
        slot.style.unmount();
      }
    }
  }

  async getStyleModule(url: string | undefined): Promise<StyleModule> {
    if (!url) {
      return {
        mount: async () => undefined,
        unmount: async () => undefined,
      };
    }
    const cssRoot = document.getElementsByTagName('head')[0];
    const styleElement: HTMLStyleElement = await loadAndAppendCss(url);
    return {
      mount: async () => {
        cssRoot.appendChild(styleElement);
      },
      unmount: async () => {
        if (styleElement) {
          styleElement.remove();
        }
      },
    };
  }
}
