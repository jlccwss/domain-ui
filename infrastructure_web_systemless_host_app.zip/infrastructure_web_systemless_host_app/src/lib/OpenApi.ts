/**
 * 对插件、布局、布局插槽暴露的公共API
 * 提供标准化DOM操作、状态更新机制、公共数据获取API等
 */
import { getEnv } from '@/utils';
import appContainer from '../appContainer';
import { AppConfig, EnvType, MicroApp, Theme, MicroAppProps } from '@/types';
import { EventEmitter } from 'events';
import cloneDeep from 'lodash.clonedeep';
import {
  getUserCollectedUrls,
  setUserCollectUrl,
  CollectedUrl,
  getUserRecentlyViewedUrls,
  RecentlyViewedUrl,
  setUserRecentlyViewedUrl,
  clearLoopUser,
} from '../utils/storage';
import {
  getErrorPage,
  getHomePage,
  getNotfoundPage,
  getUnauthorizedPage,
} from '@/utils/pages';

export interface UserInfo {
  name: string;
  id: string;
  account: string;
}
type UserInfoCallBack = (user: UserInfo) => void;
type ExtraUserInfoCallback = (info: any) => void;
type Menus = any[];
type MenusCallBack = (menus: Menus) => void;
type AsideStateCallBack = (state: boolean) => void;
type UnWatchFn = () => void;

type EventCallback = (a: any) => void;
type MessageCallback = (events: MessageEvent) => void;
type PageTipsInfoCallback = (pageTips: any) => void;

// 基座应用事件集合
type ListenerType =
  | 'hide-aside' // 隐藏侧边栏事件
  | 'show-aside' // 显示侧边栏事件
  | 'hide-header' // 隐藏header事件
  | 'show-header' // 显示header 事件
  | 'set-collect-url' // 设置用户收藏列表
  | 'set-recently-view-url'; // 设置用户最近浏览记录列表

interface AppBaseInfo {
  appName: string;
  appkey: string;
  version: string;
}

const eventEmitter: EventEmitter = new EventEmitter();

export default class OpenApi {
  private _userInfo: UserInfo | null = null;
  private _menus: Menus = [];
  private _originalMenus: Menus = []; // 过滤前的menus
  private _asideState = true;
  private _watchers: {
    [key: string]: EventCallback[];
  } = {};

  private _appConfig: AppConfig;

  // 缓存用户附加信息
  private _extraUserInfo: any = null;

  private _loginFn: (() => void) | (() => Promise<void>) | null = null;
  private _logoutFn: (() => void) | (() => Promise<void>) | null = null;
  private _onIframeMessageCallback: MessageCallback | undefined;
  private _registerApi: {
    [namespace: string]: {
      [apiName: string]: (...args: any[]) => any;
    };
  } = {};

  // 缓存路由切换时，头部提示
  private _pageTips = '';

  constructor(appConfig: AppConfig) {
    this._appConfig = appConfig;
  }

  /**
   * 获取当前记录的用户信息
   * @returns UserInfo 用户信息
   */
  getUserInfo(): UserInfo | null {
    return this._userInfo;
  }

  /**
   * 设置用户信息，供其他模块调用
   * @param userInfo 用户信息
   */
  setUserInfo(userInfo: UserInfo) {
    this._userInfo = userInfo;
    this._emitWatcher('USER_INFO', userInfo);
  }

  /**
   * 监听用户信息变化
   * @param callback 回调方法
   * @returns listener
   * @example  let unwatch = api.watchUserInfo(handUserInfoChange); unwatch();
   */
  watchUserInfo(callback: UserInfoCallBack): UnWatchFn {
    return this._setWatcher('USER_INFO', callback);
  }

  /**
   * 获取用户附加属性
   * @returns 附加属性
   */
  getExtraUserInfo(): any {
    return this._extraUserInfo;
  }

  /**
   * 设置用户附加属性
   * @param extraInfo 附加属性
   */
  setExtraUserInfo(extraInfo: any) {
    this._extraUserInfo = extraInfo;
    this._emitWatcher('EXTRA_USER_INFO', extraInfo);
  }

  /**
   * 监听附加用户信息变化
   * @param callback 回调函数
   * @returns
   */
  watchExtraUserInfo(callback: ExtraUserInfoCallback): UnWatchFn {
    return this._setWatcher('EXTRA_USER_INFO', callback);
  }

  /**
   * 获取菜单列表
   * @returns 菜单列表
   */
  getMenus(): Menus {
    return this._menus;
  }

  /**
   * 获取原始menus，即经过transform转化之前的menus
   * @returns 原始的menus
   */
  getOriginalMenus(): Menus {
    return this._originalMenus;
  }

  /**
   * 自定义菜单转化方法，业务可以通过覆盖这个方法，实现自定义菜单过滤方法
   * @param {any} menus
   * @returns
   */
  transformMenus(menus: Menus): Menus {
    return menus;
  }

  /**
   * 设置菜单列表，供其他模块调用。设置菜单的时候会经过 transformMenus 方法过滤/转化
   * @param menus 菜单列表
   */
  setMenus(menus: Menus) {
    this._originalMenus = cloneDeep(menus);
    menus = this.transformMenus(menus);
    this._menus = menus;
    this._emitWatcher('MENUS', menus);
  }

  /**
   * 监听菜单变化
   * @param callback 监听回调函数
   * @returns 取消watch的回调
   */
  watchMenus(callback: MenusCallBack) {
    return this._setWatcher('MENUS', callback);
  }

  /**
   * 对iframe src进行过滤转换
   * @param iframeSrc 原始iframeSrc
   * @returns iframe src
   */
  transformIframeSrc(iframeSrc: string): string {
    return iframeSrc;
  }

  /**
   * 注册iframe内外postMessage通信回调函数
   * @param callback 回调函数
   */
  // onIframeMessage (callback: MessageCallback) {
  //   if (callback && typeof callback === 'function') {
  //     this._onIframeMessageCallback = callback;
  //   }
  // }

  /**
   * 设置侧边栏展开收齐状态
   * @param {boolean} state 是否展开，默认展开
   */
  setAsideState(state: boolean) {
    const oldState = this._asideState;
    this._asideState = !!state;
    if (oldState !== this._asideState) {
      this._emitWatcher('ASIDE_STATE', this._asideState);
    }
  }

  /**
   * 获取侧边栏展开收齐状态
   * @returns {boolean} 侧边栏状态
   */
  getAsideState(): boolean {
    return this._asideState;
  }

  /**
   * 监听侧边栏展开收起状态
   * @param {function} callback
   * @returns
   */
  onAsideStateChange(callback: AsideStateCallBack) {
    return this._setWatcher('ASIDE_STATE', callback);
  }

  /**
   * 抛出隐藏侧边栏事件，由其他模块触发，由布局接收
   */
  hideAside() {
    eventEmitter.emit('hide-aside');
  }

  /**
   * 抛出显示侧边栏事件，由其他模块触发，由布局接收
   */
  showAside() {
    eventEmitter.emit('show-aside');
  }

  /**
   * 抛出隐藏头部事件，由其他模块触发，由布局接收
   */
  hideHeader() {
    eventEmitter.emit('hide-header');
  }

  /**
   * 抛出显示头部事件，由其他模块触发，由布局接收
   */
  showHeader() {
    eventEmitter.emit('show-header');
  }

  /**
   * 获取系统信息
   * @returns 系统基本信息
   */
  getAppInfo(): AppBaseInfo {
    const appInfo = this._appConfig || {};
    return {
      appName: appInfo.appName,
      appkey: appInfo.appkey,
      version: appInfo.version,
    };
  }

  /**
   * 获取当前执行环境
   * @returns {EnvType} 当前环境信息
   */
  getRuntimeEnv(): EnvType {
    return getEnv();
  }

  /**
   * 获取当前系统主题配置表
   * @returns 系统主题配置
   */
  getAppTheme(): Theme | undefined {
    const appInfo = this._appConfig || {};
    return appInfo.theme;
  }

  /**
   * 获取微应用列表
   * @returns 微应用列表
   */
  getMicroApps(): MicroApp[] {
    const appInfo = this._appConfig || {};
    return appInfo.apps;
  }

  /**
   * 获取当前运行中的微应用
   * @returns 当前微应用
   */
  getCurrentApp(): MicroApp | null {
    return appContainer.lastApp;
  }

  /**
   * 手动加载微应用
   * @param app 微应用配置信息
   */
  async loadMicroApp(app: MicroApp | undefined) {
    await appContainer.loadMicroApp(app);
  }

  /**
   * 执行登录方法，默认是空调用，需要开发者调用initLogin方法设置系统所需的登录方法
   */
  async login() {
    if (this._loginFn && typeof this._loginFn === 'function') {
      await this._loginFn();
    }
  }

  /**
   * 初始化登录方法
   * @param loginFn 登录方法
   */
  initLogin(loginFn: () => void) {
    this._loginFn = loginFn;
  }

  /**
   * 执行登出方法，默认是空调用，需要开发者调用initLogin方法设置系统所需的登出方法
   */
  async logout() {
    if (this._logoutFn && typeof this._logoutFn === 'function') {
      await this._logoutFn();
      clearLoopUser();
    }
  }

  /**
   * 初始化登出方法
   * @param logoutFn 登出方法
   */
  initLogout(logoutFn: () => void) {
    this._logoutFn = logoutFn;
  }

  /**
   * 自注册API
   * @param namespace 命名作用域
   * @param apiName API名称
   * @param fn API方法
   */
  registerMethod(
    namespace: string,
    apiName: string,
    fn: (...args: any) => void
  ) {
    this._registerApi[namespace] = this._registerApi[namespace] || {};
    this._registerApi[namespace][apiName] = fn;
  }

  /**
   * 调用自注册API
   * @param namespace 命名作用域
   * @param apiName API名称
   * @param args 函数参数
   * @returns
   */
  applyMethod(namespace: string, apiName: string, ...args: any) {
    const allApis = this._registerApi[namespace];
    if (allApis && allApis[apiName]) {
      const fn = allApis[apiName];
      return fn.apply(this, args);
    }
    throw new ReferenceError(`${namespace}.${apiName} is undefined`);
  }

  /**
   * 判断API是否可用，包括内置API以及自注册API
   * @param apiName API名字，可以使用 aaa.bbb 判断自注册命名空间下API是否存在
   */
  canIUse(apiName: string): boolean {
    const nameArr: string[] = apiName.split('.');
    if (nameArr.length === 1) {
      return (
        !!(this as any)[apiName] && typeof (this as any)[apiName] === 'function'
      );
    }
    const namespace = nameArr[0];
    const name = nameArr[1];
    return (
      !!this._registerApi[namespace] && !!this._registerApi[namespace][name]
    );
  }

  /**
   * 监听基座内置事件
   * @param type 事件类型
   * @param listener 事件回调
   */
  on(type: ListenerType, listener: any) {
    return eventEmitter.on(type, listener);
  }

  /**
   * 移除基座内置事件
   * @param type 事件类型
   * @param listener 事件回调
   */
  off(type: ListenerType, listener: any) {
    return eventEmitter.off(type, listener);
  }

  /**
   * 获取当前用户在当前系统中收藏的链接地址
   * @param account 用户账号，每个用户的账号收藏数据都是隔离的
   * @returns
   */
  getCollectedUrls(account?: string): CollectedUrl[] {
    const appkey = this.getAppInfo()?.appkey;
    const userAccount = account || this.getUserInfo()?.account;
    if (appkey && userAccount) {
      return getUserCollectedUrls(appkey, userAccount);
    }
    return [];
  }

  /**
   * 设置收藏链接，数组结构。会触发 set-collect-url 事件
   * @param content CollectedUrl[]
   * @param account 可选配置，自定义收藏账号
   */
  setCollectUrl({
    content,
    account,
  }: {
    content: CollectedUrl[];
    account?: string;
  }) {
    const appkey = this.getAppInfo()?.appkey;
    const userAccount = account || this.getUserInfo()?.account;
    const handleContent = (content || []).filter((item) => {
      return item.url && item.title;
    });
    if (appkey && userAccount) {
      setUserCollectUrl(appkey, userAccount, handleContent);
      eventEmitter.emit(
        'set-collect-url',
        getUserCollectedUrls(appkey, userAccount)
      );
    }
  }

  /**
   * 获取当前用户最近访问链接
   * @param account 账号，可选参数，默认当前系统登录之后的账号ID
   * @returns 最近访问链接
   */
  getRecentlyViewedUrls(account?: string): RecentlyViewedUrl[] {
    const appkey = this.getAppInfo()?.appkey;
    const userAccount = account || this.getUserInfo()?.account;
    if (appkey && userAccount) {
      return getUserRecentlyViewedUrls(appkey, userAccount);
    }
    return [];
  }

  /**
   * 设置最近浏览记录链接，数组结构。会触发 set-recently-view-url 事件
   * @param content CollectedUrl[]
   * @param account 可选配置，自定义账号
   */
  setRecentlyViewedUrl({
    content,
    account,
  }: {
    content: CollectedUrl[];
    account?: string;
  }) {
    const appkey = this.getAppInfo()?.appkey;
    const userAccount = account || this.getUserInfo()?.account;
    const handleContent = (content || []).filter((item) => {
      return item.url && item.title;
    });
    if (appkey && userAccount) {
      setUserRecentlyViewedUrl(appkey, userAccount, handleContent);
      eventEmitter.emit(
        'set-recently-view-url',
        getUserRecentlyViewedUrls(appkey, userAccount)
      );
    }
  }

  /**
   * 获取路由切换时接口返回的提示信息,在header展示
   * @returns string
   */
  getPageTipsInfo(): any {
    return this._pageTips;
  }

  /**
   * 设置路由切换时接口返回的提示信息,在header展示
   * @param pageTips string
   */
  setPageTipsInfo(pageTips: string) {
    this._pageTips = pageTips;
    this._emitWatcher('PAGE_TIPS_INFO', pageTips);
  }

  /**
   * 监听路由切换时接口返回的提示信息变化,在header展示
   * @param callback 回调函数
   * @returns
   */
  watchPageTipsInfo(callback: PageTipsInfoCallback): UnWatchFn {
    return this._setWatcher('PAGE_TIPS_INFO', callback);
  }

  /**
   * 设置监听器。在extraAPI里如果需要的话，可以调用
   * @param key 监听标识
   * @param callback 监听回调
   * @returns unwatch函数
   */
  private _setWatcher(key: string, callback: (a: any) => void) {
    this._watchers[key] = this._watchers[key] || [];
    this._watchers[key].push(callback);
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const _this = this;
    return function() {
      const idx = _this._watchers[key].findIndex(callback);
      if (idx > -1) {
        _this._watchers[key].splice(idx, 1);
      }
    };
  }

  /**
   * 触发回调时间。在extraAPI里如果需要的话，可以调用
   * @param key 监听标识
   * @param params 毁掉参数
   */
  private _emitWatcher(key: string, params: any) {
    const watchers = this._watchers[key] || [];
    watchers.forEach((watcher) => {
      watcher.call(this, params);
    });
  }

  async unmountMicroApps() {
    await appContainer.unmountMicroApps();
  }

  /**
   * 加载首页
   * @param props 传入props
   * @returns
   */
  loadHomePage(props?: MicroAppProps) {
    const home = getHomePage(this._appConfig);
    home.props = {
      ...(home.props || {}),
      ...(props || {}),
    };
    this.loadMicroApp(home);
  }
  /**
   * 加载无权限页面
   * @param props 传入props
   * @returns
   */
  loadUnauthorizedPage(props?: MicroAppProps) {
    const unauthorized = getUnauthorizedPage(this._appConfig);
    unauthorized.props = {
      ...(unauthorized.props || {}),
      ...(props || {}),
    };
    this.loadMicroApp(unauthorized);
  }
  /**
   * 加载404页面
   * @param props 传入props
   * @returns
   */
  loadNotFoundPage(props?: MicroAppProps) {
    const notfound = getNotfoundPage(this._appConfig);
    notfound.props = {
      ...(notfound.props || {}),
      ...(props || {}),
    };
    this.loadMicroApp(notfound);
  }
  /**
   * 加载通用异常页面
   * @param props 传入props
   * @returns
   */
  loadErrorPage(props?: MicroAppProps) {
    const error = getErrorPage(this._appConfig);
    error.props = {
      ...(error.props || {}),
      ...(props || {}),
    };
    this.loadMicroApp(error);
  }
}
