import { loadMicroApp as loadMicroAppByQiankun, start } from '@kl/qiankun';
import { addTimeStamp } from '../utils/url';
import { MicroApp } from '@/types';
import { createElement } from '@/utils';
import { getBridgeValue } from '../utils/bridge';
import raptor from './raptor';
import loadFailAssets from '../assets/template/loadFail.html';

interface MicroAppConfig extends MicroApp {
  container: string;
}

const fetchCache: {
  [key: string]: number;
} = {};

function isEntry(url: string): boolean {
  return /\.html(\?|$)/.test(url);
}

async function fetchFn(
  input: RequestInfo,
  init?: RequestInit | undefined
): Promise<any> {
  const url: string = input as string;
  try {
    let req = input;
    if (typeof input === 'string' && isEntry(input)) {
      // 兼容RequestInfo type
      req = addTimeStamp(input);
    }
    const resp = await window.fetch(req, init);
    if (resp.ok) {
      delete fetchCache[url];
    } else {
      throw new Error('failed to fetch');
    }
    return resp;
  } catch (err) {
    if (
      err?.message === 'failed to fetch' ||
      err?.message.toLowerCase().indexOf('failed to fetch') !== -1
    ) {
      if (typeof fetchCache[url] === 'undefined') {
        // 首次
        fetchCache[url] = 1;
      }
      return retry(input, init);
    }
    return err;
  }
}
async function retry(
  input: RequestInfo,
  init?: RequestInit | undefined
): Promise<any> {
  const url: string = input as string;
  const count = fetchCache[url];
  // eslint-disable-next-line no-console
  console.warn(`${url}第${count}次重试`);
  let MAX_RETRY_COUNT = 2;
  if (isEntry(url)) {
    // entry 文件，重试3次
    MAX_RETRY_COUNT = 3;
  }
  if (count < MAX_RETRY_COUNT) {
    fetchCache[url]++;
    return fetchFn(input, init);
  } else {
    delete fetchCache[url];
    const msg = `[systemless-host-app]子应用${
      isEntry(url) ? '入口' : '资源'
    }[${url}]加载失败`;
    // eslint-disable-next-line no-console
    console.warn(msg);
    if (isEntry(url)) {
      // 如果微应用入口加载失败，默认展示失败页。入口资源保持JSError，为了触发告警
      raptor.addJsError(msg);
      return new Response(loadFailAssets, {
        status: 200,
        statusText: 'OK',
      });
    } else {
      // 如果是其他资源加载失败，正常上报
      throw new Error(msg);
    }
  }
}

export default {
  startApp() {
    // 屏蔽掉single-spa中对pushState和replaceState的拦截重定向  https://single-spa.js.org/docs/api#start
    // 注意： 该方法必须在history库调用createBrowserHistory之前执行，因为 history createBrowserHistory 中会判断当前state，自动触发一次replaceState，如果 start在createBrowserHistory之后的话，会多导致一次刷新
    // 过程为： createBrowserHistory() -> replaceState -> singleSpa reroute -> dispatchPopstateEvent -> history.listener
    start({
      urlRerouteOnly: false,
      fetch: fetchFn,
    });
    // addGlobalUncaughtErrorHandler((event) => {
    //   errorLog('qiankun执行异常', event);
    //   // TODO: 关闭qiankun执行异常
    //   // raptor.addJsError(event as string);
    // });
  },
  async loadMicroApp(options: MicroAppConfig) {
    if (options.iframe) {
      return this.loadAppByIframe(options);
    }
    return loadMicroAppByQiankun(
      {
        ...options,
      },
      {
        // 不支持跨域，白名单配置
        excludeAssetFilter(assetUrl: string) {
          const excludeAssets = options.configuration?.excludeAssets || [];
          return !!excludeAssets
            .map((str) => new RegExp(str))
            .find((reg) => reg.test(assetUrl));
        },
        // 默认设置样式隔离，如果关闭样式隔离，则采用普通沙箱
        sandbox: options.configuration?.styleIsolation
          ? {
              experimentalStyleIsolation: true,
            }
          : true,
        fetch: fetchFn,
      }
    );
  },
  async loadAppByIframe(options: MicroAppConfig) {
    // TODO: 调整API在基座应用内部的流转接入方式
    const api = getBridgeValue('api');
    let src = options.iframeSrc || options.entry;
    // 如果定义了 iframeSrc 转化函数，进行调用转化
    if (
      api?.transformIframeSrc &&
      typeof api.transformIframeSrc === 'function'
    ) {
      src = api.transformIframeSrc(src);
    }
    if (options.props) {
      // TODO: props为了兼容
      const qs = `__props__=${encodeURIComponent(
        JSON.stringify(options.props)
      )}`;
      src = src.indexOf('?') === -1 ? `${src}?${qs}` : `${src}&${qs}`;
    }
    const iframe = createElement('iframe', {
      src,
      frameBorder: 0,
      allowFullscreen: true,
      width: '100%',
      height: '100%',
    });
    iframe.dataset.STATUS = 'NOT_LOADED';
    const containerEl = document.querySelector(options.container);

    function onMessage(events: MessageEvent) {
      if (api._onIframeMessageCallback) {
        api._onIframeMessageCallback(events);
      }
    }

    return new Promise((resolve) => {
      function onLoad() {
        iframe.dataset.STATUS = 'MOUNTED';
        window.addEventListener('message', onMessage, false);
        resolve({
          getStatus: () => iframe.dataset.STATUS,
          mountPromise: Promise.resolve(),
          async unmount() {
            iframe.dataset.STATUS = 'UNMOUNTING';
            iframe.remove();
            window.removeEventListener('message', onMessage);
          },
        });
      }
      iframe.onload = onLoad;
      iframe.dataset.STATUS = 'MOUNTING';
      containerEl?.appendChild(iframe);
    });
  },
};
