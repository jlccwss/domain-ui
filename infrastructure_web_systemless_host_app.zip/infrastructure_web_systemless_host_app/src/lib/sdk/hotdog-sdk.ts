export interface HotdogOptions {
  appkey: string;
  env: string;
}

export function initHotdogSdk (options: HotdogOptions) {
  if (window.hotdog) {
    window.hotdog.start({
      appkey: options.appkey,
      isRecordCanvas: true, // 是否需要开启canvas录制， 默认为false
      devMode: !(options.env === 'production' || options.env === 'staging')
    });
  }
}
