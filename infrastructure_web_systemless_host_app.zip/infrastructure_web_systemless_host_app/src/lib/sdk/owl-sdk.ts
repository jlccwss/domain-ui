import { createElement } from '@/utils';
import appContainer from '../../appContainer';
import { UserInfo } from '../OpenApi';
import { version } from '../../../package.json';

function getUserInfo(): UserInfo | null | undefined {
  return appContainer._api?.getUserInfo();
}

export interface OwlOptions {
  project: string;
  version: string;
  env: string;
  devMode?: boolean;
  excludeResourceError?: string[] | string;
  excludeJsError?:
    | string[]
    | string
    | {
        excludes: string[] | string;
        level: null | 'debug' | 'info';
      };
}

function toReg(str: string) {
  return new RegExp(str);
}

function matchRegs(regs: RegExp[], str: string) {
  return regs.some((reg) => reg.test(str));
}

/**
 * 将子应用资源加载失败由 jsError 变为 resourceError
 * @param errorModel 异常
 * @returns 异常
 */
function parseMicroAppResourceError(errorModel: any) {
  if (
    errorModel?.sec_category?.match(
      /\[systemless-host-app\]子应用资源(.+)加载失败/
    )
  ) {
    errorModel.category = 'resourceError';
  }
  return errorModel;
}

/**
 * 因raptor脚本加载是异步的，所以在加载到脚本之前，先mock raptor的方法，缓存调用参数，待raptor脚本资源加载成功之后，从缓存获取，再上报
 */
const cacheLogs: {
  [key in RaptorMethods]: any[];
} = {
  addJsError: [],
  addApiError: [],
  addResourceError: [],
  addApiWarn: [],
  addInfo: [],
  addMetric: [],
  setPageKey: [],
  setPush: [],
  vueSetUp: [],
};
export function initOwlSdk(options: OwlOptions) {
  window.raptor = {
    addJsError: function(...args) {
      cacheLogs.addJsError.push(args);
    },
    addApiError: function(...args) {
      cacheLogs.addApiError.push(args);
    },
    addResourceError: function(...args) {
      cacheLogs.addResourceError.push(args);
    },
    addApiWarn: function(...args) {
      cacheLogs.addApiWarn.push(args);
    },
    addInfo: function(...args) {
      cacheLogs.addInfo.push(args);
    },
    addMetric: function(...args) {
      cacheLogs.addMetric.push(args);
    },
    setPageKey: function(...args) {
      cacheLogs.setPageKey.push(args);
    },
    setPush: function(...args) {
      cacheLogs.setPush.push(args);
    },
    vueSetUp: function(...args) {
      cacheLogs.vueSetUp.push(args);
    },
  };
  window.klOwlConfig = {
    project: options.project,
    webVersion: options.version,
    runtimeEnv: options.env,
    devMode: options.devMode,
  };
  const raptorJs = createElement('script', {
    crossorigin: 'anonymous',
    src:
      'https://s3.meituan.net/v1/mss_eb9ea9cfff9840198c3ae909b17b4270/production/owl/klfe-web.js',
  });
  document.querySelector('head')?.appendChild(raptorJs);
  raptorJs.onload = function() {
    Object.keys(cacheLogs).forEach((key: string) => {
      cacheLogs[key as RaptorMethods].forEach((args: [any, any, any]) => {
        window.raptor?.[key as RaptorMethods](...args);
      });
    });
    window.raptor?.setPush({
      baseTags: () => {
        const user = getUserInfo();
        return {
          userName: user ? user.name : null,
          userId: user ? user.account : null,
          hostAppVersion: version, // 基座应用版本
        };
      },
      // 异常模型 ErrorModel：https://km.sankuai.com/custom/onecloud/page/282527175#id-%E5%BC%82%E5%B8%B8%E6%A8%A1%E5%9E%8BErrorModel
      onErrorPush(instance: any) {
        instance = parseMicroAppResourceError(instance);
        let regs: RegExp[] = [];
        let excludes: string[] = [];
        let level: string | null = '';
        if (
          typeof options.excludeJsError === 'string' ||
          Array.isArray(options.excludeJsError)
        ) {
          excludes = excludes.concat(options.excludeJsError);
          level = 'debug'; // 默认降级为debug
        } else if (options.excludeJsError?.excludes) {
          excludes = excludes.concat(options.excludeJsError?.excludes);
          level = options.excludeJsError.level;
        }
        regs = excludes.map(toReg);
        if (
          instance &&
          instance.sec_category &&
          regs.length &&
          matchRegs(regs, instance.sec_category)
        ) {
          if (level) {
            instance.level = level;
          } else {
            return; // 如果level设置为null，表示不上报
          }
        }
        return instance;
      },
      // 资源模型 ResourceModel https://km.sankuai.com/custom/onecloud/page/282527175#id-%E8%B5%84%E6%BA%90%E6%A8%A1%E5%9E%8BResourceModel
      onBatchPush: (instance: any) => {
        // 过滤特定资源上报
        if (options.excludeResourceError) {
          let configs: string[] = [];
          configs = configs.concat(options.excludeResourceError);
          const regs: RegExp[] = configs.map(toReg);

          if (matchRegs(regs, instance.resourceUrl)) {
            return;
          }
        }

        return instance;
      },
    });
  };
}
