import { createElement } from '@/utils';

interface KnbOptions {
  version?: string;
}

const defaultVersion = '1.8.3';

export async function initKnbSdk(options: KnbOptions | boolean): Promise<void> {
  let version = '';
  if (typeof options === 'boolean') {
    if (!options) {
      return;
    }
    version = defaultVersion;
  } else {
    version = options.version || defaultVersion;
  }
  const knbScript = createElement('script', {
    crossorigin: 'anonymous',
    src: `https://s0.meituan.net/bs/knb/v${version}/knb.js`,
  });
  let isLoad = false;
  return new Promise((resolve, reject) => {
    document.querySelector('head')?.appendChild(knbScript);
    knbScript.onload = function() {
      isLoad = true;
      resolve();
    };
    setTimeout(() => {
      // 5s延时判断，如果超出5s未加载，视为失败
      if (isLoad) {
        return;
      }
      reject();
    }, 5000);
  });
}
