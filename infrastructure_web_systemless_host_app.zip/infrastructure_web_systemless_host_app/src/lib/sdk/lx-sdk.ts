import { createElement } from '@/utils';

export interface LxOptions {
  category: string;
  appnm: string;
}
export function initLxSdk (options: LxOptions) {
  const els = [
    createElement('meta', {
      name: 'lx:category',
      content: options.category
    }),
    createElement('meta', {
      name: 'lx:appnm',
      content: options.appnm
    }),
    createElement('meta', {
      name: 'lx:native-report',
      content: 'off'
    }),
    createElement('meta', {
      name: 'lx:autopv',
      content: 'off'
    }),
    createElement('script', {
      type: 'text/javascript',
      charset: 'utf-8',
      src: '//analytics.meituan.net/analytics.js'
    })
  ];
  const head = document.querySelector('head');
  els.forEach((el) => {
    head?.appendChild(el);
  });
}
