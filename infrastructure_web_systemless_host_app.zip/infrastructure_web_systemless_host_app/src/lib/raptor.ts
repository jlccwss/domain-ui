interface Tags {
  [key: string]: any;
}
const raptor: Raptor = {
  addResourceError(err: string | Error, tags?: Tags) {
    if (window.raptor) {
      window.raptor.addResourceError(err, tags);
    }
  },
  addApiError(err: string | Error, tags?: Tags) {
    if (window.raptor) {
      window.raptor.addApiError(err, tags);
    }
  },
  addJsError(err: string | Error, tags?: Tags) {
    if (window.raptor) {
      window.raptor.addJsError(err, tags);
    }
  },
  setPageKey() {
    if (window.raptor) {
      window.raptor.setPageKey();
    }
  },
  addApiWarn(err: Error | string, tags?: RaptorTags) {
    if (window.raptor) {
      window.raptor.addApiWarn(err, tags);
    }
  },
  addInfo(err: Error | string, tags?: RaptorTags) {
    if (window.raptor) {
      window.raptor.addInfo(err, tags);
    }
  },
  addMetric(
    metricKey: string,
    tagObj: { [key: string]: number | string },
    value: number
  ) {
    if (window.raptor) {
      window.raptor.addMetric(metricKey, tagObj, value);
    }
  },
  setPush(params) {
    if (window.raptor) {
      window.raptor.setPush(params);
    }
  },
  vueSetUp(params) {
    if (window.raptor) {
      window.raptor.vueSetUp(params);
    }
  },
};
export default raptor;
