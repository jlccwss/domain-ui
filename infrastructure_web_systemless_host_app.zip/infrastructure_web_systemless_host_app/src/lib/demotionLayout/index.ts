/**
 * 自定义布局加载失败时，加载这个降级布局，保障微应用可以正常加载
 */
export const name = 'systemless-demotion-layout';
export const container = '#systemless-demotion-layout_app-container';
export const slots = {};

let layoutEl: HTMLElement | null = null;
export function mount (target: HTMLElement) {
  const template = '<div id="systemless-demotion-layout_app-container"></div>';
  const div = document.createElement('div');
  div.innerHTML = template;
  layoutEl = div;
  target.appendChild(div);
}
export function unmount () {
  if (layoutEl) {
    layoutEl.remove();
  }
}
