import {
  request,
  getSystemInfo,
  getErrorElement,
  initLogan,
  errorLog,
  startUpdateChecker,
  pureHostName,
  createElement,
} from './utils';

import { initOwlSdk, initLxSdk, initHotdogSdk } from '@/lib/sdk';
import { initBridge } from './utils/bridge';
import {
  getAppStorageConfig,
  setAppStorageConfig,
  setLoopUser,
  getLoopUser,
} from './utils/storage';
import appContainer from './appContainer';
import './style.scss';
import { DEFAULT_ROOT_ID } from './constants';
import { AppConfig, MicroApp } from './types';
import { PagePreventLoopPlugin } from './utils/prevent-loop';
import raptor from './lib/raptor';
import { validAppConfig } from './utils/validator';
import { initKnbSdk } from './lib/sdk/knb';
import { closeDebugMode } from './utils/debug-mode';
import { checkMemory, setReportMemoryUserAccount } from './utils/memory';

const root = document.querySelector(`#${DEFAULT_ROOT_ID}`);
let lastAppConfig: AppConfig | null = null;
let isWebInLoopTriggered = false; // 无限循环

// FIXME: 为了兼容合作商门户基座老逻辑，后续要下线。
// 影响模块：合作商门户合同管理接入yoda模块
window._RAW_WINDOW_FOR_QIANKUN_ = window;

// 运行在基座中的标记
window._POWERED_BY_SYSTEMLESS_HOST_APP_ = true;

bootstrap();

// 获取应用标识
async function bootstrap() {
  const { swimlane, env, debugMode } = getSystemInfo();

  initLogan({
    env,
  });

  // 初始化桥接实例
  initBridge();

  let res = null;
  try {
    res = await request({
      // 兼容 路径为 //app/index 的情况
      url: `${location.pathname.replace(/^(\/+)/, '/')}${location.search}`,
    });
  } catch (e) {
    showErrorPage(400, '获取应用appkey失败，请稍后刷新页面重试');
  }
  if (res) {
    const { xhr } = res;
    let appkey: string | null | undefined =
      xhr.getResponseHeader('X-App-Key') || xhr.getResponseHeader('x-app-key');
    // 避免重复设置header，重复设置的时候会返回逗号拼接的字符串
    appkey = appkey?.split(',')[0];
    if (appkey) {
      await getAppConfigAndStartApp({
        swimlane,
        env,
        appkey,
        debugMode,
      });
      // 启动更新检查
      startUpdateChecker({
        initialAppConfig: lastAppConfig,
        appContainer: appContainer,
        configFetcher: async function() {
          let appConfig = null;
          try {
            appConfig = await fetchAppConfig({
              swimlane,
              env,
              appkey: appkey!,
              debugMode: debugMode,
            });
          } catch (e) {}
          return appConfig;
        },
      });
    } else {
      showErrorPage(400, '当前应用未配置appkey，请检查Oceanus配置是否正确！');
    }
  }
}

/**
 * 根据不同环境，获取配置URL的portm地址
 * @param env {string} 环境标识
 * @returns {string}
 */
function getConfigUrl(env: string) {
  const urlMap: {
    [key: string]: string;
  } = {
    development:
      '//portal-portm.meituan.com/klfe/systemless/development/getAppConfig',
    test: '//portal-portm.meituan.com/klfe/systemless/test/getAppConfig',
    staging: '//portal-portm.meituan.com/klfe/systemless/staging/getAppConfig',
    production:
      '//portal-portm.meituan.com/klfe/systemless/production/getAppConfig',
  };
  // 如果是命令行启动，则进行代理
  if (process.env.BUILD_TARGET === 'bin') {
    return '/getAppConfig';
  }
  return urlMap[env] || urlMap.development;
}

async function fetchAppConfig(params: {
  appkey: string;
  swimlane: string;
  env: string;
  debugMode: boolean;
}) {
  const url = getConfigUrl(params.env);
  const res = await request({
    url,
    data: {
      appkey: params.appkey,
      swimlane: params.swimlane,
      env: params.env,
      hostname: pureHostName(),
      debugMode: params.debugMode,
    },
  });
  const {
    data: { data, error },
  } = res;
  if (error) {
    raptor.addResourceError(new Error(error.message || '配置加载失败'), {
      appkey: params.appkey,
      swimlane: params.swimlane,
      env: params.env,
      hostname: pureHostName(),
    });
    throw new Error(`${error.code} - ${error.message}`);
  }
  return formatAppConfig(data);
}

function formatAppConfig(appConfig: any): AppConfig {
  if (appConfig['404']) {
    appConfig['404'] =
      typeof appConfig['404'] === 'string'
        ? ({
            entry: appConfig['404'],
            name: '404-page',
          } as MicroApp)
        : appConfig['404'];
  }
  if (appConfig.home) {
    appConfig.home =
      typeof appConfig.home === 'string'
        ? ({
            entry: appConfig.home,
            name: 'home-page',
          } as MicroApp)
        : appConfig.home;
  }
  return appConfig;
}

/**
 * 获取系统配置
 * @param params
 */
async function getAppConfigAndStartApp(params: {
  appkey: string;
  swimlane: string;
  env: string;
  debugMode: boolean;
}) {
  let data = null;
  // 启动时获取配置时，如果获取成功，更新storage缓存，如果获取失败，读取缓存
  const storage = getAppStorageConfig(params.appkey);
  try {
    data = await fetchAppConfig(params);
    if (params.debugMode) {
      // 展示debug模式提示
      showDebugModeTips();
    } else {
      setAppStorageConfig(params.appkey, data); // 不缓存调试模式的配置
    }
  } catch (error) {
    raptor.addResourceError(error.message);
    if (storage) {
      // 在应用配置加载失败的时候，如果有上一次的缓存，则使用缓存
      data = storage;
      // eslint-disable-next-line no-console
      console.warn(
        `本次配置加载失败，使用缓存配置，缓存配置版本为${storage.version}`
      );
    } else {
      // eslint-disable-next-line no-console
      console.warn(error.message);
      showErrorPage(
        400,
        error.message || '应用配置获取失败，请检查配置文件是否正常'
      );
    }
  }
  if (data) {
    const config: AppConfig = data;
    if (config) {
      lastAppConfig = config;
      document.title = config.appName;
      config.favicon && replaceFavicon(config.favicon);
      // 初始化灵犀SDK
      config.sdk?.lx && initLxSdk(config.sdk.lx);
      // 初始化Owl SDK
      initOwlSdk({
        project: config.sdk?.owl?.project || config.appkey,
        version: config.version,
        env: params.env,
        excludeResourceError: config.sdk?.owl?.excludeResourceError,
        excludeJsError: config.sdk?.owl?.excludeJsError,
        devMode: config.sdk?.owl?.devMode,
      });
      if (config.sdk?.knb) {
        try {
          await initKnbSdk(config.sdk.knb);
        } catch (e) {
          raptor.addResourceError('KNB加载失败', {
            option: config.sdk?.knb,
          });
        }
      }
      // 可手动关闭hotdog
      if (!config.sdk?.hotdog?.disable) {
        initHotdogSdk({
          appkey: config.appkey,
          env: params.env,
        });
      }

      if (config?.sdk?.preventLoop) {
        const res = PagePreventLoopPlugin.logReloadChange();
        if (res) {
          raptor.addResourceError('站点间无限循环跳转', {
            appkey: config.appkey,
            env: params.env,
            user: getLoopUser(),
          });
          showErrorPage(
            400,
            '您命中了站点间无限循环，请反馈给管理员进行排查。'
          );
          return;
        }
      }

      appContainer.onPopState(() => {
        if (config.sdk?.preventLoop) {
          if (isWebInLoopTriggered) {
            return false;
          } else {
            const res = PagePreventLoopPlugin.logRouterChange();
            if (res) {
              isWebInLoopTriggered = true;
              raptor.addResourceError('站点内无限循环跳转');
              showErrorPage(
                400,
                '您命中了站点内无限循环，请反馈给管理员进行排查。'
              );
              return false;
            } else {
              return true;
            }
          }
        } else {
          return true;
        }
      });

      // 在启动之前做校验判断，上报结果
      const errors = validAppConfig(config);
      if (errors.length) {
        errors.forEach((error) => {
          raptor.addResourceError(error.name, error.content);
        });
      }

      // 启动应用
      appContainer
        .start(config)
        .then(() => {
          hideLoading();
          // 如果没有命中无限刷新，可以把账号记录下来，且每次更新，待下一次触发站点间无限刷新时，进行上报，便于追踪
          appContainer._api?.watchUserInfo((user) => {
            setLoopUser(user.name);
            setReportMemoryUserAccount(user.account);
          });
          checkMemory(raptor);
        })
        .catch((error) => {
          // eslint-disable-next-line no-console
          console.error(error);
          raptor.addJsError(error);
          showErrorPage(400, '系统加载异常，请检查网络环境并稍后重试');
        });
    } else {
      showErrorPage(400, '应用配置解析失败，请检查配置文件是否正常');
    }
  }
}

/**
 * 展示错误页面
 * @param code 错误码
 * @param message 错误信息
 */
function showErrorPage(code: number, message: string) {
  hideLoading();
  const el = getErrorElement(code, message);
  root?.appendChild(el);
  errorLog(message, code);
}

/**
 * 展示debugMode提示
 */
function showDebugModeTips() {
  const btn = createElement(
    'span',
    {
      style: 'cursor: pointer;',
    },
    '【关闭】'
  );
  const tips = createElement(
    'div',
    {
      style: `position: fixed;top: 0;left: 0;z-index: 3000;background: red;color: #fff;font-size: 12px;`,
    },
    [createElement('span', {}, '调试模式'), btn]
  );
  btn.addEventListener('click', () => {
    closeDebugMode();
    window.location.reload();
  });
  document.body.appendChild(tips);
}

/**
 * 替换 favicon
 * @param icon favicon地址
 */
function replaceFavicon(icon: string) {
  const faviconEl = document.querySelector('#favicon');
  faviconEl?.setAttribute('href', icon);
}
/**
 * 隐藏加载图标
 */
function hideLoading() {
  document.querySelector('#page-loading')?.remove();
}
