export const PREFIX = 'SYSTEMLESS';

export const AFTER_INIT = 'AFTER_INIT';
export const BEFORE_APP_CHANGE = 'BEFORE_APP_CHANGE';
export const AFTER_APP_CHANGE = 'AFTER_APP_CHANGE';

export const LAYOUT_CONTAINER_ID = 'host-app_layout-container';
export const DEFAULT_ROOT_ID = 'host-app-root-el';

export const GLOBAL_VALUES_BRIDGE = '_GLOBAL_VALUES_BRIDGE_';

export const SESSION_STORAGE_KEY = '_site_edition_';
