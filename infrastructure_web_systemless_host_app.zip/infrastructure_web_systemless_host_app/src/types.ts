/**
 * 定义通用TS类型
 */

export type EnvType = 'development' | 'test' | 'staging' | 'production';
export interface SlotOptions {
  [key: string]: any;
}
// 插槽
export interface Slot {
  target: string;
  script: string;
  style?: string;
  options?: SlotOptions;
}

export interface LayoutOptions {
  [key: string]: any;
}
// 系统布局
export interface Layout {
  name: string;
  script: string;
  style?: string;
  slots?: Slot[];
  options?: LayoutOptions;
}

// 主题配置
export interface Theme {
  [key: string]: string;
}

// 插件配置
export type PluginStep =
  | 'AFTER_INIT'
  | 'BEFORE_APP_CHANGE'
  | 'AFTER_APP_CHANGE';
export interface PluginOptions {
  [key: string]: string;
}
export interface AppPlugin {
  script: string;
  options?: PluginOptions;
}
export interface PluginGroup {
  name?: string;
  step: PluginStep;
  list: AppPlugin[];
}
export interface MicroAppProps {
  [key: string]: string;
}
export interface MicroAppConfiguration {
  excludeAssets?: string[];
  styleIsolation?: boolean;
}
// 通用页面
export interface CommonPage {
  entry: string;
  layout?: Layout;
  plugins?: PluginGroup[];
  props?: MicroAppProps;
}

// 微应用
export interface MicroApp extends CommonPage {
  name: string;
  url: string;
  iframe?: boolean;
  iframeSrc?: string;
  configuration?: MicroAppConfiguration;
}
export type CommonPageEnum = 'home' | 'unauthorized' | 'notfound' | 'error';
export interface AppConfig {
  appName: string;
  version: string;
  appkey: string;
  404: MicroApp | string;
  home: MicroApp | string;
  layout: Layout;
  theme?: Theme;
  apps: MicroApp[];
  plugins?: PluginGroup[];
  extraApi: string;
  favicon?: string;
  commonPages?: {
    [name in CommonPageEnum]: string | MicroApp;
  };
  sdk?: {
    lx?: {
      category: string;
      appnm: string;
    };
    owl?: {
      project: string;
      excludeResourceError?: string[] | string;
      excludeJsError?:
        | string[]
        | string
        | {
            excludes: string[] | string;
            level: null | 'debug' | 'info';
          };
      autoPv?: boolean;
      devMode?: boolean;
    };
    preventLoop?: boolean;
    hotdog?: {
      disable?: boolean;
    };
    knb?:
      | boolean
      | {
          version?: string;
        };
  };
}
