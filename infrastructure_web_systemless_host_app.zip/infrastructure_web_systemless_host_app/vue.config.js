module.exports = {
  crossorigin: "anonymous",
  outputDir: process.env.BUILD_TARGET === 'bin' ? 'dist' : 'build',
  publicPath: process.env.PUBLIC_URL || '/',
  lintOnSave: false,
  chainWebpack: config => {
    config
      .plugin('@@inject-app-release-variables')
      .use('webpack/lib/DefinePlugin', [
        {
          'process.env.RUNTIME_ENV': JSON.stringify(process.env.RUNTIME_ENV),
          'process.env.BUILD_TARGET': JSON.stringify(process.env.BUILD_TARGET),
          'process.env.DEBUG': JSON.stringify(process.env.DEBUG)
        }
      ]);

    config.module
      .rule('ico')
      .test(/\.ico$/)
      .use('url-loader')
      .loader('url-loader')
      .options({
        limit: 1,
        fallback: {
          loader: 'file-loader',
          options: {
            name: 'img/[name].[hash:8].[ext]'
          }
        }
      });
    config.module
      .rule('html')
      .test(/\.html$/)
      .use('html-loader')
      .loader('html-loader')
      .options({
        minimize: false,
        attrs: ['img:src', 'link:href']
      });
  },
  devServer: {
    port: 3000,
    disableHostCheck: true,
    host: '0.0.0.0',
    headers: {
      'X-App-Key': 'admin-mock'
    },
    proxy: {
      '^/(?!app)(?!sockjs-node/)': {
        logLevel: 'silent',
        logLevel: 'silent',
        target: 'http://kladmin.bb.test.sankuai.com',
        xfwd: false // x-forward header matters
      }
    }
  }
};
