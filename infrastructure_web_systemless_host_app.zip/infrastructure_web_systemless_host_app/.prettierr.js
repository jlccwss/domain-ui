const recommended = require('@kl/eslint-config-recommended/prettierrc');
module.exports = {
  ...recommended
};