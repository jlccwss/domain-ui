declare module '*.css';
declare module '*.scss';
declare module '*.png';
declare module '*.html';
declare module 'js-md5' {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  export default jsMd5 = (str: string) => string;
}

interface RaptorTags {
  [key: string]: any;
}
type RaptorMethods =
  | 'addResourceError'
  | 'addApiError'
  | 'addJsError'
  | 'addApiWarn'
  | 'addApiWarn'
  | 'addInfo'
  | 'addMetric'
  | 'setPageKey'
  | 'setPush'
  | 'vueSetUp';
interface Raptor {
  addResourceError: (err: Error | string, tags?: RaptorTags) => void;
  addApiError: (err: Error | string, tags?: RaptorTags) => void;
  addJsError: (err: Error | string, tags?: RaptorTags) => void;
  addApiWarn: (err: Error | string, tags?: RaptorTags) => void;
  addInfo: (err: Error | string, tags?: RaptorTags) => void;
  addMetric: (
    metricKey: string,
    tagObj: { [key: string]: number | string },
    value: number
  ) => void;
  setPageKey: (pageKey?: string) => void;
  setPush: (params: {
    baseTags: () => { [key: string]: any };
    onErrorPush?: (p: any) => any;
    onBatchPush?: (p: any) => any;
  }) => void;
  vueSetUp: (params: any) => void;
}
interface Window {
  raptor: Raptor | undefined;
  klOwlConfig: {
    project: string;
    webVersion: string;
    runtimeEnv: string;
    devMode?: boolean;
  };
  hotdog: any;
  _GLOBAL_VALUES_BRIDGE_: {
    [key: string]: any;
  };
  _RAW_WINDOW_FOR_QIANKUN_: Window;
  _POWERED_BY_SYSTEMLESS_HOST_APP_: boolean;
}
interface Performance {
  memory?: {
    jsHeapSizeLimit: number;
    totalJSHeapSize: number;
    usedJSHeapSize: number;
  };
}
