
##概述
1、所有项目的所有权继承于客户
2、管理员登录,能看到所有,操作所有
3、销售登录,不能分配客户,不能看其他人客户和项目,看不到账号菜单
4、非销售用户登录,只能看自己相关的项目,协作人可以编辑项目进度和自己部门的工时,账号和客户菜单不可见

所有接口的格式为json,所有业务接口均返回HTTP 200 ok,业务结果返回分两大类：
status为内部错误码,0代表没错误,返回数据在data中。非0时错误信息在msg中。
1、接口如果没有发生错误,结果返回举例：
{"status":0, "msg":"success",”data”:[{},{}]}
2、接口如果发生错误,status值不为0,错误信息在msg中进行提示,样例如下：
{"status":400, "msg":"hello world!!!",”data”:null}

关于批量删除和分配
批量都由前端一个接口一个接口的调用，遇到失败停止并提示错误
##用户接口
#login
POST /apis/account/login
{"username":"", "passwd":""}
username：字母、数字、下划线、邮箱
passwd：最短6个字符,最长24,明文传输,调试完成会改成https传输

#获取权限接口
1.系统分为3个角色,admin、xiaoshou、xiezuo
2.管理员登录,能看到所有,操作所有
3.销售登录,不能分配客户,不能看其他人客户和项目,看不到账号菜单
4.非销售用户登录,只能看自己相关的项目,协作人可以编辑项目进度和自己部门的工时,账号和客户菜单不可见
GET /apis/account/role

Response：
{"role":"admin"}

#changepwd
PUT /apis/account/passwd
{"id":1,"oldpasswd":"","newpasswd":""}

#list
GET /apis/account/users
Response
{"status":0, "msg":"success","data":[{}]}

data包含的字段为
id:string
name:string
mobile:string
department:string
updateTime:string
createTime:string
#list owners
GET /apis/account/owners
Response
{"status":0, "msg":"success","data":[{}]}

data包含的字段为
id:string
name:string
mobile:string
department:string
updateTime:string
createTime:string
#add
POST /apis/account/user
{ "id":"", "name":"string", "mobile":"string", "department":"string", "passwd":""}
新增是id传不传都可以,传的话就为空
其中department是下拉选择后,传选中的名字,见department的list接口

Response
{"status":0, "msg":"success","data":[{}]}

#mod
PUT /apis/account/user/:id
{ "id":"", "name":"string", "mobile":"string", "department":"string", "passwd":""}
其中department是下拉选择,修改时按名字匹配显示下拉框的值,见department的list接口

Response
{"status":0, "msg":"success","data":[{}]}

#del
DELETE /apis/account/user/:id
Response
{"status":0, "msg":"success","data":[{}]}

#客户接口
#list
GET /apis/customer/list
Response
{"status":0, "msg":"success","data":[{}]}

data包含的字段为
id:string
name:string
level:string          # 新建和编辑时见level的list接口
industry:string       # 新建和编辑时见industry的list接口
come:string           # 新建和编辑时见come的list接口
contactsName:string
contactsMobile:string
contactsKey:string    # 页面写死是和否两个，修改时根据内容匹配显示下拉值
address:string
owner:string          # 新建和编辑时见GET /apis/account/owners
updateTime:string
createTime:string

#add
POST /apis/customer/customer
{
name:string
level:string          # 见level的list接口
industry:string       # 见industry的list接口
come:string           # 见come的list接口
contactsName:string
contactsMobile:string
contactsKey:string    # 页面写死是和否两个，修改时根据内容匹配显示下拉值
address:string
owner:string          # 见GET /apis/account/owners
}
Response
{"status":0, "msg":"success","data":[{}]}

#mod
PUT /apis/customer/customer/:id
{
id:string
name:string
level:string          
industry:string       
come:string           
contactsName:string
contactsMobile:string
contactsKey:string    
address:string
owner:string          
updateTime:string
createTime:string
}

Response
{"status":0, "msg":"success","data":[{}]}

#del
DELETE /apis/customer/customer/:id
Response
{"status":0, "msg":"success","data":[{}]}

#move
分配接口，实际上跟修改调用的同一个接口，只不过就是换种操作只修改owner
owner只能选择一个人,和域名权限那个操作页面一样

#项目接口
#list
GET /apis/item/list
Response
{"status":0, "msg":"success","data":[{}]}

data包含的字段为
id:string
name:string
status:string         # 见status的list接口
beginTime:string      
endTime:string         
contactsName:string
budget:float
process:string
owner:string          # 新建和编辑时见GET /apis/account/owners
sync:[string,string,string] #新建和编辑时见GET /apis/account/users   
customerName:string   # 编辑和新建时见GET /apis/customer/list接口
productTime:float     
developTime:float     
supportTime:float
managerTime:float
updateTime:string
createTime:string

#add
POST /apis/item/item
{
id:string
name:string
status:string         # 见status的list接口
beginTime:string      
endTime:string         
contactsName:string
budget:float
process:string
owner:string          # 新建和编辑时见GET /apis/account/owners
sync:[string,string,string] #新建和编辑时见GET /apis/account/users   
customerName:string   # 编辑和新建时见GET /apis/customer/list接口
productTime:float     
developTime:float     
supportTime:float
managerTime:float
}
Response
{"status":0, "msg":"success","data":[{}]}

#mod
PUT /apis/itme/item/:id
{
id:string
name:string
status:string         # 见status的list接口
beginTime:string      
endTime:string         
contactsName:string
budget:float
process:string
owner:string          # 新建和编辑时见GET /apis/account/owners
sync:[string,string,string] #新建和编辑时见GET /apis/account/users   
customerName:string   # 编辑和新建时见GET /apis/customer/list接口
productTime:float     
developTime:float     
supportTime:float
managerTime:float
}

Response
{"status":0, "msg":"success","data":[{}]}

#del
DELETE /apis/item/item/:id
Response
{"status":0, "msg":"success","data":[{}]}

##资源只有list的接口
#部门接口
GET /apis/department/departments
Response
{"status":0, "msg":"success","data":[{"id":"","name":"产品部"},{"id":"","name":"市场部"}]}

#客户级别接口
GET /apis/level/levels
Response
{"status":0, "msg":"success","data":[{"id":"","name":"新建"},{"id":"","name":"重要"}]}

#客户行业接口
GET /apis/industry/industrys
Response
{"status":0, "msg":"success","data":[{"id":"","name":"金融"},{"id":"","name":"央企"}]}

#客户来源接口
GET /apis/come/comes
Response
{"status":0, "msg":"success","data":[{"id":"","name":"自己拓展"},{"id":"","name":"公司自有"}]}

#项目状态接口
GET /apis/status/statuss
Response
{"status":0, "msg":"success","data":[{"id":"","name":"需求调研"},{"id":"","name":"立项"}]}
