<template>
    <el-form label-width="120px">
      <div class="title">项目详情</div>
      <el-row>
      <el-col :span="12">
        <el-form-item prop="name" label="项目名称">
          <el-input disabled v-model="data.name"></el-input>
        </el-form-item>
      </el-col>
      </el-row>
      <el-row>
        <el-form-item prop="status" label="项目状态">
          <div class="form-row">
            <el-steps align-center :space="200" :active="data.status" finish-status="success">
              <el-step :key="proStatus.id" v-for="proStatus in proStatusList" :title="proStatus.name"></el-step>
            </el-steps>
          </div>
        </el-form-item>
      </el-row>
      <el-row>
      <el-col :span="12">
        <el-form-item prop="process" label="项目简介">
          <el-input disabled v-model="data.comment" type="textarea" rows="3" />
        </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="12">
        <el-form-item prop="process" label="项目进展">
          <el-input disabled v-model="data.process" type="textarea" rows="3" />
        </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="12">
        <el-form-item prop="beginTime" label="开始时间">
          <el-date-picker
            disabled
            class="w-full"
            v-model="data.beginTime"
            type="date"
            placeholder="选择日期">
          </el-date-picker>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item prop="endTime" label="结束时间">
          <el-date-picker
            disabled
            class="w-full"
            v-model="data.endTime"
            type="date"
            placeholder="选择日期">
          </el-date-picker>
        </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="12">
        <el-form-item prop="budget" label="项目金额">
          <el-input disabled class="w-full" v-model="data.budget">
            <template slot="append">万元</template>
          </el-input>
        </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="12">
        <el-form-item prop="owner" label="负责人">
          <el-input disabled v-model="data.ownerName"></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item prop="sync" label="协作人">
          <el-select disabled multiple class="w-full" v-model="data.sync">
            <el-option :key="user.id" v-for="user in userList" :label="user.name" :value="user.id"></el-option>
          </el-select>
        </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="24">
        <el-form-item prop="costomerId" label="客户名称">
          <el-input disabled v-model="data.customerName" />
        </el-form-item>
      </el-col>
      </el-row>
      <div class="title">项目工作量</div>
      <el-row>
      <el-col :span="12" v-if="timesAuth.includes('1')">
        <el-form-item prop="marketTime" label="营销中心">
          <el-input disabled class="w-full" v-model="data.marketTime">
            <template slot="append">人天</template>
          </el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="timesAuth.includes('4')">
        <el-form-item prop="supportTime" label="技术服务中心">
          <el-input disabled class="w-full" v-model="data.supportTime">
            <template slot="append">人天</template>
          </el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="timesAuth.includes('2')">
        <el-form-item prop="productTime" label="产品中心">
          <el-input disabled class="w-full" v-model="data.productTime">
            <template slot="append">人天</template>
          </el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="timesAuth.includes('3')">
        <el-form-item prop="developTime" label="研发中心">
          <el-input disabled class="w-full" v-model="data.developTime" >
            <template slot="append">人天</template>
          </el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="timesAuth.includes('5')">
        <el-form-item prop="managerTime" label="综合管理中心">
          <el-input disabled class="w-full" v-model="data.managerTime">
            <template slot="append">人天</template>
          </el-input>
        </el-form-item>
      </el-col>
      </el-row>
      <el-form-item>
        <el-button @click="handleClose()">取消</el-button>
      </el-form-item>
    </el-form>
</template>

<script>
import $http from '@/http';
import { getUser } from '@/user'

export default {
  data() {
    return {
      data: {},
      proStatusList: [],
      userList: [],
      customerList: [],
      disabled: false,
      timesAuth: []
    };
  },
  mounted() {
    this.getProStatusList();
    this.getUserList();
    this.getCustomerList();
    const { id } = this.$route.query;
    this.getDetail(id);
    const user = getUser();
    if (user.role === 'admin') {
      this.timesAuth = ['1', '2', '3', '4', '5'];
    } else {
      this.timesAuth = [user.department];
    }
  },
  methods: {
    getDetail(id) {
      const url = `/apis/item/item/${id}`;
      $http.get(url).then(res => {
        res.data.status = Number(res.data.status) - 1;
        this.data = res.data;
      });
    },
    getProStatusList() {
      $http.get('/apis/status/statuss').then(res => {
        if (res.data.status === 0) {
          this.proStatusList = res.data.data;
        }
      });
    },
    getUserList() {
      $http.get('/apis/account/sync').then(res => {
        if (res.data.status === 0) {
          this.userList = res.data.data;
        }
      });
    },
    getCustomerList() {
      $http.get('/apis/customer/listall').then(res => {
        if (res.data.status === 0) {
          this.customerList = res.data.data;
        }
      });
    },
    handleClose() {
      this.$router.push('/home/programMange');
    },
  }
};
</script>
<style scoped lang="scss">
.title {
  text-align: left;
  padding: 20px 10px;
}
</style>