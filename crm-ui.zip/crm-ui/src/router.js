import VueRouter from 'vue-router';
import $http from '@/http';
import authority from './home/authority';
import { setUser } from './user';

import login from './login/login.vue';
import home from './home/home.vue';
import users from './users/users.vue';
import notFound from './404/404.vue';
import customers from './customers/customers.vue';
import customerDetail from './customerDetail/customerDetail.vue';
import programMange from './programMange/programMange.vue';
import programMangeDetail from './programMangeDetail/programMangeDetail.vue';
import programMangeView from './programMangeView/programMangeDetail.vue';
import staticPage from './staticPage/staticPage.vue';

const router = new VueRouter({
  routes: [
    { path: '/', redirect: '/home/customers' },
    { path: '/login', name: 'login', component: login },
    { path: '/404', name: '404', component: notFound },
    {
      path: '/home',
      component: home,
      children: [
        {
          path: 'users',
          name: 'users',
          component: users
        },
        {
          path: 'customers',
          name: 'customers',
          component: customers
        },
        {
          path: 'customers/:id',
          name: 'customersDetail',
          component: customerDetail
        },
        {
          path: 'programMange',
          name: 'programMange',
          component: programMange
        },
        {
          path: 'test',
          name: 'test',
          component: staticPage
        },
        {
          path: 'programMange/view',
          name: 'programMangeView',
          component: programMangeView
        },
        {
          path: 'programMange/:id',
          name: 'programMangeDetail',
          component: programMangeDetail
        },
        {
          path: '404',
          name: 'home404',
          component: notFound
        },
      ]
    }
  ]
});

let getRolePromise;
function getRole() {
  if (!getRolePromise) {
    getRolePromise = $http.get('/apis/account/role');
  }
  return getRolePromise;
}

function clearRole() {
  getRolePromise = null;
}

router.beforeEach((to, from, next) => {
  if (['login', 'bigshow', '404', 'todo'].includes(to.name)) {
    next();
  } else {
    if (from.name === 'login') {
      clearRole();
    }
    getRole().then(res => {
      let user = res.data;
      setUser(user);
      let authorityArr = authority[user.role] || [];

      if (authorityArr.includes(to.name) || to.name === 'home404') {
        next();
      } else {
        if (authorityArr.length) {
          next({ name: authorityArr[0] });
        } else {
          next({ name: 'login' });
        }
      }
    }, () => {
      clearRole();
      next({ name: 'login' });
    });
  }
});

export default router;