<template>
  <el-dialog
    title="分配"
    :visible="true"
    width="60%"
    @close="handleClose">
    <el-form ref="form" label-width="100px" :rules="rules" :model="data">
      <el-form-item label="负责人" prop="owner">
        <el-select class="w-full"  v-model="data.owner">
          <el-option :key="owner.id" :label="owner.name" :value="owner.id" v-for="owner in owners"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleAssign">立即分配</el-button>
        <el-button @click="handleClose">取消</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>

<script>
import $http from '@/http';

export default {
  props: ['list'],
  data() {
    return {
      data: {},
      owners: [],
      rules: {
        owner: [
           { required: true, message: '请选择负责人', trigger: 'blur' },
        ],
      }
    };
  },
  mounted() {
    this.getOwners();
  },
  methods: {
    getOwners() {
      const url = `/apis/account/owners`;
      $http.get(url).then(res => {
        if (res.data.status === 0) {
          this.owners = res.data.data;
        }
      });
    },
    handleAssign() {
      this.$refs.form.validate(valid => {
        if (valid) {
          const ownerName = this.owners.find(item => item.id === this.data.owner).name;
          let updateList = this.list.map(item => {
            const url = `/apis/customer/customer/${item.id}`;
            const saveObj = {
              ...item,
              owner: this.data.owner,
              ownerName: ownerName
            };
            return $http.put(url, saveObj);
          });
          Promise.all(updateList).then(() => {
            this.$notify.success({
              message: '分配成功'
            });
            this.$emit('close', true);
          }, () => {
            this.$notify.error({
              message: '分配失败'
            });
          });
        }
      });
    },
    handleClose() {
      this.$emit('close');
    }
  }
};
</script>
<style scoped lang="scss">

</style>