<template>
  <el-dialog
    title="新增"
    :visible="true"
    width="60%"
    @close="handleClose">
    <el-form label-width="100px">
      <el-col :span="12">
      <el-form-item label="姓名">
        <el-input v-model="data.name"></el-input>
        <span>（公司或单位，工商注册登记名称）</span>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="客户级别">
        <el-select class="w-full"  v-model="data.l">
          <el-option label="新建" value="0"></el-option>
          <el-option label="潜在" value="1"></el-option>
          <el-option label="成交" value="2"></el-option>
          <el-option label="重要" value="3"></el-option>
        </el-select>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="行业">
        <el-select class="w-full"  v-model="data.h">
          <el-option label="金融" value="0"></el-option>
          <el-option label="政府部委" value="1"></el-option>
          <el-option label="央企" value="2"></el-option>
          <el-option label="教育" value="3"></el-option>
          <el-option label="渠道商" value="4"></el-option>
          <el-option label="其他" value="5"></el-option>
        </el-select>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="来源">
        <el-select class="w-full"  v-model="data.ly">
          <el-option label="自主开拓" value="0"></el-option>
          <el-option label="公司资源" value="1"></el-option>
        </el-select>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="联系人姓名">
        <el-input v-model="data.name"></el-input>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="联系人电话">
        <el-input v-model="data.name"></el-input>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="关键决策人">
        <el-select class="w-full"  v-model="data.ly">
          <el-option label="是" value="0"></el-option>
          <el-option label="否" value="1"></el-option>
        </el-select>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="客户地址">
        <el-input v-model="data.name"></el-input>
      </el-form-item>
      </el-col>
      <el-col :span="12">
      <el-form-item label="负责人">
        <el-input v-model="data.name"></el-input>
      </el-form-item>
      </el-col>
      <el-form-item>
        <el-button type="primary" @click="handleClose(true)">立即创建</el-button>
        <el-button @click="handleClose(false)">取消</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>

<script>
import $http from '@/http';

export default {
  props: ['data'],
  data() {
    return {
      list: [],
    };
  },
  methods: {
    handleClose(isSave) {
      if (isSave) {
        const url = '';
        $http.post(url).then(res => {
          if (res.data.status === 0) {
            this.$notify.success({
              message: '保存成功'
            });
            this.$emit('close', true);
          }
        });
      } else {
        this.$emit('close');
      }
    }
  }
};
</script>
<style scoped lang="scss">

</style>