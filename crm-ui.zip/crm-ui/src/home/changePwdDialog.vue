<template>
  <el-dialog :visible="true" title="修改密码" width="450px" @close="handlerCancel">
    <el-form ref="form" :model="form">
        <el-form-item label="旧密码">
          <el-input v-model="form.oldpasswd" show-password></el-input>
      </el-form-item>
      <el-form-item label="新密码">
          <el-input v-model="form.newpasswd" show-password></el-input>
      </el-form-item>
      <el-form-item label="新密码确认">
          <el-input v-model="form.newpasswdConfirm" show-password></el-input>
      </el-form-item>
      <el-form-item>
          <el-button @click="handlerSave">保存</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>

<script>
import $http from '@/http';

export default {
  data() {
    return {
      form: {},
    };
  },
  props: ['user'],
  methods: {
    handlerCancel() {
      this.$emit('close');
    },
    handlerSave() {
      if (this.form.newpasswd !== this.form.newpasswdConfirm) {
        this.$notify.warning('两次新密码不一致');
        return;
      }
      const url = '/apis/account/passwd';
      const data = {
        id: this.user.uid,
        oldpasswd: this.form.oldpasswd,
        newpasswd: this.form.newpasswd
      };
      $http.put(url, data).then(res => {
        if (res.data.status === 0) {
          this.$notify.success({
            message: '修改成功'
          });
          this.$emit('close', true);
        } else {
          this.$notify.error({
            message: res.data.msg
          });
        }
      });
    }
  }
};
</script>
<style scoped lange="scss">
.left-panel {
    width: 500px;
    text-align: left;
    background: #fff;
}
</style>