<template>
    <div class="main">
      <div class="header">
        <div class="logo">
          <div class="logo-img"></div>
          <!-- <div class="logo-name">CRM系统</div> -->
        </div>
        <div class="handler flex">
          <!-- <i class="el-icon-bell mr-sm" v-if="user.admin === 'admin'"></i>
          <i class="el-icon-question mr-sm"></i> -->
          <span class="mr-sm user-name">你好，{{user.username}}</span>
          <!-- <div class="user-logo mr-sm"></div> -->
          <el-dropdown class="mr-sm" @command="handleCommand">
            <span class="el-dropdown-link mr-sm">
            <i class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item command="changePwd">修改密码</el-dropdown-item>
              <el-dropdown-item command="logout">登出</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
      <div class="content">
        <el-menu :unique-opened="true" :router="true" :default-openeds="openeds" class="menu" :default-active="currentNav">
          <el-menu-item v-if="authority.includes('customers')" index="/home/customers">客户管理</el-menu-item>
          <el-menu-item v-if="authority.includes('programMange')" index="/home/programMange">项目管理</el-menu-item>
          <el-menu-item v-if="authority.includes('users')" index="/home/users">账号管理</el-menu-item>
        </el-menu>
        <div class="page">
          <router-view></router-view>
        </div>
      </div>
      <changePwdDialog v-if="pwdDialog" :user="user" @close="close"></changePwdDialog>
    </div>
</template>

<script>
import $http from '@/http';
import changePwdDialog from './changePwdDialog.vue';
import authority from './authority';
import { getUser } from '@/user';

export default {
  components: {
    changePwdDialog
  },
  data() {
    return {
      user: {},
      pwdDialog: false,
      currentNav: '',
      openeds: [],
      authority: []
    };
  },
  mounted() {
    this.getCurRole();
    this.currentNav = this.$route.path;
    if (this.currentNav.includes('/home/customers/')) {
      this.currentNav = '/home/customers';
    }

    if (this.currentNav.includes('/home/gzoprogramMangenes/')) {
      this.currentNav = '/home/programMange'
    }
    this.$router.afterEach((to) => {
      if (this.currentNav !== to.path) {
        this.currentNav = to.path;
        if (this.currentNav.includes('/home/customers/')) {
          this.currentNav = '/home/customers';
        }

        if (this.currentNav.includes('/home/programMange/')) {
          this.currentNav = '/home/programMange'
        }
      }
    });
  },
  methods: {
    getCurRole() {
      this.user = getUser();
      this.authority = authority[this.user.role] || [];
    },
    handleCommand(type) {
      if (this[type]) {
        this[type]();
      }
    },
    changePwd() {
      this.pwdDialog = true;
    },
    close() {
      this.pwdDialog = false;
    },
    logout() {
      const url = '/apis/account/logout';
      $http.delete(url).then(() => {
        this.$router.push({
            path: '/login'
          });
      });
    }
  }
};
</script>
<style scoped lang="scss">
.main {
  height: 100%;
  .header {
    height: 60px;
    background: #001529;
    display: flex;
    .logo {
      width: 400px;
      color: #fff;
      display: flex;
      text-align: left;
      align-items: center;
      padding-left: 16px;
      .logo-img {
        display: inline-block;
        background: url(./../assets/logo.png);
        background-repeat: no-repeat;
        background-size: contain;
        height: 36px;
        width: 181px;
      }

      .logo-name {
        display: inline-block;
        line-height: 28px;
      }
    }
    .handler {
      flex: 1;
      justify-content: flex-end;
      align-items: center;
      .el-icon-bell {
        color: #fff;
      }

      .el-icon-question {
        background: #fff;
        border-radius: 50%;
        color: #001529;
      }

      .user {
        color: #fff;
      }
    }
  }

  .user-logo {
    width: 40px;
    height: 40px;
    // background: url(./../assets/account.jpeg);
    background-size: cover;
    border-radius: 50%;
  }

  .el-dropdown-link {
    color: #fff;
    cursor: pointer;
  }

  .content {
    display: flex;
    height: calc(100% - 60px);
    background: #f5f5f5;

    .menu {
      width: 240px;
      text-align: left;
      background: #233353;
      box-shadow: 0 2px 4px 0 rgba(0,0,0,0.08);
      & /deep/ .el-menu {
        background: transparent;
      }

      & /deep/ .el-menu-item {
        color: #fff;
      }

      & /deep/ .el-submenu__title {
        color: #fff;
      }

      & /deep/ .el-submenu__title:hover {
        background: transparent;
      }

      & /deep/ .el-menu-item:focus {
        color: #40A9FF;
        background: transparent;
      }

      & /deep/ .el-menu-item:hover {
        color: #40A9FF;
        background: transparent;
      }

      & /deep/ .el-submenu.is-active .el-submenu__title {
        color: #40A9FF;
      }

      & /deep/ .el-menu-item.is-active {
        color: #40A9FF;
      }


      .icon {
        background-size: cover;
        display: inline-block;
        width: 18px;
        height: 18px;
        margin-right: 15px;
        &.dns {
          // background-image: url(./../assets/dns-icon.png);
        }

        &.domain {
          // background-image: url(./../assets/domain-icon.png);
        }

        &.icp {
          // background-image: url(./../assets/icp-icon.png);
        }
      }
    }

    .page {
      flex: 1;
      overflow-y: hidden;
      padding: 12px 16px;
    }
  }

  .user-name {
    color: #fff;
  }
}
</style>