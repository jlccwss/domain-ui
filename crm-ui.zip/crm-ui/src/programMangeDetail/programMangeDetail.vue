<template>
    <el-form label-width="120px" ref="form" :rules="rules" :model="data">
      <div class="title">项目详情</div>
      <el-row>
      <el-col :span="12">
        <el-form-item prop="name" label="项目名称">
          <el-input :disabled="disabled" v-model="data.name"></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item prop="status" label="项目状态">
          <el-select :disabled="disabled" v-model="data.status" class="w-full" placeholder="项目状态">
            <el-option :key="proStatus.id" v-for="proStatus in proStatusList" :label="proStatus.name" :value="proStatus.id"></el-option>
          </el-select>
        </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="12">
        <el-form-item prop="beginTime" label="开始时间">
          <el-date-picker
            :disabled="disabled"
            class="w-full"
            v-model="data.beginTime"
            type="date"
            placeholder="选择日期">
          </el-date-picker>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item prop="endTime" label="结束时间">
          <el-date-picker
            :disabled="disabled"
            class="w-full"
            v-model="data.endTime"
            type="date"
            placeholder="选择日期">
          </el-date-picker>
        </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="12">
        <el-form-item prop="budget" label="项目金额">
          <el-input-number :disabled="disabled" class="times-inpout" :controls="false" v-model="data.budget" />万元
        </el-form-item>
        <el-form-item prop="comment" label="项目简介">
          <el-input :disabled="type === 'view'" type="textarea" rows="3" v-model="data.comment" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item prop="process" label="项目进展">
          <el-input :disabled="type === 'view'" v-model="data.process" type="textarea" rows="3" />
          <div class="align-left">示例： 20211201 adxxxxxx<br/>20220120 xxxx</div>
        </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="12">
        <el-form-item prop="owner" label="负责人">
          <el-input v-if="disabled" disabled class="w-full" v-model="data.ownerName"></el-input>
          <el-select v-else class="w-full" v-model="data.owner">
            <el-option :key="owner.id" v-for="owner in ownerList" :label="owner.name" :value="owner.id"></el-option>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item prop="sync" label="协作人">
          <el-select :disabled="disabled" multiple class="w-full" v-model="data.sync">
            <el-option :key="user.id" v-for="user in userList" :label="user.name" :value="user.id"></el-option>
          </el-select>
        </el-form-item>
      </el-col>
      </el-row>
      <el-row>
      <el-col :span="24">
        <el-form-item prop="costomerId" label="客户名称">
          <el-input v-if="disabled" disabled class="w-full" v-model="data.customerName"></el-input>
          <el-select v-else filterable :disabled="disabled" class="w-full" v-model="data.costomerId">
            <el-option :key="customer.id" v-for="customer in customerList" :label="customer.name" :value="customer.id"></el-option>
          </el-select>
        </el-form-item>
      </el-col>
      </el-row>
      <div class="title">项目工作量</div>
      <el-row>
      <el-col :span="12" v-if="timesAuth.includes('1')">
        <el-form-item prop="marketTime" label="营销中心">
          <el-input-number :disabled="type === 'view'" class="times-inpout" :controls="false" v-model="data.marketTime">
          </el-input-number>人天
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="timesAuth.includes('4')">
        <el-form-item prop="supportTime" label="技术服务中心">
          <el-input-number :disabled="type === 'view'" class="times-inpout" :controls="false" type="number" v-model="data.supportTime">
          </el-input-number>人天
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="timesAuth.includes('2')">
        <el-form-item prop="productTime" label="产品中心">
          <el-input-number :disabled="type === 'view'" class="times-inpout" :controls="false" type="number" v-model="data.productTime">
          </el-input-number>人天
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="timesAuth.includes('3')">
        <el-form-item prop="developTime" label="研发中心">
          <el-input-number :disabled="type === 'view'" class="times-inpout" :controls="false" type="number" v-model="data.developTime">
          </el-input-number>人天
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="timesAuth.includes('5')">
        <el-form-item prop="managerTime" label="综合管理中心">
          <el-input-number :disabled="type === 'view'" class="times-inpout" :controls="false" type="number" v-model="data.managerTime">
          </el-input-number>人天
        </el-form-item>
      </el-col>
      </el-row>
      <el-form-item>
        <el-button type="primary" @click="handleSave()">{{btnText}}</el-button>
        <el-button @click="handleClose()">取消</el-button>
      </el-form-item>
    </el-form>
</template>

<script>
import $http from '@/http';
import { getUser } from '@/user';

export default {
  data() {
    return {
      data: {},
      proStatusList: [],
      userList: [],
      customerList: [],
      ownerList: [],
      type: 'add',
      btnText: '立即创建',
      disabled: false,
      timesAuth: [],
      rules: {
        name: [
           { required: true, message: '请输入项目名称', trigger: 'blur' },
        ],
        status: [
           { required: true, message: '请输入项目名称', trigger: 'blur' },
        ],
        beginTime: [
           { required: true, message: '请选择开始时间', trigger: 'blur' },
        ],
        endTime: [
           { required: true, message: '请选择结束时间', trigger: 'blur' },
        ],
        process: [
           { required: true, message: '请选择项目进展', trigger: 'blur' },
        ],
        owner: [
           { required: true, message: '请选择负责人', trigger: 'blur' },
        ],
        costomerId: [
           { required: true, message: '请选择客户', trigger: 'blur' },
        ],
        budget: [
           { required: true, message: '请输入预算', trigger: 'blur' },
        ],
      }
    };
  },
  mounted() {
    this.getProStatusList();
    this.getOwnerList();
    this.getUserList();
    this.getCustomerList();
    const { id } = this.$route.params;
    const user = getUser();
    if (user.role === 'admin') {
        this.timesAuth = ['1', '2', '3', '4', '5'];
      } else {
        this.timesAuth = [user.department];
      }
    if (['add'].includes(id)) {
      this.type = id;
    }  else {
      this.type = 'edit';
      this.btnText = '更新';
      this.getDetail(id);
      if (user.role === 'xiezuo') {
        this.disabled = true;
      }
      
    }
  },
  methods: {
    getDetail(id) {
      const url = `/apis/item/item/${id}`;
      $http.get(url).then(res => {
        this.data = res.data;
      });
    },
    getProStatusList() {
      $http.get('/apis/status/statuss').then(res => {
        if (res.data.status === 0) {
          this.proStatusList = res.data.data;
        }
      });
    },
    getOwnerList() {
      $http.get('/apis/account/owners').then(res => {
        if (res.data.status === 0) {
          this.ownerList = res.data.data;
        }
      });
    },
    getUserList() {
      $http.get('/apis/account/sync').then(res => {
        if (res.data.status === 0) {
          this.userList = res.data.data;
        }
      });
    },
    getCustomerList() {
      $http.get('/apis/customer/listall').then(res => {
        if (res.data.status === 0) {
          this.customerList = res.data.data;
        }
      });
    },
    handleClose() {
      if (this.$route.params.cache) {
        this.$router.push({
          name: 'programMange',
          params: {
            cache: true
          }
        });
      } else {
        this.$router.push('/home/programMange');
      }
    },
    handleSave() {
      this.$refs.form.validate(valid => {
        if (valid) {
          let url = '/apis/item/item';
          let func = $http.post;
          if (this.type === 'edit') {
            func = $http.put;
            url += '/' + this.data.id;
          }

          if (!this.disabled) {
            const { costomerId } = this.data;
            const customer = this.customerList.find(item => item.id === costomerId) || {};
            const customerName = customer.name || costomerId;
            this.data.customerName = customerName;

            const { owner } = this.data;
            const ownerObj = this.ownerList.find(item => item.id === owner) || {};
            this.data.ownerName = ownerObj.name || owner;
          }
          func(url, this.data).then(res => {
            if (res.data.status === 0) {
              this.$notify.success({
                message: '保存成功'
              });
              setTimeout(() => {
                this.handleClose();
              }, 500);
            } else {
              this.$notify.error({
                message: res.data.msg
              });
            }
          });
        }
      });
    }
  }
};
</script>
<style scoped lang="scss">
.title {
  text-align: left;
  padding: 20px 10px;
}

.times-inpout {
  width: calc(100% - 40px);
  margin-right: 5px;

 & /deep/ .el-input .el-input__inner {
    text-align: right;
  }
}
</style>