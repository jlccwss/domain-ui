<template>
    <div>
      <div class="breadcrumb">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>统计</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <el-table
        :data="tableData"
        :span-method="objectSpanMethod"
        border
        style="width: 100%; margin-top: 20px">
        <el-table-column
          prop="id"
          label="负责人"
          width="180">
        </el-table-column>
        <el-table-column
          prop="name"
          label="行业">
        </el-table-column>
        <el-table-column
          prop="amount1"
          label="客户级别">
        </el-table-column>
        <el-table-column
          prop="amount2"
          label="数量（个）">
        </el-table-column>
        <el-table-column
          prop="amount3"
          label="汇总（个）">
        </el-table-column>
      </el-table>
    </div>
</template>

<script>
// import $http from '@/http';
// import { getUser } from '@/user';
// import authority from './../home/authority';

export default {
  data() {
    return {
      tableData: [{
          id: '北京连星',
          name: '金融',
          amount1: '新建',
          amount2: '3.2',
          amount3: 10
        }, {
          id: '北京连星',
          name: '金融',
          amount1: '潜在',
          amount2: '4.43',
          amount3: 12
        }, {
          id: '北京连星',
          name: '王小虎',
          amount1: '324',
          amount2: '1.9',
          amount3: 9
        }, {
          id: '北京连星',
          name: '王小虎',
          amount1: '621',
          amount2: '2.2',
          amount3: 17
        }, {
          id: '北京连星',
          name: '王小虎',
          amount1: '539',
          amount2: '4.1',
          amount3: 15
        }]
    };
  },
  mounted() {
    
  },
  methods: {
   objectSpanMethod({ rowIndex, columnIndex }) {
        if (columnIndex === 0) {
          if (rowIndex % 2 === 0) {
            return {
              rowspan: 2,
              colspan: 1
            };
          } else {
            return {
              rowspan: 0,
              colspan: 0
            };
          }
        }
   }
  }
};
</script>
<style scoped lang="scss">

</style>